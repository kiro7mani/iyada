'use strict';
/**
 * بذور البيانات الأولية (تشغيل لمرة واحدة بعد الترحيل):
 *   - الأدوار الثلاثة: admin, reception, doctor
 *   - مستخدم Admin افتراضي (يجب تغيير كلمة المرور فورًا بعد أول تسجيل دخول)
 *   - إعدادات العيادة الافتراضية
 *
 * الاستخدام:
 *   node database/seeds/run.js
 */

require('dotenv').config({ path: require('path').join(__dirname, '..', '..', 'backend', '.env') });
const { Client } = require('pg');
const bcrypt = require('bcryptjs');

const DEFAULT_ADMIN_USERNAME = 'admin';
const DEFAULT_ADMIN_PASSWORD = 'ChangeMe123!'; // ⚠ غيّرها فور أول تسجيل دخول

async function run() {
  const client = new Client({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT, 10) || 5432,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
  });
  await client.connect();

  try {
    await client.query('BEGIN');

    // 1) الأدوار
    const roles = [
      { name: 'admin', permissions: { all: true } },
      {
        name: 'reception',
        permissions: {
          patients: ['search', 'create', 'view'],
          queue: ['book', 'confirm_presence', 'view'],
          payments: ['create', 'view'],
        },
      },
      {
        name: 'doctor',
        permissions: {
          patients: ['view'],
          visits: ['examine', 'diagnose', 'prescribe', 'set_price', 'set_discount'],
          pregnancy: ['manage'],
          tv: ['control_playback'],
        },
      },
    ];

    const roleIds = {};
    for (const role of roles) {
      const res = await client.query(
        `INSERT INTO roles (name, permissions)
         VALUES ($1, $2)
         ON CONFLICT (name) DO UPDATE SET permissions = EXCLUDED.permissions
         RETURNING id`,
        [role.name, role.permissions]
      );
      roleIds[role.name] = res.rows[0].id;
    }
    console.log('✔ تم إنشاء/تحديث الأدوار:', roleIds);

    // 2) مستخدم Admin افتراضي
    const existingAdmin = await client.query('SELECT id FROM users WHERE username = $1', [
      DEFAULT_ADMIN_USERNAME,
    ]);

    if (existingAdmin.rows.length === 0) {
      const passwordHash = await bcrypt.hash(DEFAULT_ADMIN_PASSWORD, 12);
      await client.query(
        `INSERT INTO users (full_name, username, password_hash, role_id, is_active)
         VALUES ($1, $2, $3, $4, TRUE)`,
        ['مدير النظام', DEFAULT_ADMIN_USERNAME, passwordHash, roleIds.admin]
      );
      console.log(
        `✔ تم إنشاء مستخدم Admin افتراضي — اسم المستخدم: "${DEFAULT_ADMIN_USERNAME}" | كلمة المرور: "${DEFAULT_ADMIN_PASSWORD}"`
      );
      console.log('⚠ يجب تغيير كلمة المرور هذه فور أول تسجيل دخول.');
    } else {
      console.log('⏭ مستخدم Admin موجود مسبقًا، تم تخطي الإنشاء.');
    }

    // 3) إعدادات العيادة الافتراضية
    const defaultSettings = [
      ['clinic_name', 'عيادة أمراض النساء والتوليد ومتابعة الحمل'],
      ['logo_path', ''],
      ['clinic_address', ''],
      ['clinic_phone', ''],
      ['opening_time', '08:00'],
      ['closing_time', '18:00'],
      ['loyalty_visit_threshold', '5'],
      ['discount_type_allowed', 'BOTH'], // FIXED | PERCENTAGE | BOTH
    ];

    for (const [key, value] of defaultSettings) {
      await client.query(
        `INSERT INTO clinic_settings (key, value)
         VALUES ($1, $2)
         ON CONFLICT (key) DO NOTHING`,
        [key, value]
      );
    }
    console.log('✔ تم إدخال إعدادات العيادة الافتراضية.');

    // 4) خدمات افتراضية (يمكن تعديلها لاحقًا من لوحة الإدارة)
    const defaultServices = [
      ['فحص عام', 1500],
      ['إيكوغرافي', 2000],
    ];
    for (const [name, defaultPrice] of defaultServices) {
      const exists = await client.query('SELECT 1 FROM services WHERE name = $1', [name]);
      if (exists.rowCount === 0) {
        await client.query('INSERT INTO services (name, default_price) VALUES ($1, $2)', [name, defaultPrice]);
      }
    }
    console.log('✔ تم إدخال الخدمات الافتراضية.');

    await client.query('COMMIT');
    console.log('تم تنفيذ البذور بنجاح.');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('فشل تنفيذ البذور:', err.message);
    process.exitCode = 1;
  } finally {
    await client.end();
  }
}

run();
