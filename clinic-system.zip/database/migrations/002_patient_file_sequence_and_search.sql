-- ============================================================
-- 002_patient_file_sequence_and_search.sql
-- توليد رقم الملف الطبي (GYN-000001) تلقائيًا عبر Trigger
-- + تفعيل pg_trgm لدعم اكتشاف المريضات المشابهة (منع التكرار)
-- ============================================================

BEGIN;

-- ------------------------------------------------------------
-- 1) Sequence + Trigger لرقم الملف الطبي الدائم
-- ------------------------------------------------------------
CREATE SEQUENCE IF NOT EXISTS patient_file_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE FUNCTION generate_medical_file_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.medical_file_number IS NULL OR NEW.medical_file_number = '' THEN
    NEW.medical_file_number := 'GYN-' || LPAD(nextval('patient_file_seq')::text, 6, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_generate_medical_file_number ON patients;
CREATE TRIGGER trg_generate_medical_file_number
  BEFORE INSERT ON patients
  FOR EACH ROW
  EXECUTE FUNCTION generate_medical_file_number();

-- ------------------------------------------------------------
-- 2) pg_trgm لاكتشاف التشابه في الأسماء (منع تكرار المريضات)
-- ------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE INDEX IF NOT EXISTS idx_patients_fullname_trgm
  ON patients USING gin ((first_name || ' ' || last_name) gin_trgm_ops);

COMMIT;
