-- ============================================================
-- 003_payment_receipt_sequence.sql
-- توليد رقم الوصل (RCPT-000001) تلقائيًا عبر Trigger
-- ============================================================

BEGIN;

CREATE SEQUENCE IF NOT EXISTS payment_receipt_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE FUNCTION generate_receipt_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.receipt_number IS NULL OR NEW.receipt_number = '' THEN
    NEW.receipt_number := 'RCPT-' || LPAD(nextval('payment_receipt_seq')::text, 6, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_generate_receipt_number ON payments;
CREATE TRIGGER trg_generate_receipt_number
  BEFORE INSERT ON payments
  FOR EACH ROW
  EXECUTE FUNCTION generate_receipt_number();

COMMIT;
