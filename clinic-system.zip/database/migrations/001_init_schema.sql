-- ============================================================
-- 001_init_schema.sql
-- نظام إدارة عيادة أمراض النساء والتوليد ومتابعة الحمل
-- ينشئ كل الجداول والأنواع (ENUM) والفهارس الأساسية
-- ============================================================

BEGIN;

-- ------------------------------------------------------------
-- Extensions
-- ------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto; -- لتوليد tokens عشوائية آمنة

-- ------------------------------------------------------------
-- ENUM Types
-- ------------------------------------------------------------
CREATE TYPE visit_status AS ENUM (
  'BOOKED', 'PRESENT', 'WAITING', 'CALLED', 'WITH_DOCTOR',
  'EXAM_COMPLETED', 'AWAITING_PAYMENT', 'PAID', 'COMPLETED',
  'CANCELLED', 'NO_SHOW'
);

CREATE TYPE discount_type AS ENUM ('FIXED', 'PERCENTAGE');
CREATE TYPE payment_method AS ENUM ('CASH', 'CARD', 'OTHER');
CREATE TYPE pregnancy_status AS ENUM ('ACTIVE', 'DELIVERED', 'TERMINATED');
CREATE TYPE announcement_type AS ENUM ('CALL', 'RECALL');
CREATE TYPE backup_type AS ENUM ('DAILY', 'WEEKLY', 'MONTHLY', 'MANUAL');

-- ------------------------------------------------------------
-- roles
-- ------------------------------------------------------------
CREATE TABLE roles (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(30) NOT NULL UNIQUE, -- admin | reception | doctor
  permissions   JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- users
-- ------------------------------------------------------------
CREATE TABLE users (
  id              SERIAL PRIMARY KEY,
  full_name       VARCHAR(150) NOT NULL,
  username        VARCHAR(60) NOT NULL UNIQUE,
  password_hash   VARCHAR(255) NOT NULL,
  role_id         INTEGER NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_users_role_id ON users(role_id);

-- ------------------------------------------------------------
-- patients
-- ------------------------------------------------------------
CREATE TABLE patients (
  id                    SERIAL PRIMARY KEY,
  medical_file_number   VARCHAR(20) NOT NULL UNIQUE, -- GYN-000001
  first_name            VARCHAR(100) NOT NULL,
  last_name             VARCHAR(100) NOT NULL,
  birth_date            DATE,
  phone                 VARCHAR(30),
  address               TEXT,
  national_id           VARCHAR(50),
  admin_notes           TEXT,
  created_by            INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_patients_name ON patients(last_name, first_name);
CREATE INDEX idx_patients_phone ON patients(phone);
CREATE INDEX idx_patients_birth_date ON patients(birth_date);

-- ------------------------------------------------------------
-- patient_qr
-- ------------------------------------------------------------
CREATE TABLE patient_qr (
  id            SERIAL PRIMARY KEY,
  patient_id    INTEGER NOT NULL UNIQUE REFERENCES patients(id) ON DELETE CASCADE,
  token         VARCHAR(64) NOT NULL UNIQUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- visits
-- ------------------------------------------------------------
CREATE TABLE visits (
  id                SERIAL PRIMARY KEY,
  patient_id        INTEGER NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  visit_date        DATE NOT NULL DEFAULT CURRENT_DATE,
  booked_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  status            visit_status NOT NULL DEFAULT 'BOOKED',
  visit_type        VARCHAR(50) NOT NULL DEFAULT 'GENERAL', -- GENERAL | PREGNANCY | OTHER
  doctor_id         INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reception_notes   TEXT,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_visits_patient_id ON visits(patient_id);
CREATE INDEX idx_visits_date_status ON visits(visit_date, status);

-- ------------------------------------------------------------
-- daily_queue
-- ------------------------------------------------------------
CREATE TABLE daily_queue (
  id                SERIAL PRIMARY KEY,
  visit_id          INTEGER NOT NULL UNIQUE REFERENCES visits(id) ON DELETE CASCADE,
  queue_date        DATE NOT NULL,
  queue_number      INTEGER NOT NULL,
  called_at         TIMESTAMPTZ,
  recalled_count    INTEGER NOT NULL DEFAULT 0,
  UNIQUE (queue_date, queue_number)
);
CREATE INDEX idx_daily_queue_date ON daily_queue(queue_date);

-- ------------------------------------------------------------
-- medical_history (ملاحظات الفحص لكل زيارة)
-- ------------------------------------------------------------
CREATE TABLE medical_history (
  id                        SERIAL PRIMARY KEY,
  visit_id                  INTEGER NOT NULL UNIQUE REFERENCES visits(id) ON DELETE CASCADE,
  reason_for_visit          TEXT,
  examination_notes         TEXT,
  diagnosis                 TEXT,
  treatment_plan            TEXT,
  reception_measurements    JSONB, -- {blood_pressure, blood_sugar, weight, height, temperature}
  doctor_notes               TEXT,
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- pregnancies
-- ------------------------------------------------------------
CREATE TABLE pregnancies (
  id                          SERIAL PRIMARY KEY,
  patient_id                  INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  lmp_date                    DATE,
  edd_date                    DATE,
  gravida                     INTEGER,
  para                        INTEGER,
  previous_pregnancy_notes    TEXT,
  status                      pregnancy_status NOT NULL DEFAULT 'ACTIVE',
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_pregnancies_patient_id ON pregnancies(patient_id);

-- ------------------------------------------------------------
-- pregnancy_visits
-- ------------------------------------------------------------
CREATE TABLE pregnancy_visits (
  id                        SERIAL PRIMARY KEY,
  pregnancy_id              INTEGER NOT NULL REFERENCES pregnancies(id) ON DELETE CASCADE,
  visit_id                  INTEGER NOT NULL UNIQUE REFERENCES visits(id) ON DELETE CASCADE,
  gestational_age_weeks     INTEGER,
  weight                    NUMERIC(6,2),
  blood_pressure            VARCHAR(20),
  blood_sugar               VARCHAR(20),
  lab_summary               TEXT,
  ultrasound_summary        TEXT,
  medications                TEXT,
  supplements                TEXT,
  notes                      TEXT
);
CREATE INDEX idx_pregnancy_visits_pregnancy_id ON pregnancy_visits(pregnancy_id);

-- ------------------------------------------------------------
-- radiology
-- ------------------------------------------------------------
CREATE TABLE radiology (
  id            SERIAL PRIMARY KEY,
  patient_id    INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  visit_id      INTEGER NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
  file_path     VARCHAR(500) NOT NULL,
  file_type     VARCHAR(20) NOT NULL, -- image | pdf
  report_text   TEXT,
  notes         TEXT,
  uploaded_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_radiology_visit_id ON radiology(visit_id);

-- ------------------------------------------------------------
-- lab_results
-- ------------------------------------------------------------
CREATE TABLE lab_results (
  id             SERIAL PRIMARY KEY,
  patient_id     INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  visit_id       INTEGER NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
  test_name      VARCHAR(150) NOT NULL,
  result_value   VARCHAR(150),
  unit           VARCHAR(30),
  notes          TEXT,
  file_path      VARCHAR(500),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_lab_results_visit_id ON lab_results(visit_id);

-- ------------------------------------------------------------
-- prescriptions / prescription_items
-- ------------------------------------------------------------
CREATE TABLE prescriptions (
  id            SERIAL PRIMARY KEY,
  visit_id      INTEGER NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
  created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_prescriptions_visit_id ON prescriptions(visit_id);

CREATE TABLE prescription_items (
  id                 SERIAL PRIMARY KEY,
  prescription_id    INTEGER NOT NULL REFERENCES prescriptions(id) ON DELETE CASCADE,
  medication_name    VARCHAR(200) NOT NULL,
  dosage             VARCHAR(100),
  frequency          VARCHAR(100),
  duration           VARCHAR(100),
  instructions       TEXT
);
CREATE INDEX idx_prescription_items_prescription_id ON prescription_items(prescription_id);

-- ------------------------------------------------------------
-- services / visit_services
-- ------------------------------------------------------------
CREATE TABLE services (
  id              SERIAL PRIMARY KEY,
  name            VARCHAR(150) NOT NULL,
  default_price   NUMERIC(10,2) NOT NULL DEFAULT 0,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE visit_services (
  id            SERIAL PRIMARY KEY,
  visit_id      INTEGER NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
  service_id    INTEGER NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
  price         NUMERIC(10,2) NOT NULL,
  set_by        INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX idx_visit_services_visit_id ON visit_services(visit_id);

-- ------------------------------------------------------------
-- discounts
-- ------------------------------------------------------------
CREATE TABLE discounts (
  id            SERIAL PRIMARY KEY,
  visit_id      INTEGER NOT NULL UNIQUE REFERENCES visits(id) ON DELETE CASCADE,
  type          discount_type NOT NULL,
  value         NUMERIC(10,2) NOT NULL,
  subtotal      NUMERIC(10,2) NOT NULL,
  total         NUMERIC(10,2) NOT NULL,
  set_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- payments
-- ------------------------------------------------------------
CREATE TABLE payments (
  id                SERIAL PRIMARY KEY,
  visit_id          INTEGER NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
  amount            NUMERIC(10,2) NOT NULL,
  method            payment_method NOT NULL,
  received_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
  paid_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  receipt_number    VARCHAR(30) NOT NULL UNIQUE
);
CREATE INDEX idx_payments_visit_id ON payments(visit_id);

-- ------------------------------------------------------------
-- TV: media / playlists / playlist_items / settings / announcements
-- ------------------------------------------------------------
CREATE TABLE tv_media (
  id                  SERIAL PRIMARY KEY,
  file_path           VARCHAR(500) NOT NULL,
  title               VARCHAR(200) NOT NULL,
  category            VARCHAR(60), -- توعية | حمل | خدمات | إعلانات
  duration_seconds    INTEGER,
  uploaded_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE tv_playlists (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  is_default    BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE tv_playlist_items (
  id             SERIAL PRIMARY KEY,
  playlist_id    INTEGER NOT NULL REFERENCES tv_playlists(id) ON DELETE CASCADE,
  media_id       INTEGER NOT NULL REFERENCES tv_media(id) ON DELETE CASCADE,
  order_index    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_tv_playlist_items_playlist_id ON tv_playlist_items(playlist_id);

CREATE TABLE tv_settings (
  id                    SERIAL PRIMARY KEY,
  start_time            TIME NOT NULL,
  end_time              TIME NOT NULL,
  playlist_id           INTEGER REFERENCES tv_playlists(id) ON DELETE SET NULL,
  show_clock            BOOLEAN NOT NULL DEFAULT TRUE,
  show_weather          BOOLEAN NOT NULL DEFAULT TRUE,
  show_logo             BOOLEAN NOT NULL DEFAULT TRUE,
  call_volume           INTEGER NOT NULL DEFAULT 80 CHECK (call_volume BETWEEN 0 AND 100),
  call_repeat_count     INTEGER NOT NULL DEFAULT 2
);

CREATE TABLE tv_announcements (
  id              SERIAL PRIMARY KEY,
  queue_number    INTEGER NOT NULL,
  visit_id        INTEGER REFERENCES visits(id) ON DELETE SET NULL,
  announced_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  type            announcement_type NOT NULL DEFAULT 'CALL'
);

-- ------------------------------------------------------------
-- clinic_settings (Key/Value عام)
-- ------------------------------------------------------------
CREATE TABLE clinic_settings (
  key           VARCHAR(100) PRIMARY KEY,
  value         TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ------------------------------------------------------------
-- audit_logs
-- ------------------------------------------------------------
CREATE TABLE audit_logs (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action         VARCHAR(100) NOT NULL,
  record_type    VARCHAR(60),
  record_id      INTEGER,
  details        JSONB,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);

-- ------------------------------------------------------------
-- backups
-- ------------------------------------------------------------
CREATE TABLE backups (
  id            SERIAL PRIMARY KEY,
  file_path     VARCHAR(500) NOT NULL,
  type          backup_type NOT NULL,
  size_bytes    BIGINT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMIT;
