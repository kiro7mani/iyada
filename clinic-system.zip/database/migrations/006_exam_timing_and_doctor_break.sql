-- ============================================================
-- 006_exam_timing_and_doctor_break.sql
-- تتبّع وقت بداية/نهاية الفحص الفعلي (لحساب متوسط الوقت المتوقع)
-- + حالة استراحة عمل الطبيبة (Singleton)
-- ============================================================

BEGIN;

ALTER TABLE visits ADD COLUMN IF NOT EXISTS with_doctor_started_at TIMESTAMPTZ;
ALTER TABLE visits ADD COLUMN IF NOT EXISTS with_doctor_ended_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS doctor_break_status (
  id            SERIAL PRIMARY KEY,
  is_on_break   BOOLEAN NOT NULL DEFAULT FALSE,
  started_at    TIMESTAMPTZ,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- سجل واحد فقط (Singleton) يمثّل الحالة الحالية
INSERT INTO doctor_break_status (is_on_break)
SELECT FALSE
WHERE NOT EXISTS (SELECT 1 FROM doctor_break_status);

COMMIT;
