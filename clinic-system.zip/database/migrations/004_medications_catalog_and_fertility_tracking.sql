-- ============================================================
-- 004_medications_catalog_and_fertility_tracking.sql
-- كتالوج الأدوية (لوحة الإدارة → إدارة الأدوية)
-- متابعة الإنجاب (تاريخ الزواج / آخر حمل)
-- إضافة عمود "عدد العلب" لعناصر الوصفة
-- ============================================================

BEGIN;

-- ------------------------------------------------------------
-- كتالوج الأدوية
-- ------------------------------------------------------------
CREATE TABLE medications (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(200) NOT NULL UNIQUE,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_medications_name ON medications(name);

-- ------------------------------------------------------------
-- عدد العلب في عنصر الوصفة (الجرعة/عدد المرات مخزّنة أصلًا في dosage/frequency)
-- ------------------------------------------------------------
ALTER TABLE prescription_items ADD COLUMN IF NOT EXISTS quantity VARCHAR(50);

-- ------------------------------------------------------------
-- متابعة الإنجاب: سجل واحد حالي لكل مريضة (تاريخ الزواج أو آخر حمل)
-- ------------------------------------------------------------
CREATE TABLE patient_fertility_tracking (
  id              SERIAL PRIMARY KEY,
  patient_id      INTEGER NOT NULL UNIQUE REFERENCES patients(id) ON DELETE CASCADE,
  date_type       VARCHAR(20) NOT NULL CHECK (date_type IN ('MARRIAGE', 'LAST_PREGNANCY')),
  reference_date  DATE NOT NULL,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMIT;
