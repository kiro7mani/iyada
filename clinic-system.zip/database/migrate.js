'use strict';
/**
 * أداة بسيطة لتشغيل ملفات الترحيل (Migrations) بالترتيب،
 * مع تسجيل الملفات المنفذة في جدول schema_migrations لمنع إعادة التنفيذ.
 *
 * الاستخدام:
 *   node database/migrate.js up
 */

require('dotenv').config({ path: require('path').join(__dirname, '..', 'backend', '.env') });
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

const MIGRATIONS_DIR = path.join(__dirname, 'migrations');

async function getClient() {
  const client = new Client({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT, 10) || 5432,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
  });
  await client.connect();
  return client;
}

async function ensureMigrationsTable(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      filename    VARCHAR(255) PRIMARY KEY,
      applied_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

async function getAppliedMigrations(client) {
  const res = await client.query('SELECT filename FROM schema_migrations ORDER BY filename');
  return new Set(res.rows.map((r) => r.filename));
}

async function up() {
  const client = await getClient();
  try {
    await ensureMigrationsTable(client);
    const applied = await getAppliedMigrations(client);

    const files = fs
      .readdirSync(MIGRATIONS_DIR)
      .filter((f) => f.endsWith('.sql'))
      .sort();

    let executedCount = 0;
    for (const file of files) {
      if (applied.has(file)) {
        console.log(`⏭  تم تخطيه (منفذ مسبقًا): ${file}`);
        continue;
      }
      const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');
      console.log(`▶  تنفيذ: ${file}`);
      await client.query(sql);
      await client.query('INSERT INTO schema_migrations (filename) VALUES ($1)', [file]);
      console.log(`✔  تم بنجاح: ${file}`);
      executedCount += 1;
    }

    if (executedCount === 0) {
      console.log('لا توجد ملفات ترحيل جديدة. قاعدة البيانات محدّثة بالفعل.');
    } else {
      console.log(`تم تنفيذ ${executedCount} ملف/ملفات ترحيل بنجاح.`);
    }
  } catch (err) {
    console.error('فشل تنفيذ الترحيل:', err.message);
    process.exitCode = 1;
  } finally {
    await client.end();
  }
}

const command = process.argv[2];
if (command === 'up') {
  up();
} else {
  console.log('الاستخدام: node database/migrate.js up');
  process.exitCode = 1;
}
