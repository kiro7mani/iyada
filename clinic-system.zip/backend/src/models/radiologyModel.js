'use strict';

const { query } = require('../config/db');

const FIELDS = `
  id, patient_id, visit_id, file_path, file_type, report_text, notes, uploaded_by, created_at
`;

async function create({ patientId, visitId, filePath, fileType, reportText, notes, uploadedBy }) {
  const res = await query(
    `INSERT INTO radiology (patient_id, visit_id, file_path, file_type, report_text, notes, uploaded_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING ${FIELDS}`,
    [patientId, visitId, filePath, fileType, reportText || null, notes || null, uploadedBy || null]
  );
  return res.rows[0];
}

async function findById(id) {
  const res = await query(`SELECT ${FIELDS} FROM radiology WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

async function findByVisitId(visitId) {
  const res = await query(`SELECT ${FIELDS} FROM radiology WHERE visit_id = $1 ORDER BY created_at DESC`, [
    visitId,
  ]);
  return res.rows;
}

async function findByPatientId(patientId) {
  const res = await query(`SELECT ${FIELDS} FROM radiology WHERE patient_id = $1 ORDER BY created_at DESC`, [
    patientId,
  ]);
  return res.rows;
}

module.exports = { create, findById, findByVisitId, findByPatientId };
