'use strict';

const { query } = require('../config/db');

async function addService(visitId, serviceId, price, setBy) {
  const res = await query(
    `INSERT INTO visit_services (visit_id, service_id, price, set_by)
     VALUES ($1, $2, $3, $4)
     RETURNING id, visit_id, service_id, price, set_by`,
    [visitId, serviceId, price, setBy]
  );
  return res.rows[0];
}

async function findByVisitId(visitId) {
  const res = await query(
    `SELECT vs.id, vs.visit_id, vs.service_id, vs.price, s.name AS service_name
     FROM visit_services vs
     JOIN services s ON s.id = vs.service_id
     WHERE vs.visit_id = $1
     ORDER BY vs.id ASC`,
    [visitId]
  );
  return res.rows;
}

async function removeById(id, visitId) {
  const res = await query('DELETE FROM visit_services WHERE id = $1 AND visit_id = $2 RETURNING id', [
    id,
    visitId,
  ]);
  return res.rowCount > 0;
}

/**
 * مجموع أسعار الخدمات المضافة على الزيارة (Subtotal قبل التخفيض).
 */
async function sumByVisitId(visitId) {
  const res = await query(
    'SELECT COALESCE(SUM(price), 0) AS subtotal FROM visit_services WHERE visit_id = $1',
    [visitId]
  );
  return Number(res.rows[0].subtotal);
}

module.exports = { addService, findByVisitId, removeById, sumByVisitId };
