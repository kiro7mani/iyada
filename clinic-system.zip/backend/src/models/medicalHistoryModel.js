'use strict';

const { query } = require('../config/db');

async function findByVisitId(visitId) {
  const res = await query(
    `SELECT visit_id, reason_for_visit, examination_notes, diagnosis, treatment_plan,
            reception_measurements, doctor_notes, updated_at
     FROM medical_history WHERE visit_id = $1`,
    [visitId]
  );
  return res.rows[0] || null;
}

/**
 * يُدرج/يحدّث قياسات الاستقبال فقط، دون المساس بحقول الفحص الطبي إن وُجدت.
 */
async function upsertMeasurements(visitId, measurements) {
  const res = await query(
    `INSERT INTO medical_history (visit_id, reception_measurements)
     VALUES ($1, $2)
     ON CONFLICT (visit_id) DO UPDATE
       SET reception_measurements = EXCLUDED.reception_measurements, updated_at = NOW()
     RETURNING visit_id, reason_for_visit, examination_notes, diagnosis, treatment_plan,
               reception_measurements, doctor_notes, updated_at`,
    [visitId, JSON.stringify(measurements)]
  );
  return res.rows[0];
}

/**
 * يُدرج/يحدّث بيانات فحص الطبيبة فقط، دون المساس بقياسات الاستقبال إن وُجدت.
 */
async function upsertExamination(visitId, { reasonForVisit, examinationNotes, diagnosis, treatmentPlan, doctorNotes }) {
  const res = await query(
    `INSERT INTO medical_history (visit_id, reason_for_visit, examination_notes, diagnosis, treatment_plan, doctor_notes)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (visit_id) DO UPDATE
       SET reason_for_visit = EXCLUDED.reason_for_visit,
           examination_notes = EXCLUDED.examination_notes,
           diagnosis = EXCLUDED.diagnosis,
           treatment_plan = EXCLUDED.treatment_plan,
           doctor_notes = EXCLUDED.doctor_notes,
           updated_at = NOW()
     RETURNING visit_id, reason_for_visit, examination_notes, diagnosis, treatment_plan,
               reception_measurements, doctor_notes, updated_at`,
    [visitId, reasonForVisit || null, examinationNotes || null, diagnosis || null, treatmentPlan || null, doctorNotes || null]
  );
  return res.rows[0];
}

module.exports = { findByVisitId, upsertMeasurements, upsertExamination };
