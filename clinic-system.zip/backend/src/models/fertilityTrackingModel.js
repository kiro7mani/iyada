'use strict';

const { query } = require('../config/db');

async function findByPatientId(patientId) {
  const res = await query(
    'SELECT id, patient_id, date_type, reference_date, updated_at FROM patient_fertility_tracking WHERE patient_id = $1',
    [patientId]
  );
  return res.rows[0] || null;
}

/**
 * يُدرج/يحدّث سجل متابعة الإنجاب (سجل واحد حالي لكل مريضة، قابل للتعديل في كل زيارة).
 */
async function upsert(patientId, { dateType, referenceDate }) {
  const res = await query(
    `INSERT INTO patient_fertility_tracking (patient_id, date_type, reference_date)
     VALUES ($1, $2, $3)
     ON CONFLICT (patient_id) DO UPDATE
       SET date_type = EXCLUDED.date_type, reference_date = EXCLUDED.reference_date, updated_at = NOW()
     RETURNING id, patient_id, date_type, reference_date, updated_at`,
    [patientId, dateType, referenceDate]
  );
  return res.rows[0];
}

module.exports = { findByPatientId, upsert };
