'use strict';

const { query } = require('../config/db');

const PREGNANCY_FIELDS = `
  id, patient_id, lmp_date, edd_date, gravida, para,
  previous_pregnancy_notes, status, created_at
`;

async function create({ patientId, lmpDate, eddDate, gravida, para, previousPregnancyNotes }) {
  const res = await query(
    `INSERT INTO pregnancies (patient_id, lmp_date, edd_date, gravida, para, previous_pregnancy_notes)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING ${PREGNANCY_FIELDS}`,
    [patientId, lmpDate || null, eddDate || null, gravida || null, para || null, previousPregnancyNotes || null]
  );
  return res.rows[0];
}

async function findById(id) {
  const res = await query(`SELECT ${PREGNANCY_FIELDS} FROM pregnancies WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

async function findByPatientId(patientId) {
  const res = await query(
    `SELECT ${PREGNANCY_FIELDS} FROM pregnancies WHERE patient_id = $1 ORDER BY created_at DESC`,
    [patientId]
  );
  return res.rows;
}

async function updateStatus(id, status) {
  const res = await query(
    `UPDATE pregnancies SET status = $2 WHERE id = $1 RETURNING ${PREGNANCY_FIELDS}`,
    [id, status]
  );
  return res.rows[0] || null;
}

async function update(id, { lmpDate, eddDate, gravida, para, previousPregnancyNotes }) {
  const res = await query(
    `UPDATE pregnancies SET
        lmp_date = COALESCE($2, lmp_date),
        edd_date = COALESCE($3, edd_date),
        gravida = COALESCE($4, gravida),
        para = COALESCE($5, para),
        previous_pregnancy_notes = COALESCE($6, previous_pregnancy_notes)
     WHERE id = $1
     RETURNING ${PREGNANCY_FIELDS}`,
    [id, lmpDate, eddDate, gravida, para, previousPregnancyNotes]
  );
  return res.rows[0] || null;
}

module.exports = { create, findById, findByPatientId, updateStatus, update };
