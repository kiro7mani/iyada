'use strict';

const { query } = require('../config/db');

/**
 * إجماليات الفوترة لزيارة واحدة: المجموع الفرعي، التخفيض (إن وُجد)، المبلغ الإجمالي،
 * ما دُفع فعليًا، وما تبقى.
 */
async function getVisitTotals(visitId) {
  const servicesRes = await query(
    `SELECT vs.id, vs.service_id, vs.price, s.name AS service_name
     FROM visit_services vs JOIN services s ON s.id = vs.service_id
     WHERE vs.visit_id = $1 ORDER BY vs.id`,
    [visitId]
  );
  const services = servicesRes.rows;
  const subtotal = services.reduce((sum, s) => sum + Number(s.price), 0);

  const discountRes = await query(
    'SELECT type, value, subtotal, total FROM discounts WHERE visit_id = $1',
    [visitId]
  );
  const discount = discountRes.rows[0] || null;
  const total = discount ? Number(discount.total) : subtotal;

  const paidRes = await query(
    'SELECT COALESCE(SUM(amount), 0) AS paid FROM payments WHERE visit_id = $1',
    [visitId]
  );
  const paidAmount = Number(paidRes.rows[0].paid);

  return {
    services,
    subtotal,
    discount,
    total,
    paidAmount,
    remainingBalance: Math.max(0, total - paidAmount),
  };
}

/**
 * الأرصدة المتبقية من زيارات سابقة مكتملة لنفس المريضة (باستثناء الزيارة الحالية) —
 * تُعرض في نافذة "تخليص" الزيارة الجديدة، ويبقى كل رصيد مرتبطًا بزيارته الأصلية.
 */
async function getOutstandingBalancesForPatient(patientId, excludeVisitId) {
  const res = await query(
    `WITH visit_totals AS (
       SELECT v.id AS visit_id, v.visit_date,
              COALESCE(d.total, vs_sum.subtotal, 0) AS total,
              COALESCE(pay_sum.paid, 0) AS paid
       FROM visits v
       LEFT JOIN discounts d ON d.visit_id = v.id
       LEFT JOIN (SELECT visit_id, SUM(price) AS subtotal FROM visit_services GROUP BY visit_id) vs_sum
         ON vs_sum.visit_id = v.id
       LEFT JOIN (SELECT visit_id, SUM(amount) AS paid FROM payments GROUP BY visit_id) pay_sum
         ON pay_sum.visit_id = v.id
       WHERE v.patient_id = $1 AND v.id <> $2 AND v.status = 'COMPLETED'
     )
     SELECT visit_id, visit_date, total, paid, (total - paid) AS remaining_balance
     FROM visit_totals
     WHERE (total - paid) > 0.01
     ORDER BY visit_date ASC`,
    [patientId, excludeVisitId]
  );
  return res.rows;
}

module.exports = { getVisitTotals, getOutstandingBalancesForPatient };
