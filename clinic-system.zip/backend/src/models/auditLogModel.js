'use strict';

const { query } = require('../config/db');

/**
 * قراءة سجل التدقيق مع فلاتر اختيارية وترقيم صفحات.
 */
async function findAll({ userId = null, action = null, from = null, to = null, page = 1, limit = 50 }) {
  const offset = (page - 1) * limit;
  const res = await query(
    `SELECT al.id, al.user_id, u.full_name AS user_name, u.username,
            al.action, al.record_type, al.record_id, al.details, al.created_at
     FROM audit_logs al
     LEFT JOIN users u ON u.id = al.user_id
     WHERE ($1::int IS NULL OR al.user_id = $1)
       AND ($2::text IS NULL OR al.action ILIKE '%' || $2 || '%')
       AND ($3::date IS NULL OR al.created_at::date >= $3)
       AND ($4::date IS NULL OR al.created_at::date <= $4)
     ORDER BY al.created_at DESC
     LIMIT $5 OFFSET $6`,
    [userId, action, from, to, limit, offset]
  );
  return res.rows;
}

async function countAll({ userId = null, action = null, from = null, to = null }) {
  const res = await query(
    `SELECT COUNT(*)::int AS count
     FROM audit_logs al
     WHERE ($1::int IS NULL OR al.user_id = $1)
       AND ($2::text IS NULL OR al.action ILIKE '%' || $2 || '%')
       AND ($3::date IS NULL OR al.created_at::date >= $3)
       AND ($4::date IS NULL OR al.created_at::date <= $4)`,
    [userId, action, from, to]
  );
  return res.rows[0].count;
}

module.exports = { findAll, countAll };
