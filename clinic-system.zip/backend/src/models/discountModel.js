'use strict';

const { query } = require('../config/db');

async function upsert(visitId, { type, value, subtotal, total, setBy }) {
  const res = await query(
    `INSERT INTO discounts (visit_id, type, value, subtotal, total, set_by)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (visit_id) DO UPDATE
       SET type = EXCLUDED.type, value = EXCLUDED.value,
           subtotal = EXCLUDED.subtotal, total = EXCLUDED.total, set_by = EXCLUDED.set_by
     RETURNING id, visit_id, type, value, subtotal, total, set_by, created_at`,
    [visitId, type, value, subtotal, total, setBy]
  );
  return res.rows[0];
}

async function findByVisitId(visitId) {
  const res = await query(
    'SELECT id, visit_id, type, value, subtotal, total, set_by, created_at FROM discounts WHERE visit_id = $1',
    [visitId]
  );
  return res.rows[0] || null;
}

module.exports = { upsert, findByVisitId };
