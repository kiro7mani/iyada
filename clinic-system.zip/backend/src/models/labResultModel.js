'use strict';

const { query } = require('../config/db');

const FIELDS = `
  id, patient_id, visit_id, test_name, result_value, unit, notes, file_path, created_at
`;

async function create({ patientId, visitId, testName, resultValue, unit, notes, filePath }) {
  const res = await query(
    `INSERT INTO lab_results (patient_id, visit_id, test_name, result_value, unit, notes, file_path)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING ${FIELDS}`,
    [patientId, visitId, testName, resultValue || null, unit || null, notes || null, filePath || null]
  );
  return res.rows[0];
}

async function findById(id) {
  const res = await query(`SELECT ${FIELDS} FROM lab_results WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

async function findByVisitId(visitId) {
  const res = await query(`SELECT ${FIELDS} FROM lab_results WHERE visit_id = $1 ORDER BY created_at DESC`, [
    visitId,
  ]);
  return res.rows;
}

async function findByPatientId(patientId) {
  const res = await query(`SELECT ${FIELDS} FROM lab_results WHERE patient_id = $1 ORDER BY created_at DESC`, [
    patientId,
  ]);
  return res.rows;
}

module.exports = { create, findById, findByVisitId, findByPatientId };
