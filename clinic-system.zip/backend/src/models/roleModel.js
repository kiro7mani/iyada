'use strict';

const { query } = require('../config/db');

async function findAll() {
  const res = await query('SELECT id, name, permissions, created_at FROM roles ORDER BY id');
  return res.rows;
}

async function findByName(name) {
  const res = await query('SELECT id, name, permissions FROM roles WHERE name = $1', [name]);
  return res.rows[0] || null;
}

async function findById(id) {
  const res = await query('SELECT id, name, permissions FROM roles WHERE id = $1', [id]);
  return res.rows[0] || null;
}

module.exports = { findAll, findByName, findById };
