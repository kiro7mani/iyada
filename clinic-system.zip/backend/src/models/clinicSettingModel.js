'use strict';

const { query } = require('../config/db');

async function getAll() {
  const res = await query('SELECT key, value, updated_at FROM clinic_settings ORDER BY key');
  const settings = {};
  for (const row of res.rows) {
    settings[row.key] = row.value;
  }
  return settings;
}

async function getByKey(key) {
  const res = await query('SELECT value FROM clinic_settings WHERE key = $1', [key]);
  return res.rows[0] ? res.rows[0].value : null;
}

/**
 * تحديث/إدراج مجموعة إعدادات دفعة واحدة.
 * @param {Record<string, string>} settingsObject
 */
async function upsertMany(settingsObject) {
  const entries = Object.entries(settingsObject);
  for (const [key, value] of entries) {
    await query(
      `INSERT INTO clinic_settings (key, value, updated_at)
       VALUES ($1, $2, NOW())
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
      [key, String(value)]
    );
  }
  return getAll();
}

module.exports = { getAll, getByKey, upsertMany };
