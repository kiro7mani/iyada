'use strict';

const { query } = require('../config/db');

async function findAll({ activeOnly = false } = {}) {
  const sql = activeOnly
    ? 'SELECT id, name, default_price, is_active FROM services WHERE is_active = TRUE ORDER BY name'
    : 'SELECT id, name, default_price, is_active FROM services ORDER BY name';
  const res = await query(sql);
  return res.rows;
}

async function findById(id) {
  const res = await query('SELECT id, name, default_price, is_active FROM services WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function create({ name, defaultPrice }) {
  const res = await query(
    `INSERT INTO services (name, default_price) VALUES ($1, $2)
     RETURNING id, name, default_price, is_active`,
    [name, defaultPrice]
  );
  return res.rows[0];
}

async function update(id, { name, defaultPrice, isActive }) {
  const res = await query(
    `UPDATE services SET
        name = COALESCE($2, name),
        default_price = COALESCE($3, default_price),
        is_active = COALESCE($4, is_active)
     WHERE id = $1
     RETURNING id, name, default_price, is_active`,
    [id, name, defaultPrice, isActive]
  );
  return res.rows[0] || null;
}

async function remove(id) {
  const res = await query('DELETE FROM services WHERE id = $1 RETURNING id', [id]);
  return res.rowCount > 0;
}

module.exports = { findAll, findById, create, update, remove };
