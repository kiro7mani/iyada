'use strict';

const { query } = require('../config/db');

const PATIENT_FIELDS = `
  id, medical_file_number, first_name, last_name, birth_date, phone,
  address, national_id, admin_notes, created_by, created_at, updated_at
`;

/**
 * بحث مدمج بالاسم/الهاتف/رقم الملف (كنص واحد) + تصفية اختيارية بتاريخ الميلاد.
 */
async function search({ q = null, birthDate = null, limit = 50 }) {
  const res = await query(
    `SELECT ${PATIENT_FIELDS}
     FROM patients
     WHERE
       ($1::text IS NULL OR $1 = '' OR
         (first_name || ' ' || last_name) ILIKE '%' || $1 || '%' OR
         phone ILIKE '%' || $1 || '%' OR
         medical_file_number ILIKE '%' || $1 || '%' OR
         id::text = $1
       )
       AND ($2::date IS NULL OR birth_date = $2)
     ORDER BY updated_at DESC
     LIMIT $3`,
    [q, birthDate, limit]
  );
  return res.rows;
}

async function findById(id) {
  const res = await query(`SELECT ${PATIENT_FIELDS} FROM patients WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

async function findByMedicalFileNumber(fileNumber) {
  const res = await query(`SELECT ${PATIENT_FIELDS} FROM patients WHERE medical_file_number = $1`, [
    fileNumber,
  ]);
  return res.rows[0] || null;
}

/**
 * اكتشاف مريضات مشابهات (قبل الإنشاء) عبر:
 *  - تشابه الاسم الكامل (pg_trgm) بعتبة 0.35
 *  - تطابق تام في تاريخ الميلاد
 *  - تطابق تام في الهاتف
 */
async function findPossibleDuplicates({ firstName, lastName, birthDate = null, phone = null }) {
  const fullName = `${firstName || ''} ${lastName || ''}`.trim();
  const res = await query(
    `SELECT ${PATIENT_FIELDS},
            similarity(first_name || ' ' || last_name, $1) AS name_similarity
     FROM patients
     WHERE
       similarity(first_name || ' ' || last_name, $1) > 0.35
       OR ($2::date IS NOT NULL AND birth_date = $2)
       OR ($3::text IS NOT NULL AND $3 <> '' AND phone = $3)
     ORDER BY name_similarity DESC NULLS LAST
     LIMIT 10`,
    [fullName, birthDate, phone]
  );
  return res.rows;
}

/**
 * إنشاء مريضة ضمن Transaction موجود مسبقًا (client بدلاً من pool مباشرة).
 * رقم الملف الطبي يُولَّد تلقائيًا عبر Trigger في قاعدة البيانات.
 */
async function createWithClient(client, data) {
  const res = await client.query(
    `INSERT INTO patients (first_name, last_name, birth_date, phone, address, national_id, admin_notes, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     RETURNING ${PATIENT_FIELDS}`,
    [
      data.firstName,
      data.lastName,
      data.birthDate || null,
      data.phone || null,
      data.address || null,
      data.nationalId || null,
      data.adminNotes || null,
      data.createdBy || null,
    ]
  );
  return res.rows[0];
}

async function update(id, data) {
  const res = await query(
    `UPDATE patients SET
        first_name   = COALESCE($2, first_name),
        last_name    = COALESCE($3, last_name),
        birth_date   = COALESCE($4, birth_date),
        phone        = COALESCE($5, phone),
        address      = COALESCE($6, address),
        national_id  = COALESCE($7, national_id),
        admin_notes  = COALESCE($8, admin_notes),
        updated_at   = NOW()
     WHERE id = $1
     RETURNING ${PATIENT_FIELDS}`,
    [
      id,
      data.firstName,
      data.lastName,
      data.birthDate,
      data.phone,
      data.address,
      data.nationalId,
      data.adminNotes,
    ]
  );
  return res.rows[0] || null;
}

async function countAll() {
  const res = await query('SELECT COUNT(*)::int AS count FROM patients');
  return res.rows[0].count;
}

/**
 * حذف مريضة نهائيًا. إذا كانت لديها زيارات مسجّلة، قاعدة البيانات تمنع الحذف
 * (visits.patient_id ON DELETE RESTRICT) للحفاظ على السجل الطبي — يُعالَج هذا
 * في الـ Controller برسالة عربية واضحة بدل خطأ تقني.
 */
async function remove(id) {
  const res = await query('DELETE FROM patients WHERE id = $1 RETURNING id', [id]);
  return res.rowCount > 0;
}

module.exports = {
  search,
  findById,
  findByMedicalFileNumber,
  findPossibleDuplicates,
  createWithClient,
  update,
  countAll,
  remove,
};
