'use strict';

const { query } = require('../config/db');

const VISIT_FIELDS = `
  id, patient_id, visit_date, booked_at, status, visit_type,
  doctor_id, created_by, reception_notes, updated_at,
  with_doctor_started_at, with_doctor_ended_at
`;

async function createWithClient(client, { patientId, visitType = 'GENERAL', createdBy, status = 'BOOKED' }) {
  const res = await client.query(
    `INSERT INTO visits (patient_id, visit_type, created_by, status)
     VALUES ($1, $2, $3, $4)
     RETURNING ${VISIT_FIELDS}`,
    [patientId, visitType, createdBy, status]
  );
  return res.rows[0];
}

async function findById(id) {
  const res = await query(`SELECT ${VISIT_FIELDS} FROM visits WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

/**
 * يبحث عن زيارة نشطة اليوم لنفس المريضة (ليست ملغاة أو "لم تحضر").
 * يُستخدم لمنع الحجز المزدوج في نفس اليوم.
 */
async function findTodayActiveByPatient(patientId) {
  const res = await query(
    `SELECT ${VISIT_FIELDS} FROM visits
     WHERE patient_id = $1
       AND visit_date = CURRENT_DATE
       AND status NOT IN ('CANCELLED', 'NO_SHOW')
     LIMIT 1`,
    [patientId]
  );
  return res.rows[0] || null;
}

async function updateStatus(id, status) {
  const res = await query(
    `UPDATE visits SET status = $2, updated_at = NOW() WHERE id = $1 RETURNING ${VISIT_FIELDS}`,
    [id, status]
  );
  return res.rows[0] || null;
}

async function updateVisitType(id, visitType) {
  const res = await query(
    `UPDATE visits SET visit_type = $2, updated_at = NOW() WHERE id = $1 RETURNING ${VISIT_FIELDS}`,
    [id, visitType]
  );
  return res.rows[0] || null;
}

/**
 * يسجّل لحظة دخول المريضة فعليًا للفحص (بداية حساب المدة الفعلية للاستشارة).
 */
async function markWithDoctorStarted(id) {
  const res = await query(
    `UPDATE visits SET with_doctor_started_at = NOW(), updated_at = NOW() WHERE id = $1 RETURNING ${VISIT_FIELDS}`,
    [id]
  );
  return res.rows[0] || null;
}

/**
 * يسجّل لحظة انتهاء الفحص فعليًا (نهاية حساب المدة الفعلية للاستشارة).
 */
async function markWithDoctorEnded(id) {
  const res = await query(
    `UPDATE visits SET with_doctor_ended_at = NOW(), updated_at = NOW() WHERE id = $1 RETURNING ${VISIT_FIELDS}`,
    [id]
  );
  return res.rows[0] || null;
}

async function findAllByPatientId(patientId) {
  const res = await query(
    `SELECT ${VISIT_FIELDS} FROM visits
     WHERE patient_id = $1
     ORDER BY visit_date DESC, booked_at DESC`,
    [patientId]
  );
  return res.rows;
}

async function countAll() {
  const res = await query('SELECT COUNT(*)::int AS count FROM visits');
  return res.rows[0].count;
}

async function countToday() {
  const res = await query("SELECT COUNT(*)::int AS count FROM visits WHERE visit_date = CURRENT_DATE");
  return res.rows[0].count;
}

/**
 * آخر زيارة غير ملغاة للمريضة (يُستخدم لتحديد "نوع الزيارة" الافتراضي في الحجز/الفحص التالي،
 * ولبطاقة الملخص الطبي عند بدء الفحص).
 */
async function findLastByPatient(patientId, excludeVisitId = null) {
  const res = await query(
    `SELECT ${VISIT_FIELDS} FROM visits
     WHERE patient_id = $1 AND status <> 'CANCELLED'
       AND ($2::int IS NULL OR id <> $2)
     ORDER BY visit_date DESC, booked_at DESC
     LIMIT 1`,
    [patientId, excludeVisitId]
  );
  return res.rows[0] || null;
}

/**
 * آخر N زيارات للمريضة (باستثناء الزيارة الحالية) التي لديها قياسات مسجّلة (وزن/ضغط/سكر) —
 * تُستخدم في جدول "آخر ثلاث قياسات" ببطاقة الملخص الطبي.
 */
async function findRecentVisitsWithMeasurements(patientId, excludeVisitId, limit = 3) {
  const res = await query(
    `SELECT v.id AS visit_id, v.visit_date, mh.reception_measurements
     FROM visits v
     JOIN medical_history mh ON mh.visit_id = v.id
     WHERE v.patient_id = $1
       AND v.id <> $2
       AND v.status <> 'CANCELLED'
       AND mh.reception_measurements IS NOT NULL
     ORDER BY v.visit_date DESC, v.booked_at DESC
     LIMIT $3`,
    [patientId, excludeVisitId, limit]
  );
  return res.rows;
}

/**
 * آخر ملاحظة طبية مسجّلة للمريضة (باستثناء الزيارة الحالية) — لبطاقة الملخص الطبي.
 */
async function findLastMedicalNote(patientId, excludeVisitId) {
  const res = await query(
    `SELECT mh.examination_notes, v.visit_date
     FROM medical_history mh
     JOIN visits v ON v.id = mh.visit_id
     WHERE v.patient_id = $1 AND v.id <> $2
       AND mh.examination_notes IS NOT NULL AND mh.examination_notes <> ''
     ORDER BY v.visit_date DESC, v.booked_at DESC
     LIMIT 1`,
    [patientId, excludeVisitId]
  );
  return res.rows[0] || null;
}

module.exports = {
  createWithClient,
  findById,
  findTodayActiveByPatient,
  updateStatus,
  updateVisitType,
  findAllByPatientId,
  countAll,
  findLastByPatient,
  findRecentVisitsWithMeasurements,
  findLastMedicalNote,
  countToday,
  markWithDoctorStarted,
  markWithDoctorEnded,
};
