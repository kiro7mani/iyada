'use strict';

const { query } = require('../config/db');

const FIELDS = `
  pv.id, pv.pregnancy_id, pv.visit_id, pv.gestational_age_weeks, pv.weight,
  pv.blood_pressure, pv.blood_sugar, pv.lab_summary, pv.ultrasound_summary,
  pv.medications, pv.supplements, pv.notes
`;

async function create({
  pregnancyId,
  visitId,
  gestationalAgeWeeks,
  weight,
  bloodPressure,
  bloodSugar,
  labSummary,
  ultrasoundSummary,
  medications,
  supplements,
  notes,
}) {
  const res = await query(
    `INSERT INTO pregnancy_visits
        (pregnancy_id, visit_id, gestational_age_weeks, weight, blood_pressure, blood_sugar,
         lab_summary, ultrasound_summary, medications, supplements, notes)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
     RETURNING ${FIELDS.replace(/pv\./g, '')}`,
    [
      pregnancyId,
      visitId,
      gestationalAgeWeeks || null,
      weight || null,
      bloodPressure || null,
      bloodSugar || null,
      labSummary || null,
      ultrasoundSummary || null,
      medications || null,
      supplements || null,
      notes || null,
    ]
  );
  return res.rows[0];
}

async function findByVisitId(visitId) {
  const res = await query(
    `SELECT ${FIELDS.replace(/pv\./g, '')} FROM pregnancy_visits WHERE visit_id = $1`,
    [visitId]
  );
  return res.rows[0] || null;
}

/**
 * الخط الزمني الكامل لحمل معيّن، مرتّبًا بتاريخ الزيارة الفعلي.
 */
async function findTimelineByPregnancyId(pregnancyId) {
  const res = await query(
    `SELECT ${FIELDS}, v.visit_date, v.booked_at
     FROM pregnancy_visits pv
     JOIN visits v ON v.id = pv.visit_id
     WHERE pv.pregnancy_id = $1
     ORDER BY v.visit_date ASC, v.booked_at ASC`,
    [pregnancyId]
  );
  return res.rows;
}

module.exports = { create, findByVisitId, findTimelineByPregnancyId };
