'use strict';

const { query } = require('../config/db');

async function create({ filePath, title, category, durationSeconds, uploadedBy }) {
  const res = await query(
    `INSERT INTO tv_media (file_path, title, category, duration_seconds, uploaded_by)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, file_path, title, category, duration_seconds, uploaded_by, created_at`,
    [filePath, title, category || null, durationSeconds || null, uploadedBy || null]
  );
  return res.rows[0];
}

async function findAll() {
  const res = await query(
    'SELECT id, file_path, title, category, duration_seconds, uploaded_by, created_at FROM tv_media ORDER BY created_at DESC'
  );
  return res.rows;
}

async function findById(id) {
  const res = await query(
    'SELECT id, file_path, title, category, duration_seconds, uploaded_by, created_at FROM tv_media WHERE id = $1',
    [id]
  );
  return res.rows[0] || null;
}

async function remove(id) {
  const res = await query('DELETE FROM tv_media WHERE id = $1 RETURNING file_path', [id]);
  return res.rows[0] || null;
}

module.exports = { create, findAll, findById, remove };
