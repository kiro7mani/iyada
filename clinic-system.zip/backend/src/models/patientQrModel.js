'use strict';

const { query } = require('../config/db');

async function createWithClient(client, patientId, token) {
  const res = await client.query(
    `INSERT INTO patient_qr (patient_id, token)
     VALUES ($1, $2)
     RETURNING id, patient_id, token, created_at`,
    [patientId, token]
  );
  return res.rows[0];
}

async function findByPatientId(patientId) {
  const res = await query('SELECT id, patient_id, token, created_at FROM patient_qr WHERE patient_id = $1', [
    patientId,
  ]);
  return res.rows[0] || null;
}

async function findByToken(token) {
  const res = await query(
    `SELECT p.id, p.medical_file_number, p.first_name, p.last_name, p.birth_date,
            p.phone, p.address, p.national_id, p.admin_notes, p.created_at, p.updated_at,
            q.token AS qr_token
     FROM patient_qr q
     JOIN patients p ON p.id = q.patient_id
     WHERE q.token = $1`,
    [token]
  );
  return res.rows[0] || null;
}

module.exports = { createWithClient, findByPatientId, findByToken };
