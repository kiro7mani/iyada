'use strict';

const { query } = require('../config/db');

async function getStatus() {
  const res = await query(
    'SELECT id, is_on_break, started_at, updated_at FROM doctor_break_status ORDER BY id LIMIT 1'
  );
  return res.rows[0] || { is_on_break: false, started_at: null };
}

async function setBreak(isOnBreak) {
  const current = await getStatus();
  if (!current.id) {
    // احتياطًا: لو لم يوجد السجل الافتراضي لأي سبب، ننشئه الآن
    const res = await query(
      'INSERT INTO doctor_break_status (is_on_break, started_at) VALUES ($1, $2) RETURNING id, is_on_break, started_at, updated_at',
      [isOnBreak, isOnBreak ? new Date() : null]
    );
    return res.rows[0];
  }
  const res = await query(
    `UPDATE doctor_break_status
     SET is_on_break = $2, started_at = $3, updated_at = NOW()
     WHERE id = $1
     RETURNING id, is_on_break, started_at, updated_at`,
    [current.id, isOnBreak, isOnBreak ? new Date() : null]
  );
  return res.rows[0];
}

module.exports = { getStatus, setBreak };
