'use strict';

const { query } = require('../config/db');

async function createWithClient(client, { visitId, createdBy }) {
  const res = await client.query(
    `INSERT INTO prescriptions (visit_id, created_by) VALUES ($1, $2)
     RETURNING id, visit_id, created_by, created_at`,
    [visitId, createdBy]
  );
  return res.rows[0];
}

async function addItemWithClient(client, { prescriptionId, medicationName, dosage, frequency, quantity, duration, instructions }) {
  const res = await client.query(
    `INSERT INTO prescription_items (prescription_id, medication_name, dosage, frequency, quantity, duration, instructions)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id, prescription_id, medication_name, dosage, frequency, quantity, duration, instructions`,
    [
      prescriptionId,
      medicationName,
      dosage || null,
      frequency || null,
      quantity || null,
      duration || null,
      instructions || null,
    ]
  );
  return res.rows[0];
}

async function findByVisitId(visitId) {
  const prescriptionsRes = await query(
    'SELECT id, visit_id, created_by, created_at FROM prescriptions WHERE visit_id = $1 ORDER BY created_at DESC',
    [visitId]
  );
  const prescriptions = prescriptionsRes.rows;
  if (prescriptions.length === 0) return [];

  const ids = prescriptions.map((p) => p.id);
  const itemsRes = await query(
    `SELECT id, prescription_id, medication_name, dosage, frequency, quantity, duration, instructions
     FROM prescription_items WHERE prescription_id = ANY($1::int[])`,
    [ids]
  );

  return prescriptions.map((p) => ({
    ...p,
    items: itemsRes.rows.filter((i) => i.prescription_id === p.id),
  }));
}

async function findById(id) {
  const prescriptionRes = await query(
    `SELECT p.id, p.visit_id, p.created_by, p.created_at, v.patient_id
     FROM prescriptions p
     JOIN visits v ON v.id = p.visit_id
     WHERE p.id = $1`,
    [id]
  );
  const prescription = prescriptionRes.rows[0];
  if (!prescription) return null;

  const itemsRes = await query(
    `SELECT id, medication_name, dosage, frequency, quantity, duration, instructions
     FROM prescription_items WHERE prescription_id = $1 ORDER BY id ASC`,
    [id]
  );

  return { ...prescription, items: itemsRes.rows };
}

/**
 * آخر وصفة (مع أدويتها) سجّلتها المريضة في زيارة سابقة — لبطاقة الملخص الطبي.
 */
async function findLastForPatient(patientId, excludeVisitId) {
  const prescriptionRes = await query(
    `SELECT p.id, p.visit_id, p.created_at
     FROM prescriptions p
     JOIN visits v ON v.id = p.visit_id
     WHERE v.patient_id = $1 AND v.id <> $2
     ORDER BY p.created_at DESC
     LIMIT 1`,
    [patientId, excludeVisitId]
  );
  const prescription = prescriptionRes.rows[0];
  if (!prescription) return null;

  const itemsRes = await query(
    `SELECT medication_name, dosage, frequency, quantity, duration FROM prescription_items
     WHERE prescription_id = $1 ORDER BY id ASC`,
    [prescription.id]
  );
  return { ...prescription, items: itemsRes.rows };
}

module.exports = { createWithClient, addItemWithClient, findByVisitId, findById, findLastForPatient };
