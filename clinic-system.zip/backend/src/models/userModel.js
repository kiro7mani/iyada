'use strict';

const { query } = require('../config/db');

const PUBLIC_FIELDS = `
  u.id, u.full_name, u.username, u.is_active, u.created_at, u.updated_at,
  r.id AS role_id, r.name AS role_name
`;

async function findByUsername(username) {
  const res = await query(
    `SELECT u.id, u.full_name, u.username, u.password_hash, u.is_active,
            r.id AS role_id, r.name AS role_name, r.permissions
     FROM users u
     JOIN roles r ON r.id = u.role_id
     WHERE u.username = $1`,
    [username]
  );
  return res.rows[0] || null;
}

async function findById(id) {
  const res = await query(
    `SELECT ${PUBLIC_FIELDS}
     FROM users u
     JOIN roles r ON r.id = u.role_id
     WHERE u.id = $1`,
    [id]
  );
  return res.rows[0] || null;
}

async function findAll() {
  const res = await query(
    `SELECT ${PUBLIC_FIELDS}
     FROM users u
     JOIN roles r ON r.id = u.role_id
     ORDER BY u.created_at DESC`
  );
  return res.rows;
}

async function create({ fullName, username, passwordHash, roleId }) {
  const res = await query(
    `INSERT INTO users (full_name, username, password_hash, role_id)
     VALUES ($1, $2, $3, $4)
     RETURNING id, full_name, username, role_id, is_active, created_at`,
    [fullName, username, passwordHash, roleId]
  );
  return res.rows[0];
}

async function updateProfile(id, { fullName, roleId }) {
  const res = await query(
    `UPDATE users
     SET full_name = COALESCE($2, full_name),
         role_id = COALESCE($3, role_id),
         updated_at = NOW()
     WHERE id = $1
     RETURNING id, full_name, username, role_id, is_active`,
    [id, fullName, roleId]
  );
  return res.rows[0] || null;
}

async function updatePassword(id, passwordHash) {
  await query('UPDATE users SET password_hash = $2, updated_at = NOW() WHERE id = $1', [
    id,
    passwordHash,
  ]);
}

async function setActive(id, isActive) {
  const res = await query(
    `UPDATE users SET is_active = $2, updated_at = NOW()
     WHERE id = $1
     RETURNING id, full_name, username, is_active`,
    [id, isActive]
  );
  return res.rows[0] || null;
}

async function usernameExists(username) {
  const res = await query('SELECT 1 FROM users WHERE username = $1', [username]);
  return res.rowCount > 0;
}

async function remove(id) {
  const res = await query('DELETE FROM users WHERE id = $1 RETURNING id', [id]);
  return res.rowCount > 0;
}

module.exports = {
  findByUsername,
  findById,
  findAll,
  create,
  updateProfile,
  updatePassword,
  setActive,
  usernameExists,
  remove,
};
