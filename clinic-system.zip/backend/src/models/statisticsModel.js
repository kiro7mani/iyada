'use strict';

const { query } = require('../config/db');

/**
 * تركيبة المريضات خلال فترة: إجمالي، جدد، سابقون، دائمون (بناءً على عدد الزيارات مدى الحياة).
 * "الجديدة" = أول زيارة غير ملغاة لها في تاريخ العيادة بأكمله وقعت ضمن هذه الفترة.
 */
async function getPeriodPatientComposition(from, to, loyaltyThreshold) {
  const res = await query(
    `WITH period_patients AS (
       SELECT DISTINCT patient_id FROM visits
       WHERE visit_date BETWEEN $1 AND $2 AND status <> 'CANCELLED'
     ),
     first_visit AS (
       SELECT patient_id, MIN(visit_date) AS first_date
       FROM visits WHERE status <> 'CANCELLED'
       GROUP BY patient_id
     ),
     lifetime_counts AS (
       SELECT patient_id, COUNT(*) AS total_visits
       FROM visits WHERE status <> 'CANCELLED'
       GROUP BY patient_id
     )
     SELECT
       COUNT(*)::int AS total_patients,
       COUNT(*) FILTER (WHERE fv.first_date BETWEEN $1 AND $2)::int AS new_patients,
       COUNT(*) FILTER (WHERE fv.first_date < $1)::int AS returning_patients,
       COUNT(*) FILTER (WHERE lc.total_visits >= $3)::int AS loyal_patients
     FROM period_patients pp
     JOIN first_visit fv ON fv.patient_id = pp.patient_id
     JOIN lifetime_counts lc ON lc.patient_id = pp.patient_id`,
    [from, to, loyaltyThreshold]
  );
  return res.rows[0];
}

/**
 * عدد الزيارات حسب النوع (فحص عام / متابعة حمل)، عدد الأشعة/الإيكوغرافي، وعدد الوصفات خلال الفترة.
 */
async function getPeriodActivityCounts(from, to) {
  const visitsRes = await query(
    `SELECT
       COUNT(*) FILTER (WHERE visit_type = 'GENERAL' AND status <> 'CANCELLED')::int AS general_exams,
       COUNT(*) FILTER (WHERE visit_type = 'PREGNANCY' AND status <> 'CANCELLED')::int AS pregnancy_visits,
       COUNT(*) FILTER (WHERE status = 'CANCELLED')::int AS cancelled_visits,
       COUNT(*) FILTER (WHERE status = 'NO_SHOW')::int AS no_show_visits
     FROM visits WHERE visit_date BETWEEN $1 AND $2`,
    [from, to]
  );

  const radiologyRes = await query(
    `SELECT COUNT(*)::int AS ultrasound_count FROM radiology WHERE created_at::date BETWEEN $1 AND $2`,
    [from, to]
  );

  const prescriptionsRes = await query(
    `SELECT COUNT(*)::int AS prescriptions_count FROM prescriptions WHERE created_at::date BETWEEN $1 AND $2`,
    [from, to]
  );

  return {
    ...visitsRes.rows[0],
    ...radiologyRes.rows[0],
    ...prescriptionsRes.rows[0],
  };
}

/**
 * الملخص المالي: عدد الزيارات المدفوعة/غير المدفوعة، المجموع الفرعي، التخفيضات، وصافي الإيراد.
 * الحساب مبني على تاريخ الزيارة (visit_date) لا تاريخ الدفع، لتبقى كل الأرقام متسقة مع نفس الفترة.
 */
async function getPeriodFinancialSummary(from, to) {
  const res = await query(
    `WITH visit_totals AS (
       SELECT v.id AS visit_id, v.status,
              COALESCE(d.subtotal, vs_sum.subtotal, 0) AS subtotal,
              COALESCE(d.total, vs_sum.subtotal, 0) AS total
       FROM visits v
       LEFT JOIN discounts d ON d.visit_id = v.id
       LEFT JOIN (
         SELECT visit_id, SUM(price) AS subtotal FROM visit_services GROUP BY visit_id
       ) vs_sum ON vs_sum.visit_id = v.id
       WHERE v.visit_date BETWEEN $1 AND $2
     )
     SELECT
       COUNT(*) FILTER (WHERE status = 'COMPLETED')::int AS paid_visits_count,
       COUNT(*) FILTER (WHERE status = 'AWAITING_PAYMENT')::int AS unpaid_visits_count,
       COALESCE(SUM(subtotal) FILTER (WHERE status = 'COMPLETED'), 0) AS total_subtotal,
       COALESCE(SUM(subtotal - total) FILTER (WHERE status = 'COMPLETED'), 0) AS total_discounts,
       COALESCE(SUM(total) FILTER (WHERE status = 'COMPLETED'), 0) AS net_revenue
     FROM visit_totals`,
    [from, to]
  );
  return res.rows[0];
}

async function getPaymentMethodBreakdown(from, to) {
  const res = await query(
    `SELECT method, COUNT(*)::int AS count, COALESCE(SUM(amount), 0) AS total
     FROM payments
     WHERE paid_at::date BETWEEN $1 AND $2
     GROUP BY method`,
    [from, to]
  );
  return res.rows;
}

async function getTopServices(from, to, limit = 10) {
  const res = await query(
    `SELECT s.name, COUNT(*)::int AS count, COALESCE(SUM(vs.price), 0) AS total
     FROM visit_services vs
     JOIN services s ON s.id = vs.service_id
     JOIN visits v ON v.id = vs.visit_id
     WHERE v.visit_date BETWEEN $1 AND $2
     GROUP BY s.name
     ORDER BY count DESC
     LIMIT $3`,
    [from, to, limit]
  );
  return res.rows;
}

/**
 * قائمة المريضات الدائمات (القسم 46): الاسم، رقم الملف، عدد الزيارات، آخر زيارة، هل حامل، آخر متابعة حمل.
 */
async function getLoyalPatients(threshold) {
  const res = await query(
    `SELECT
       p.id, p.medical_file_number, p.first_name, p.last_name,
       COUNT(v.id) FILTER (WHERE v.status <> 'CANCELLED')::int AS visit_count,
       MAX(v.visit_date) AS last_visit_date,
       EXISTS(SELECT 1 FROM pregnancies pr WHERE pr.patient_id = p.id AND pr.status = 'ACTIVE') AS is_pregnant,
       (
         SELECT MAX(vv.visit_date)
         FROM pregnancy_visits pvv
         JOIN visits vv ON vv.id = pvv.visit_id
         JOIN pregnancies prr ON prr.id = pvv.pregnancy_id
         WHERE prr.patient_id = p.id
       ) AS last_pregnancy_visit_date
     FROM patients p
     JOIN visits v ON v.patient_id = p.id
     GROUP BY p.id
     HAVING COUNT(v.id) FILTER (WHERE v.status <> 'CANCELLED') >= $1
     ORDER BY visit_count DESC`,
    [threshold]
  );
  return res.rows;
}

module.exports = {
  getPeriodPatientComposition,
  getPeriodActivityCounts,
  getPeriodFinancialSummary,
  getPaymentMethodBreakdown,
  getTopServices,
  getLoyalPatients,
};
