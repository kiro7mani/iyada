'use strict';

const { query } = require('../config/db');

/**
 * ينشئ سجل انتظار يومي جديد للزيارة، برقم تسلسلي فريد ضمن نفس اليوم فقط.
 * يستخدم pg_advisory_xact_lock مبنيًا على تاريخ اليوم لمنع تعارض الأرقام
 * عند حجزين متزامنين من جهازين مختلفين (استقبال + إنشاء تلقائي مثلاً).
 * القفل يُحرَّر تلقائيًا عند نهاية الـ Transaction (COMMIT/ROLLBACK).
 */
async function createWithClient(client, visitId) {
  await client.query("SELECT pg_advisory_xact_lock(hashtext(CURRENT_DATE::text))");

  const nextNumberRes = await client.query(
    `SELECT COALESCE(MAX(queue_number), 0) + 1 AS next_number
     FROM daily_queue
     WHERE queue_date = CURRENT_DATE`
  );
  const nextNumber = nextNumberRes.rows[0].next_number;

  const res = await client.query(
    `INSERT INTO daily_queue (visit_id, queue_date, queue_number)
     VALUES ($1, CURRENT_DATE, $2)
     RETURNING id, visit_id, queue_date, queue_number, called_at, recalled_count`,
    [visitId, nextNumber]
  );
  return res.rows[0];
}

async function findByVisitId(visitId) {
  const res = await query(
    'SELECT id, visit_id, queue_date, queue_number, called_at, recalled_count FROM daily_queue WHERE visit_id = $1',
    [visitId]
  );
  return res.rows[0] || null;
}

/**
 * قائمة انتظار اليوم كاملة، مرتبة برقم الانتظار، مع بيانات المريضة والزيارة.
 */
async function findTodayQueue() {
  const res = await query(
    `SELECT
        dq.queue_number, dq.called_at, dq.recalled_count,
        v.id AS visit_id, v.status, v.visit_type, v.booked_at,
        v.with_doctor_started_at, v.with_doctor_ended_at,
        p.id AS patient_id, p.medical_file_number, p.first_name, p.last_name
     FROM daily_queue dq
     JOIN visits v ON v.id = dq.visit_id
     JOIN patients p ON p.id = v.patient_id
     WHERE dq.queue_date = CURRENT_DATE
     ORDER BY dq.queue_number ASC`
  );
  return res.rows;
}

/**
 * أول مريضة بحالة WAITING اليوم (حسب رقم الانتظار) — تُستخدم في "استدعاء التالية".
 */
async function findNextWaiting() {
  const res = await query(
    `SELECT dq.queue_number, dq.visit_id, v.status,
            p.first_name, p.last_name, p.medical_file_number
     FROM daily_queue dq
     JOIN visits v ON v.id = dq.visit_id
     JOIN patients p ON p.id = v.patient_id
     WHERE dq.queue_date = CURRENT_DATE AND v.status = 'WAITING'
     ORDER BY dq.queue_number ASC
     LIMIT 1`
  );
  return res.rows[0] || null;
}

async function setCalledAt(visitId) {
  const res = await query(
    `UPDATE daily_queue SET called_at = NOW() WHERE visit_id = $1
     RETURNING id, visit_id, queue_date, queue_number, called_at, recalled_count`,
    [visitId]
  );
  return res.rows[0] || null;
}

async function incrementRecall(visitId) {
  const res = await query(
    `UPDATE daily_queue SET recalled_count = recalled_count + 1 WHERE visit_id = $1
     RETURNING id, visit_id, queue_date, queue_number, called_at, recalled_count`,
    [visitId]
  );
  return res.rows[0] || null;
}

module.exports = {
  createWithClient,
  findByVisitId,
  findTodayQueue,
  findNextWaiting,
  setCalledAt,
  incrementRecall,
};
