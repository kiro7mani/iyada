'use strict';

const { query, withTransaction } = require('../config/db');

async function findAll() {
  const res = await query('SELECT id, name, is_default FROM tv_playlists ORDER BY id');
  return res.rows;
}

async function findById(id) {
  const res = await query('SELECT id, name, is_default FROM tv_playlists WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function findDefault() {
  const res = await query('SELECT id, name, is_default FROM tv_playlists WHERE is_default = TRUE LIMIT 1');
  return res.rows[0] || null;
}

/**
 * ينشئ Playlist جديدة. إذا كانت isDefault=true، تُلغى الافتراضية من أي Playlist أخرى ضمن نفس الـ Transaction.
 */
async function create({ name, isDefault = false }) {
  return withTransaction(async (client) => {
    if (isDefault) {
      await client.query('UPDATE tv_playlists SET is_default = FALSE WHERE is_default = TRUE');
    }
    const res = await client.query(
      'INSERT INTO tv_playlists (name, is_default) VALUES ($1, $2) RETURNING id, name, is_default',
      [name, isDefault]
    );
    return res.rows[0];
  });
}

async function setDefault(id) {
  return withTransaction(async (client) => {
    await client.query('UPDATE tv_playlists SET is_default = FALSE WHERE is_default = TRUE');
    const res = await client.query(
      'UPDATE tv_playlists SET is_default = TRUE WHERE id = $1 RETURNING id, name, is_default',
      [id]
    );
    return res.rows[0] || null;
  });
}

async function addItem(playlistId, mediaId, orderIndex) {
  const res = await query(
    `INSERT INTO tv_playlist_items (playlist_id, media_id, order_index)
     VALUES ($1, $2, $3)
     RETURNING id, playlist_id, media_id, order_index`,
    [playlistId, mediaId, orderIndex || 0]
  );
  return res.rows[0];
}

async function removeItem(itemId, playlistId) {
  const res = await query(
    'DELETE FROM tv_playlist_items WHERE id = $1 AND playlist_id = $2 RETURNING id',
    [itemId, playlistId]
  );
  return res.rowCount > 0;
}

async function findItemsByPlaylistId(playlistId) {
  const res = await query(
    `SELECT pi.id, pi.order_index, m.id AS media_id, m.file_path, m.title, m.duration_seconds
     FROM tv_playlist_items pi
     JOIN tv_media m ON m.id = pi.media_id
     WHERE pi.playlist_id = $1
     ORDER BY pi.order_index ASC, pi.id ASC`,
    [playlistId]
  );
  return res.rows;
}

module.exports = {
  findAll,
  findById,
  findDefault,
  create,
  setDefault,
  addItem,
  removeItem,
  findItemsByPlaylistId,
};
