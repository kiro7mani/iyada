'use strict';

const { query } = require('../config/db');

async function create({ queueNumber, visitId, type }) {
  const res = await query(
    `INSERT INTO tv_announcements (queue_number, visit_id, type)
     VALUES ($1, $2, $3)
     RETURNING id, queue_number, visit_id, announced_at, type`,
    [queueNumber, visitId, type]
  );
  return res.rows[0];
}

module.exports = { create };
