'use strict';

const { query } = require('../config/db');

const FIELDS = `
  id, start_time, end_time, playlist_id, show_clock, show_weather, show_logo,
  call_volume, call_repeat_count
`;

async function findAll() {
  const res = await query(
    `SELECT ts.*, p.name AS playlist_name
     FROM tv_settings ts
     LEFT JOIN tv_playlists p ON p.id = ts.playlist_id
     ORDER BY ts.start_time`
  );
  return res.rows;
}

async function findById(id) {
  const res = await query(`SELECT ${FIELDS} FROM tv_settings WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

async function create({
  startTime,
  endTime,
  playlistId,
  showClock,
  showWeather,
  showLogo,
  callVolume,
  callRepeatCount,
}) {
  const res = await query(
    `INSERT INTO tv_settings (start_time, end_time, playlist_id, show_clock, show_weather, show_logo, call_volume, call_repeat_count)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     RETURNING ${FIELDS}`,
    [
      startTime,
      endTime,
      playlistId,
      showClock !== undefined ? showClock : true,
      showWeather !== undefined ? showWeather : true,
      showLogo !== undefined ? showLogo : true,
      callVolume !== undefined ? callVolume : 80,
      callRepeatCount !== undefined ? callRepeatCount : 2,
    ]
  );
  return res.rows[0];
}

async function update(id, fields) {
  const res = await query(
    `UPDATE tv_settings SET
        start_time = COALESCE($2, start_time),
        end_time = COALESCE($3, end_time),
        playlist_id = COALESCE($4, playlist_id),
        show_clock = COALESCE($5, show_clock),
        show_weather = COALESCE($6, show_weather),
        show_logo = COALESCE($7, show_logo),
        call_volume = COALESCE($8, call_volume),
        call_repeat_count = COALESCE($9, call_repeat_count)
     WHERE id = $1
     RETURNING ${FIELDS}`,
    [
      id,
      fields.startTime,
      fields.endTime,
      fields.playlistId,
      fields.showClock,
      fields.showWeather,
      fields.showLogo,
      fields.callVolume,
      fields.callRepeatCount,
    ]
  );
  return res.rows[0] || null;
}

async function remove(id) {
  const res = await query('DELETE FROM tv_settings WHERE id = $1 RETURNING id', [id]);
  return res.rowCount > 0;
}

/**
 * يبحث عن جدولة العرض النشطة حاليًا بناءً على وقت الخادم (HH:MM:SS).
 * إن لم توجد جدولة مطابقة، يرجع null (يُستخدم عندها الإعداد الافتراضي في الخدمة).
 */
async function findActiveNow() {
  const res = await query(
    `SELECT ${FIELDS} FROM tv_settings
     WHERE start_time <= CURRENT_TIME AND end_time >= CURRENT_TIME
     ORDER BY start_time
     LIMIT 1`
  );
  return res.rows[0] || null;
}

module.exports = { findAll, findById, create, update, remove, findActiveNow };
