'use strict';

const { query } = require('../config/db');

async function findAll({ activeOnly = false } = {}) {
  const sql = activeOnly
    ? 'SELECT id, name, is_active FROM medications WHERE is_active = TRUE ORDER BY name'
    : 'SELECT id, name, is_active FROM medications ORDER BY name';
  const res = await query(sql);
  return res.rows;
}

async function findById(id) {
  const res = await query('SELECT id, name, is_active FROM medications WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function search(q) {
  const res = await query(
    'SELECT id, name, is_active FROM medications WHERE name ILIKE $1 ORDER BY name LIMIT 20',
    [`%${q}%`]
  );
  return res.rows;
}

async function create({ name }) {
  const res = await query(
    'INSERT INTO medications (name) VALUES ($1) RETURNING id, name, is_active',
    [name]
  );
  return res.rows[0];
}

async function update(id, { name, isActive }) {
  const res = await query(
    `UPDATE medications SET
        name = COALESCE($2, name),
        is_active = COALESCE($3, is_active)
     WHERE id = $1
     RETURNING id, name, is_active`,
    [id, name, isActive]
  );
  return res.rows[0] || null;
}

async function remove(id) {
  const res = await query('DELETE FROM medications WHERE id = $1 RETURNING id', [id]);
  return res.rowCount > 0;
}

module.exports = { findAll, findById, search, create, update, remove };
