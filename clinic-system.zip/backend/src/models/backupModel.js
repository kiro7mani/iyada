'use strict';

const { query } = require('../config/db');

async function create({ filePath, type, sizeBytes }) {
  const res = await query(
    `INSERT INTO backups (file_path, type, size_bytes)
     VALUES ($1, $2, $3)
     RETURNING id, file_path, type, size_bytes, created_at`,
    [filePath, type, sizeBytes]
  );
  return res.rows[0];
}

async function findAll() {
  const res = await query(
    'SELECT id, file_path, type, size_bytes, created_at FROM backups ORDER BY created_at DESC'
  );
  return res.rows;
}

async function findById(id) {
  const res = await query('SELECT id, file_path, type, size_bytes, created_at FROM backups WHERE id = $1', [
    id,
  ]);
  return res.rows[0] || null;
}

async function count() {
  const res = await query('SELECT COUNT(*)::int AS count FROM backups');
  return res.rows[0].count;
}

module.exports = { create, findAll, findById, count };
