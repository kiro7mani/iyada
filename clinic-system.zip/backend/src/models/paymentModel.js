'use strict';

const { query } = require('../config/db');

async function create({ visitId, amount, method, receivedBy }) {
  const res = await query(
    `INSERT INTO payments (visit_id, amount, method, received_by)
     VALUES ($1, $2, $3, $4)
     RETURNING id, visit_id, amount, method, received_by, paid_at, receipt_number`,
    [visitId, amount, method, receivedBy]
  );
  return res.rows[0];
}

/**
 * كل دفعات الزيارة (قد تكون أكثر من دفعة واحدة عبر الزمن: سداد جزئي ثم سداد رصيد لاحقًا).
 */
async function findAllByVisitId(visitId) {
  const res = await query(
    `SELECT id, visit_id, amount, method, received_by, paid_at, receipt_number
     FROM payments WHERE visit_id = $1 ORDER BY paid_at DESC`,
    [visitId]
  );
  return res.rows;
}

/**
 * أحدث دفعة على هذه الزيارة (تُستخدم لطباعة آخر وصل).
 */
async function findByVisitId(visitId) {
  const res = await query(
    `SELECT id, visit_id, amount, method, received_by, paid_at, receipt_number
     FROM payments WHERE visit_id = $1 ORDER BY paid_at DESC LIMIT 1`,
    [visitId]
  );
  return res.rows[0] || null;
}

module.exports = { create, findAllByVisitId, findByVisitId };
