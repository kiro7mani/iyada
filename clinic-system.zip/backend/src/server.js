'use strict';

const http = require('http');
const { Server } = require('socket.io');

const env = require('./config/env');
const createApp = require('./app');
const { checkConnection } = require('./config/db');
const initSockets = require('./sockets');
const { startBackupScheduler } = require('./services/backupScheduler');

async function start() {
  try {
    await checkConnection();
    // eslint-disable-next-line no-console
    console.log('✔ الاتصال بقاعدة البيانات ناجح.');
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('✘ تعذر الاتصال بقاعدة البيانات:', err.message);
    process.exit(1);
  }

  const app = createApp();
  const httpServer = http.createServer(app);

  const io = new Server(httpServer, {
    cors: {
      origin: env.corsOrigins.length > 0 ? env.corsOrigins : true,
      credentials: true,
    },
  });
  initSockets(io);

  // إتاحة io لبقية التطبيق (controllers لاحقًا) عبر app.locals
  app.locals.io = io;

  httpServer.listen(env.port, () => {
    // eslint-disable-next-line no-console
    console.log(`🚀 الخادم يعمل على المنفذ ${env.port} (${env.nodeEnv})`);
  });

  startBackupScheduler();

  process.on('unhandledRejection', (err) => {
    // eslint-disable-next-line no-console
    console.error('Unhandled Rejection:', err);
  });
}

start();
