'use strict';

const userModel = require('../models/userModel');
const serviceModel = require('../models/serviceModel');
const tvMediaModel = require('../models/tvMediaModel');
const backupModel = require('../models/backupModel');
const patientModel = require('../models/patientModel');
const visitModel = require('../models/visitModel');
const statisticsModel = require('../models/statisticsModel');
const clinicSettingModel = require('../models/clinicSettingModel');
const asyncHandler = require('../utils/asyncHandler');

function toDateString(d) {
  return d.toISOString().slice(0, 10);
}

const getDashboard = asyncHandler(async (req, res) => {
  const today = toDateString(new Date());
  const clinicSettings = await clinicSettingModel.getAll();
  const loyaltyThreshold = parseInt(clinicSettings.loyalty_visit_threshold, 10) || 5;

  const [
    users,
    services,
    tvMedia,
    backupsCount,
    totalPatients,
    totalVisits,
    todayVisitsCount,
    todayPatients,
    todayFinancial,
  ] = await Promise.all([
    userModel.findAll(),
    serviceModel.findAll(),
    tvMediaModel.findAll(),
    backupModel.count(),
    patientModel.countAll(),
    visitModel.countAll(),
    visitModel.countToday(),
    statisticsModel.getPeriodPatientComposition(today, today, loyaltyThreshold),
    statisticsModel.getPeriodFinancialSummary(today, today),
  ]);

  res.json({
    success: true,
    data: {
      counts: {
        activeUsers: users.filter((u) => u.is_active).length,
        totalUsers: users.length,
        activeServices: services.filter((s) => s.is_active).length,
        totalServices: services.length,
        tvVideos: tvMedia.length,
        backups: backupsCount,
        totalPatients,
        totalVisits,
        todayVisitsCount,
      },
      today: {
        patients: todayPatients,
        financial: todayFinancial,
      },
    },
  });
});

module.exports = { getDashboard };
