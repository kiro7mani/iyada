'use strict';

const path = require('path');
const env = require('../config/env');
const visitModel = require('../models/visitModel');
const patientModel = require('../models/patientModel');
const radiologyModel = require('../models/radiologyModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const upload = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (!req.file) {
    throw new AppError('يجب رفع ملف (صورة أو PDF).', 422, 'FILE_REQUIRED');
  }

  const fileType = req.file.mimetype === 'application/pdf' ? 'pdf' : 'image';
  const relativePath = `radiology/${req.file.filename}`;

  const record = await radiologyModel.create({
    patientId: visit.patient_id,
    visitId,
    filePath: relativePath,
    fileType,
    reportText: req.body.reportText || null,
    notes: req.body.notes || null,
    uploadedBy: req.user.id,
  });

  await logAction({
    userId: req.user.id,
    action: 'UPLOAD_RADIOLOGY',
    recordType: 'radiology',
    recordId: record.id,
    details: { visitId: Number(visitId) },
  });

  res.status(201).json({ success: true, data: record });
});

const listByVisit = asyncHandler(async (req, res) => {
  const records = await radiologyModel.findByVisitId(req.params.id);
  res.json({ success: true, data: records });
});

const listByPatient = asyncHandler(async (req, res) => {
  const patient = await patientModel.findById(req.params.id);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }
  const records = await radiologyModel.findByPatientId(req.params.id);
  res.json({ success: true, data: records });
});

/**
 * يعرض الملف نفسه (صورة/PDF) — محمي بتسجيل الدخول، لا وصول مباشر بدون صلاحية.
 */
const getFile = asyncHandler(async (req, res) => {
  const record = await radiologyModel.findById(req.params.id);
  if (!record) {
    throw new AppError('الملف غير موجود.', 404, 'NOT_FOUND');
  }
  const absolutePath = path.resolve(env.uploads.dir, record.file_path);
  res.sendFile(absolutePath, (err) => {
    if (err && !res.headersSent) {
      res.status(404).json({ success: false, message: 'تعذر العثور على الملف على الخادم.', code: 'FILE_NOT_FOUND' });
    }
  });
});

module.exports = { upload, listByVisit, listByPatient, getFile };
