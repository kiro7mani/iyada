'use strict';

const clinicSettingModel = require('../models/clinicSettingModel');
const { logAction } = require('../utils/auditLog');
const asyncHandler = require('../utils/asyncHandler');

const getSettings = asyncHandler(async (req, res) => {
  const settings = await clinicSettingModel.getAll();
  res.json({ success: true, data: settings });
});

const updateSettings = asyncHandler(async (req, res) => {
  // req.body مثال: { clinic_name: "...", opening_time: "08:00", ... }
  const updated = await clinicSettingModel.upsertMany(req.body);

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_CLINIC_SETTINGS',
    recordType: 'clinic_settings',
    details: req.body,
  });

  res.json({ success: true, data: updated });
});

module.exports = { getSettings, updateSettings };
