'use strict';

const visitModel = require('../models/visitModel');
const patientModel = require('../models/patientModel');
const medicalHistoryModel = require('../models/medicalHistoryModel');
const pregnancyModel = require('../models/pregnancyModel');
const pregnancyVisitModel = require('../models/pregnancyVisitModel');
const fertilityTrackingModel = require('../models/fertilityTrackingModel');
const prescriptionModel = require('../models/prescriptionModel');
const { emitQueueUpdated } = require('../utils/socketEvents');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

function addDaysToDateString(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function daysBetween(dateStr, until = new Date()) {
  const start = new Date(dateStr);
  const diffMs = until.getTime() - start.getTime();
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

const getById = asyncHandler(async (req, res) => {
  const visit = await visitModel.findById(req.params.id);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  const patient = await patientModel.findById(visit.patient_id);
  const medicalHistory = await medicalHistoryModel.findByVisitId(visit.id);

  res.json({ success: true, data: { visit, patient, medicalHistory } });
});

/**
 * بطاقة الملخص الطبي (المرحلة الأولى من واجهة الطبيبة): آخر متابعة (حمل/إنجاب/روتيني)،
 * قياسات اليوم، آخر 3 قياسات سابقة، آخر ملاحظة طبية، آخر الأدوية الموصوفة.
 */
const getSummary = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  const patient = await patientModel.findById(visit.patient_id);

  const lastVisit = await visitModel.findLastByPatient(visit.patient_id, visitId);
  const todayMedicalHistory = await medicalHistoryModel.findByVisitId(visitId);

  // معلومات آخر متابعة حسب نوع آخر زيارة
  let lastFollowUp = null;
  if (lastVisit) {
    if (lastVisit.visit_type === 'PREGNANCY') {
      const pregnancies = await pregnancyModel.findByPatientId(visit.patient_id);
      const activePregnancy = pregnancies.find((p) => p.status === 'ACTIVE') || pregnancies[0];
      if (activePregnancy && activePregnancy.lmp_date) {
        const ageDays = daysBetween(activePregnancy.lmp_date);
        lastFollowUp = {
          type: 'PREGNANCY',
          lastVisitDate: lastVisit.visit_date,
          gestationalAgeWeeks: Math.floor(ageDays / 7),
          gestationalAgeExtraDays: ageDays % 7,
          eddDate: activePregnancy.edd_date,
        };
      }
    } else if (lastVisit.visit_type === 'FERTILITY') {
      const fertility = await fertilityTrackingModel.findByPatientId(visit.patient_id);
      if (fertility) {
        lastFollowUp = {
          type: 'FERTILITY',
          lastVisitDate: lastVisit.visit_date,
          dateType: fertility.date_type,
          referenceDate: fertility.reference_date,
          daysSince: daysBetween(fertility.reference_date),
        };
      }
    } else {
      lastFollowUp = { type: 'GENERAL', lastVisitDate: lastVisit.visit_date };
    }
  }

  const recentMeasurements = await visitModel.findRecentVisitsWithMeasurements(visit.patient_id, visitId, 3);
  const lastNote = await visitModel.findLastMedicalNote(visit.patient_id, visitId);
  const lastPrescription = await prescriptionModel.findLastForPatient(visit.patient_id, visitId);

  res.json({
    success: true,
    data: {
      patient,
      lastFollowUp,
      defaultVisitType: lastVisit ? lastVisit.visit_type : 'GENERAL',
      todayMeasurements: todayMedicalHistory ? todayMedicalHistory.reception_measurements : null,
      recentMeasurements,
      lastNote,
      lastPrescription,
    },
  });
});

/**
 * قياسات الاستقبال الأولية (كل حقل اختياري تمامًا بشكل فردي).
 */
const updateMeasurements = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const visit = await visitModel.findById(id);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }

  const { bloodPressure, bloodSugar, weight, notes } = req.body;
  const measurements = {};
  if (bloodPressure !== undefined && bloodPressure !== '') measurements.blood_pressure = bloodPressure;
  if (bloodSugar !== undefined && bloodSugar !== '') measurements.blood_sugar = bloodSugar;
  if (weight !== undefined && weight !== '') measurements.weight = weight;
  if (notes !== undefined && notes !== '') measurements.notes = notes;

  const record = await medicalHistoryModel.upsertMeasurements(id, measurements);

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_MEASUREMENTS',
    recordType: 'visits',
    recordId: Number(id),
  });

  res.json({ success: true, data: record });
});

/**
 * حفظ الفحص (بطاقة الفحص، المرحلة الثانية): نوع الزيارة + بيانات المتابعة المرتبطة +
 * الملاحظات. يُحدِّث نفس الزيارة الحالية في كل ضغطة "حفظ" (لا يُنشئ زيارة جديدة).
 */
const updateExamination = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const visit = await visitModel.findById(id);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (visit.status !== 'WITH_DOCTOR') {
    throw new AppError('يجب أن تكون المريضة قيد الفحص لإدخال بيانات الفحص.', 400, 'INVALID_STATUS');
  }

  const { visitType, examinationNotes, fertility, pregnancy } = req.body;

  if (visitType && visitType !== visit.visit_type) {
    await visitModel.updateVisitType(id, visitType);
  }

  if (visitType === 'FERTILITY' && fertility && fertility.dateType && fertility.referenceDate) {
    await fertilityTrackingModel.upsert(visit.patient_id, {
      dateType: fertility.dateType,
      referenceDate: fertility.referenceDate,
    });
  }

  if (visitType === 'PREGNANCY' && pregnancy && pregnancy.lmpDate) {
    const pregnancies = await pregnancyModel.findByPatientId(visit.patient_id);
    let activePregnancy = pregnancies.find((p) => p.status === 'ACTIVE');
    const eddDate = addDaysToDateString(pregnancy.lmpDate, 280);

    if (activePregnancy) {
      activePregnancy = await pregnancyModel.update(activePregnancy.id, {
        lmpDate: pregnancy.lmpDate,
        eddDate,
      });
    } else {
      activePregnancy = await pregnancyModel.create({
        patientId: visit.patient_id,
        lmpDate: pregnancy.lmpDate,
        eddDate,
      });
    }

    const existingPregnancyVisit = await pregnancyVisitModel.findByVisitId(id);
    if (!existingPregnancyVisit) {
      await pregnancyVisitModel.create({ pregnancyId: activePregnancy.id, visitId: id });
    }
  }

  const record = await medicalHistoryModel.upsertExamination(id, {
    reasonForVisit: null,
    examinationNotes,
    diagnosis: null,
    treatmentPlan: null,
    doctorNotes: null,
  });

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_EXAMINATION',
    recordType: 'visits',
    recordId: Number(id),
    details: { visitType },
  });

  res.json({ success: true, data: record });
});

const listByPatient = asyncHandler(async (req, res) => {
  const patient = await patientModel.findById(req.params.id);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }
  const visits = await visitModel.findAllByPatientId(req.params.id);
  res.json({ success: true, data: visits });
});

module.exports = { getById, getSummary, updateMeasurements, updateExamination, listByPatient };
