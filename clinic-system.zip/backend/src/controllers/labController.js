'use strict';

const path = require('path');
const env = require('../config/env');
const visitModel = require('../models/visitModel');
const patientModel = require('../models/patientModel');
const labResultModel = require('../models/labResultModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const create = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }

  const { testName, resultValue, unit, notes } = req.body;
  const filePath = req.file ? `labs/${req.file.filename}` : null;

  const record = await labResultModel.create({
    patientId: visit.patient_id,
    visitId,
    testName,
    resultValue,
    unit,
    notes,
    filePath,
  });

  await logAction({
    userId: req.user.id,
    action: 'ADD_LAB_RESULT',
    recordType: 'lab_results',
    recordId: record.id,
    details: { visitId: Number(visitId) },
  });

  res.status(201).json({ success: true, data: record });
});

const listByVisit = asyncHandler(async (req, res) => {
  const records = await labResultModel.findByVisitId(req.params.id);
  res.json({ success: true, data: records });
});

const listByPatient = asyncHandler(async (req, res) => {
  const patient = await patientModel.findById(req.params.id);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }
  const records = await labResultModel.findByPatientId(req.params.id);
  res.json({ success: true, data: records });
});

const getFile = asyncHandler(async (req, res) => {
  const record = await labResultModel.findById(req.params.id);
  if (!record || !record.file_path) {
    throw new AppError('الملف غير موجود.', 404, 'NOT_FOUND');
  }
  const absolutePath = path.resolve(env.uploads.dir, record.file_path);
  res.sendFile(absolutePath, (err) => {
    if (err && !res.headersSent) {
      res.status(404).json({ success: false, message: 'تعذر العثور على الملف على الخادم.', code: 'FILE_NOT_FOUND' });
    }
  });
});

module.exports = { create, listByVisit, listByPatient, getFile };
