'use strict';

const visitModel = require('../models/visitModel');
const patientModel = require('../models/patientModel');
const serviceModel = require('../models/serviceModel');
const visitServiceModel = require('../models/visitServiceModel');
const discountModel = require('../models/discountModel');
const paymentModel = require('../models/paymentModel');
const visitBillingModel = require('../models/visitBillingModel');
const clinicSettingModel = require('../models/clinicSettingModel');
const { generateReceiptPdf } = require('../services/receiptPdfService');
const { emitQueueUpdated } = require('../utils/socketEvents');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

/**
 * إضافة خدمة وسعرها إلى الزيارة. السعر يُحدَّد من الطبيبة حصريًا — تُضاف ضمن نافذة
 * "إنهاء الفحص" أثناء والزيارة لا تزال WITH_DOCTOR (قيد الفحص).
 */
const addService = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const { serviceId, price } = req.body;

  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (!['WITH_DOCTOR', 'AWAITING_PAYMENT'].includes(visit.status)) {
    throw new AppError('لا يمكن إضافة خدمات في هذه المرحلة من الزيارة.', 400, 'INVALID_STATUS');
  }

  const service = await serviceModel.findById(serviceId);
  if (!service) {
    throw new AppError('الخدمة غير موجودة.', 404, 'SERVICE_NOT_FOUND');
  }

  const finalPrice = price !== undefined && price !== null ? price : service.default_price;
  const record = await visitServiceModel.addService(visitId, serviceId, finalPrice, req.user.id);

  await logAction({
    userId: req.user.id,
    action: 'ADD_VISIT_SERVICE',
    recordType: 'visits',
    recordId: Number(visitId),
    details: { serviceId, price: finalPrice },
  });

  res.status(201).json({ success: true, data: { ...record, service_name: service.name } });
});

const removeService = asyncHandler(async (req, res) => {
  const { id: visitId, serviceLineId } = req.params;
  const removed = await visitServiceModel.removeById(serviceLineId, visitId);
  if (!removed) {
    throw new AppError('هذا السطر غير موجود لهذه الزيارة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'REMOVE_VISIT_SERVICE',
    recordType: 'visits',
    recordId: Number(visitId),
    details: { serviceLineId: Number(serviceLineId) },
  });

  res.json({ success: true, message: 'تم حذف الخدمة من الزيارة.' });
});

const listServices = asyncHandler(async (req, res) => {
  const services = await visitServiceModel.findByVisitId(req.params.id);
  res.json({ success: true, data: services });
});

/**
 * تحديد التخفيض (ثابت أو نسبة) — اختياري، يُعاد حسابه من مجموع الخدمات الحالي في كل مرة.
 */
const setDiscount = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const { type, value } = req.body;

  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (!['WITH_DOCTOR', 'AWAITING_PAYMENT'].includes(visit.status)) {
    throw new AppError('لا يمكن تحديد تخفيض في هذه المرحلة من الزيارة.', 400, 'INVALID_STATUS');
  }

  const subtotal = await visitServiceModel.sumByVisitId(visitId);
  if (subtotal <= 0) {
    throw new AppError('يجب إضافة خدمة واحدة على الأقل قبل تحديد التخفيض.', 400, 'NO_SERVICES');
  }

  const numericValue = Number(value);
  const total = type === 'PERCENTAGE' ? subtotal - (subtotal * numericValue) / 100 : subtotal - numericValue;
  if (total < 0) {
    throw new AppError('قيمة التخفيض أكبر من المبلغ الإجمالي.', 400, 'INVALID_DISCOUNT');
  }

  const record = await discountModel.upsert(visitId, {
    type,
    value: numericValue,
    subtotal,
    total,
    setBy: req.user.id,
  });

  await logAction({
    userId: req.user.id,
    action: 'SET_DISCOUNT',
    recordType: 'visits',
    recordId: Number(visitId),
    details: { type, value: numericValue, total },
  });

  res.json({ success: true, data: record });
});

/**
 * "تأكيد وإنهاء الفحص": يتحقق من وجود خدمة واحدة على الأقل، وينقل الحالة مباشرة
 * WITH_DOCTOR → AWAITING_PAYMENT (قيد الدفع)، فتظهر المريضة تلقائيًا لدى الاستقبال.
 */
const confirmFinishExam = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (visit.status !== 'WITH_DOCTOR') {
    throw new AppError('لا يمكن إنهاء الفحص إلا لزيارة قيد الفحص حاليًا.', 400, 'INVALID_STATUS');
  }

  const subtotal = await visitServiceModel.sumByVisitId(visitId);
  if (subtotal <= 0) {
    throw new AppError('يجب اختيار خدمة واحدة على الأقل قبل إنهاء الفحص.', 400, 'NO_SERVICES');
  }

  await visitModel.updateStatus(visitId, 'AWAITING_PAYMENT');
  const updated = await visitModel.markWithDoctorEnded(visitId);

  await logAction({
    userId: req.user.id,
    action: 'CONFIRM_FINISH_EXAM',
    recordType: 'visits',
    recordId: Number(visitId),
  });

  emitQueueUpdated(req.app);

  res.json({ success: true, data: updated });
});

/**
 * فاتورة "قيد الدفع": خدمات الزيارة الحالية + المبلغ المستحق، بالإضافة إلى أي أرصدة
 * متبقية من زيارات سابقة مكتملة لنفس المريضة (تظهر تحذيرًا في نافذة التخليص).
 */
const getInvoice = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }

  const currentTotals = await visitBillingModel.getVisitTotals(visitId);
  const oldBalances = await visitBillingModel.getOutstandingBalancesForPatient(visit.patient_id, visitId);
  const oldBalancesTotal = oldBalances.reduce((sum, b) => sum + Number(b.remaining_balance), 0);

  res.json({
    success: true,
    data: {
      visitStatus: visit.status,
      services: currentTotals.services,
      subtotal: currentTotals.subtotal,
      discount: currentTotals.discount,
      currentTotal: currentTotals.total,
      currentPaid: currentTotals.paidAmount,
      currentRemaining: currentTotals.remainingBalance,
      oldBalances,
      oldBalancesTotal,
      grandTotalDue: currentTotals.remainingBalance + oldBalancesTotal,
    },
  });
});

/**
 * "تخليص": يستقبل مبلغًا واحدًا مدفوعًا الآن، ويوزّعه تلقائيًا:
 * أولًا على أقدم الأرصدة المتبقية من زيارات سابقة (كل دفعة تُسجَّل على زيارتها الأصلية)،
 * ثم الباقي على الزيارة الحالية. الزيارة الحالية تُغلق (COMPLETED) دائمًا، سواء
 * تم السداد بالكامل أو جزئيًا — والمبلغ غير المسدَّد يبقى كرصيد متبقٍ مرتبطًا بمصدره.
 */
const checkout = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const { amountPaidNow, method } = req.body;

  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (visit.status !== 'AWAITING_PAYMENT') {
    throw new AppError('هذه الزيارة ليست بانتظار الدفع حاليًا.', 400, 'INVALID_STATUS');
  }

  const currentTotals = await visitBillingModel.getVisitTotals(visitId);
  const oldBalances = await visitBillingModel.getOutstandingBalancesForPatient(visit.patient_id, visitId);
  const oldBalancesTotal = oldBalances.reduce((sum, b) => sum + Number(b.remaining_balance), 0);
  const grandTotal = currentTotals.remainingBalance + oldBalancesTotal;

  let remaining = Number(amountPaidNow);
  if (remaining < 0) {
    throw new AppError('المبلغ المدفوع غير صالح.', 400, 'INVALID_AMOUNT');
  }
  if (remaining > grandTotal + 0.01) {
    throw new AppError(
      `المبلغ المدفوع (${remaining}) أكبر من إجمالي المطلوب (${grandTotal.toFixed(2)}).`,
      400,
      'AMOUNT_EXCEEDS_DUE'
    );
  }

  const allocations = [];

  // 1) سداد الأرصدة القديمة أولًا (الأقدم فالأحدث)، كل دفعة على زيارتها الأصلية
  for (const balance of oldBalances) {
    if (remaining <= 0) break;
    const payAmount = Math.min(remaining, Number(balance.remaining_balance));
    if (payAmount > 0.005) {
      const payment = await paymentModel.create({
        visitId: balance.visit_id,
        amount: payAmount,
        method,
        receivedBy: req.user.id,
      });
      allocations.push({ visitId: balance.visit_id, amount: payAmount, type: 'OLD_BALANCE', payment });
      remaining -= payAmount;
    }
  }

  // 2) الباقي يُسجَّل على الزيارة الحالية
  if (remaining > 0.005) {
    const payment = await paymentModel.create({
      visitId: Number(visitId),
      amount: remaining,
      method,
      receivedBy: req.user.id,
    });
    allocations.push({ visitId: Number(visitId), amount: remaining, type: 'CURRENT_VISIT', payment });
  }

  // الزيارة الحالية تُغلق دائمًا بعد التخليص (مكتملة)، سواء كان السداد كاملًا أو جزئيًا
  const updatedVisit = await visitModel.updateStatus(visitId, 'COMPLETED');

  const finalCurrentTotals = await visitBillingModel.getVisitTotals(visitId);

  await logAction({
    userId: req.user.id,
    action: 'CHECKOUT_PAYMENT',
    recordType: 'visits',
    recordId: Number(visitId),
    details: { amountPaidNow, method, allocations: allocations.map((a) => ({ visitId: a.visitId, amount: a.amount })) },
  });

  emitQueueUpdated(req.app);

  res.status(201).json({
    success: true,
    data: {
      visit: updatedVisit,
      allocations,
      currentVisitRemainingBalance: finalCurrentTotals.remainingBalance,
      paymentStatus: finalCurrentTotals.remainingBalance <= 0.01 ? 'PAID' : (finalCurrentTotals.paidAmount > 0 ? 'PARTIAL' : 'UNPAID'),
    },
  });
});

const printReceipt = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  const payment = await paymentModel.findByVisitId(visitId);
  if (!payment) {
    throw new AppError('لا يوجد دفع مسجَّل لهذه الزيارة بعد.', 404, 'PAYMENT_NOT_FOUND');
  }

  const patient = await patientModel.findById(visit.patient_id);
  const services = await visitServiceModel.findByVisitId(visitId);
  const discount = await discountModel.findByVisitId(visitId);
  const clinicSettings = await clinicSettingModel.getAll();

  const pdfBuffer = await generateReceiptPdf({ patient, clinicSettings, services, discount, payment });

  await logAction({
    userId: req.user.id,
    action: 'PRINT_RECEIPT',
    recordType: 'payments',
    recordId: payment.id,
  });

  res.set('Content-Type', 'application/pdf');
  res.set('Content-Disposition', `inline; filename="${payment.receipt_number}.pdf"`);
  res.send(pdfBuffer);
});

module.exports = {
  addService,
  removeService,
  listServices,
  setDiscount,
  confirmFinishExam,
  getInvoice,
  checkout,
  printReceipt,
};
