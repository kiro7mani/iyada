'use strict';

const doctorBreakModel = require('../models/doctorBreakModel');
const { logAction } = require('../utils/auditLog');
const asyncHandler = require('../utils/asyncHandler');

const getStatus = asyncHandler(async (req, res) => {
  const status = await doctorBreakModel.getStatus();
  res.json({ success: true, data: status });
});

/**
 * الطبيبة تضغط "استراحة عمل" — يتوقف احتساب متوسطات مدة الفحص، وتُعلَم الاستقبال
 * فورًا بإشعار مستمر لا يختفي إلا عند استئناف العمل.
 */
const start = asyncHandler(async (req, res) => {
  const status = await doctorBreakModel.setBreak(true);

  const io = req.app.locals.io;
  if (io) io.to('reception').emit('doctor_break_started');

  await logAction({ userId: req.user.id, action: 'DOCTOR_BREAK_STARTED' });

  res.json({ success: true, data: status });
});

/**
 * استئناف العمل — يُعلَم الاستقبال بتحديث نفس الإشعار، ويُعاد احتساب المتوسطات من جديد.
 */
const end = asyncHandler(async (req, res) => {
  const status = await doctorBreakModel.setBreak(false);

  const io = req.app.locals.io;
  if (io) io.to('reception').emit('doctor_break_ended');

  await logAction({ userId: req.user.id, action: 'DOCTOR_BREAK_ENDED' });

  res.json({ success: true, data: status });
});

module.exports = { getStatus, start, end };
