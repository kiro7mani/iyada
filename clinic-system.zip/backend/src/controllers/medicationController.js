'use strict';

const medicationModel = require('../models/medicationModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const list = asyncHandler(async (req, res) => {
  const activeOnly = req.query.activeOnly === 'true';
  const q = req.query.q;
  const medications = q ? await medicationModel.search(q) : await medicationModel.findAll({ activeOnly });
  res.json({ success: true, data: medications });
});

const create = asyncHandler(async (req, res) => {
  const { name } = req.body;
  const medication = await medicationModel.create({ name });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_MEDICATION',
    recordType: 'medications',
    recordId: medication.id,
  });

  res.status(201).json({ success: true, data: medication });
});

const update = asyncHandler(async (req, res) => {
  const { name, isActive } = req.body;
  const updated = await medicationModel.update(req.params.id, { name, isActive });
  if (!updated) {
    throw new AppError('الدواء غير موجود.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_MEDICATION',
    recordType: 'medications',
    recordId: updated.id,
  });

  res.json({ success: true, data: updated });
});

const remove = asyncHandler(async (req, res) => {
  const removed = await medicationModel.remove(req.params.id);
  if (!removed) {
    throw new AppError('الدواء غير موجود.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'DELETE_MEDICATION',
    recordType: 'medications',
    recordId: Number(req.params.id),
  });

  res.json({ success: true, message: 'تم حذف الدواء.' });
});

module.exports = { list, create, update, remove };
