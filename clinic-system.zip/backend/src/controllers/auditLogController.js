'use strict';

const auditLogModel = require('../models/auditLogModel');
const asyncHandler = require('../utils/asyncHandler');

const list = asyncHandler(async (req, res) => {
  const { userId, action, from, to, page, limit } = req.query;
  const filters = {
    userId: userId ? Number(userId) : null,
    action: action || null,
    from: from || null,
    to: to || null,
    page: page ? Number(page) : 1,
    limit: limit ? Math.min(Number(limit), 200) : 50,
  };

  const [logs, total] = await Promise.all([
    auditLogModel.findAll(filters),
    auditLogModel.countAll(filters),
  ]);

  res.json({
    success: true,
    data: logs,
    pagination: { page: filters.page, limit: filters.limit, total },
  });
});

module.exports = { list };
