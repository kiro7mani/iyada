'use strict';

const { withTransaction } = require('../config/db');
const visitModel = require('../models/visitModel');
const dailyQueueModel = require('../models/dailyQueueModel');
const doctorBreakModel = require('../models/doctorBreakModel');
const patientModel = require('../models/patientModel');
const clinicSettingModel = require('../models/clinicSettingModel');
const printerService = require('../services/printerService');
const tvAnnouncementModel = require('../models/tvAnnouncementModel');
const { emitQueueUpdated, emitPatientCalled } = require('../utils/socketEvents');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const NON_CANCELLABLE_STATUSES = ['WITH_DOCTOR', 'EXAM_COMPLETED', 'AWAITING_PAYMENT', 'PAID', 'COMPLETED'];

/**
 * حجز مريضة لليوم الحالي — يبدأ مباشرة بحالة "في الانتظار" (لا مرحلة حجز هاتفي منفصلة).
 * - إذا كان لديها حجز نشط اليوم بالفعل → 409 مع بيانات الحجز الموجود (لا رقم جديد).
 */
const book = asyncHandler(async (req, res) => {
  const { patientId, visitType = 'GENERAL' } = req.body;

  const patient = await patientModel.findById(patientId);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }

  const existingVisit = await visitModel.findTodayActiveByPatient(patientId);
  if (existingVisit) {
    const existingQueue = await dailyQueueModel.findByVisitId(existingVisit.id);
    return res.status(409).json({
      success: false,
      code: 'ALREADY_BOOKED_TODAY',
      message: 'هذه المريضة لديها حجز بالفعل اليوم.',
      data: { visit: existingVisit, queue: existingQueue },
    });
  }

  const result = await withTransaction(async (client) => {
    const visit = await visitModel.createWithClient(client, {
      patientId,
      visitType,
      createdBy: req.user.id,
      status: 'WAITING',
    });
    const queueEntry = await dailyQueueModel.createWithClient(client, visit.id);
    return { visit, queueEntry };
  });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_BOOKING',
    recordType: 'visits',
    recordId: result.visit.id,
    details: { queueNumber: result.queueEntry.queue_number },
  });

  emitQueueUpdated(req.app);

  res.status(201).json({
    success: true,
    data: { visit: result.visit, queue: result.queueEntry, patient },
  });
});

/**
 * تأكيد حضور مريضة كانت محجوزة مسبقًا هاتفيًا (BOOKED) → تنتقل إلى WAITING.
 */
const confirmPresence = asyncHandler(async (req, res) => {
  const { visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (!['BOOKED', 'PRESENT'].includes(visit.status)) {
    throw new AppError('لا يمكن تأكيد الحضور لهذه الزيارة في حالتها الحالية.', 400, 'INVALID_STATUS');
  }

  const updated = await visitModel.updateStatus(visitId, 'WAITING');

  await logAction({
    userId: req.user.id,
    action: 'CONFIRM_PRESENCE',
    recordType: 'visits',
    recordId: Number(visitId),
  });

  emitQueueUpdated(req.app);

  res.json({ success: true, data: updated });
});

const cancel = asyncHandler(async (req, res) => {
  const { visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (NON_CANCELLABLE_STATUSES.includes(visit.status)) {
    throw new AppError('لا يمكن إلغاء زيارة قيد الفحص أو مكتملة.', 400, 'INVALID_STATUS');
  }

  const updated = await visitModel.updateStatus(visitId, 'CANCELLED');

  await logAction({
    userId: req.user.id,
    action: 'CANCEL_BOOKING',
    recordType: 'visits',
    recordId: Number(visitId),
  });

  emitQueueUpdated(req.app);

  res.json({ success: true, data: updated });
});

const markNoShow = asyncHandler(async (req, res) => {
  const { visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (!['BOOKED', 'PRESENT'].includes(visit.status)) {
    throw new AppError('لا يمكن تعليم هذه الزيارة كـ"لم تحضر" في حالتها الحالية.', 400, 'INVALID_STATUS');
  }

  const updated = await visitModel.updateStatus(visitId, 'NO_SHOW');

  await logAction({
    userId: req.user.id,
    action: 'MARK_NO_SHOW',
    recordType: 'visits',
    recordId: Number(visitId),
  });

  emitQueueUpdated(req.app);

  res.json({ success: true, data: updated });
});

const today = asyncHandler(async (req, res) => {
  const list = await dailyQueueModel.findTodayQueue();
  res.json({ success: true, data: list });
});

const printTicket = asyncHandler(async (req, res) => {
  const { visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  const queueEntry = await dailyQueueModel.findByVisitId(visitId);
  if (!queueEntry) {
    throw new AppError('لا يوجد رقم انتظار لهذه الزيارة.', 404, 'QUEUE_NOT_FOUND');
  }
  const patient = await patientModel.findById(visit.patient_id);
  const clinicSettings = await clinicSettingModel.getAll();

  const bookedAt = new Date(visit.booked_at);
  const visitDate = bookedAt.toLocaleDateString('ar-DZ');
  const visitTime = bookedAt.toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit' });

  try {
    await printerService.printTicket({
      clinicName: clinicSettings.clinic_name || 'عيادة أمراض النساء والتوليد ومتابعة الحمل',
      patientFullName: `${patient.first_name} ${patient.last_name}`,
      queueNumber: queueEntry.queue_number,
      visitDate,
      visitTime,
    });
  } catch (err) {
    throw new AppError('تعذر الاتصال بالطابعة.', 503, 'PRINTER_ERROR');
  }

  await logAction({
    userId: req.user.id,
    action: 'PRINT_TICKET',
    recordType: 'visits',
    recordId: Number(visitId),
  });

  res.json({ success: true, message: 'تمت طباعة الكوبون بنجاح.' });
});

const testPrinterConnection = asyncHandler(async (req, res) => {
  try {
    await printerService.testPrinter();
  } catch (err) {
    throw new AppError('تعذر الاتصال بالطابعة.', 503, 'PRINTER_ERROR');
  }
  res.json({ success: true, message: 'الطابعة متصلة وتعمل بشكل صحيح.' });
});

/**
 * استدعاء أول مريضة بحالة WAITING (حسب رقم الانتظار).
 */
const callNext = asyncHandler(async (req, res) => {
  const next = await dailyQueueModel.findNextWaiting();
  if (!next) {
    throw new AppError('لا توجد مريضات في الانتظار حاليًا.', 404, 'QUEUE_EMPTY');
  }

  const updatedVisit = await visitModel.updateStatus(next.visit_id, 'CALLED');
  const updatedQueue = await dailyQueueModel.setCalledAt(next.visit_id);
  await tvAnnouncementModel.create({
    queueNumber: next.queue_number,
    visitId: next.visit_id,
    type: 'CALL',
  });

  await logAction({
    userId: req.user.id,
    action: 'CALL_PATIENT',
    recordType: 'visits',
    recordId: next.visit_id,
    details: { queueNumber: next.queue_number },
  });

  emitPatientCalled(req.app, { queueNumber: next.queue_number, visitId: next.visit_id }, false);
  emitQueueUpdated(req.app);

  res.json({
    success: true,
    data: {
      visit: updatedVisit,
      queue: updatedQueue,
      patient: {
        firstName: next.first_name,
        lastName: next.last_name,
        medicalFileNumber: next.medical_file_number,
      },
    },
  });
});

/**
 * إعادة استدعاء آخر رقم تم نداؤه (زر "إعادة الاستدعاء" في Dashboard الطبيبة).
 */
const recall = asyncHandler(async (req, res) => {
  const { visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (visit.status !== 'CALLED') {
    throw new AppError('لا يمكن إعادة استدعاء زيارة لم تُستدعَ بعد.', 400, 'INVALID_STATUS');
  }

  const updatedQueue = await dailyQueueModel.incrementRecall(visitId);
  if (!updatedQueue) {
    throw new AppError('لا يوجد رقم انتظار لهذه الزيارة.', 404, 'QUEUE_NOT_FOUND');
  }

  await tvAnnouncementModel.create({
    queueNumber: updatedQueue.queue_number,
    visitId: Number(visitId),
    type: 'RECALL',
  });

  await logAction({
    userId: req.user.id,
    action: 'RECALL_PATIENT',
    recordType: 'visits',
    recordId: Number(visitId),
  });

  emitPatientCalled(req.app, { queueNumber: updatedQueue.queue_number, visitId: Number(visitId) }, true);

  res.json({ success: true, data: updatedQueue });
});

/**
 * دخول المريضة فعليًا لغرفة الفحص: CALLED → WITH_DOCTOR.
 */
const startExam = asyncHandler(async (req, res) => {
  const { visitId } = req.params;
  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (visit.status !== 'CALLED') {
    throw new AppError('يجب استدعاء المريضة أولاً قبل بدء الفحص.', 400, 'INVALID_STATUS');
  }

  const breakStatus = await doctorBreakModel.getStatus();
  if (breakStatus.is_on_break) {
    throw new AppError('لا يمكن بدء الفحص أثناء استراحة العمل. اضغط "استئناف العمل" أولًا.', 400, 'DOCTOR_ON_BREAK');
  }

  await visitModel.updateStatus(visitId, 'WITH_DOCTOR');
  const updated = await visitModel.markWithDoctorStarted(visitId);

  await logAction({
    userId: req.user.id,
    action: 'START_EXAM',
    recordType: 'visits',
    recordId: Number(visitId),
  });

  emitQueueUpdated(req.app);

  res.json({ success: true, data: updated });
});

module.exports = {
  book,
  confirmPresence,
  cancel,
  markNoShow,
  today,
  printTicket,
  testPrinterConnection,
  callNext,
  recall,
  startExam,
};
