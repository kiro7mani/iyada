'use strict';

const fs = require('fs');
const path = require('path');
const env = require('../config/env');
const tvMediaModel = require('../models/tvMediaModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const upload = asyncHandler(async (req, res) => {
  if (!req.file) {
    throw new AppError('يجب رفع ملف فيديو (MP4 أو WEBM).', 422, 'FILE_REQUIRED');
  }
  const { title, category } = req.body;
  const relativePath = `tv/${req.file.filename}`;

  const media = await tvMediaModel.create({
    filePath: relativePath,
    title: title || req.file.originalname,
    category: category || null,
    uploadedBy: req.user.id,
  });

  await logAction({
    userId: req.user.id,
    action: 'UPLOAD_TV_MEDIA',
    recordType: 'tv_media',
    recordId: media.id,
  });

  res.status(201).json({ success: true, data: media });
});

const list = asyncHandler(async (req, res) => {
  const media = await tvMediaModel.findAll();
  res.json({ success: true, data: media });
});

const remove = asyncHandler(async (req, res) => {
  const media = await tvMediaModel.remove(req.params.id);
  if (!media) {
    throw new AppError('الفيديو غير موجود.', 404, 'NOT_FOUND');
  }

  const absolutePath = path.resolve(env.uploads.dir, media.file_path);
  fs.unlink(absolutePath, () => {}); // حذف الملف من القرص، بدون إيقاف الطلب إن فشل

  await logAction({
    userId: req.user.id,
    action: 'DELETE_TV_MEDIA',
    recordType: 'tv_media',
    recordId: Number(req.params.id),
  });

  res.json({ success: true, message: 'تم حذف الفيديو.' });
});

module.exports = { upload, list, remove };
