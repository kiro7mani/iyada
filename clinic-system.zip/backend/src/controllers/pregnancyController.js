'use strict';

const patientModel = require('../models/patientModel');
const visitModel = require('../models/visitModel');
const pregnancyModel = require('../models/pregnancyModel');
const pregnancyVisitModel = require('../models/pregnancyVisitModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

function addDaysToDateString(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

/**
 * تسجيل حمل جديد لمريضة. إذا لم يُرسل موعد الولادة المتوقع (EDD) صراحة،
 * يُحسب تلقائيًا من تاريخ آخر دورة (LMP + 280 يومًا).
 */
const create = asyncHandler(async (req, res) => {
  const { id: patientId } = req.params;
  const patient = await patientModel.findById(patientId);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }

  const { lmpDate, eddDate, gravida, para, previousPregnancyNotes } = req.body;
  const computedEdd = eddDate || (lmpDate ? addDaysToDateString(lmpDate, 280) : null);

  const pregnancy = await pregnancyModel.create({
    patientId,
    lmpDate,
    eddDate: computedEdd,
    gravida,
    para,
    previousPregnancyNotes,
  });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_PREGNANCY',
    recordType: 'pregnancies',
    recordId: pregnancy.id,
    details: { patientId: Number(patientId) },
  });

  res.status(201).json({ success: true, data: pregnancy });
});

const listByPatient = asyncHandler(async (req, res) => {
  const patient = await patientModel.findById(req.params.id);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }
  const pregnancies = await pregnancyModel.findByPatientId(req.params.id);
  res.json({ success: true, data: pregnancies });
});

const getById = asyncHandler(async (req, res) => {
  const pregnancy = await pregnancyModel.findById(req.params.id);
  if (!pregnancy) {
    throw new AppError('سجل الحمل غير موجود.', 404, 'NOT_FOUND');
  }
  const timeline = await pregnancyVisitModel.findTimelineByPregnancyId(pregnancy.id);
  res.json({ success: true, data: { ...pregnancy, timeline } });
});

const update = asyncHandler(async (req, res) => {
  const { lmpDate, eddDate, gravida, para, previousPregnancyNotes } = req.body;
  const updated = await pregnancyModel.update(req.params.id, {
    lmpDate,
    eddDate,
    gravida,
    para,
    previousPregnancyNotes,
  });
  if (!updated) {
    throw new AppError('سجل الحمل غير موجود.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_PREGNANCY',
    recordType: 'pregnancies',
    recordId: updated.id,
  });

  res.json({ success: true, data: updated });
});

const updateStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const updated = await pregnancyModel.updateStatus(req.params.id, status);
  if (!updated) {
    throw new AppError('سجل الحمل غير موجود.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_PREGNANCY_STATUS',
    recordType: 'pregnancies',
    recordId: updated.id,
    details: { status },
  });

  res.json({ success: true, data: updated });
});

/**
 * إضافة زيارة متابعة حمل جديدة إلى الـ Timeline، مرتبطة بزيارة فعلية للمريضة.
 * تُحدَّث الزيارة تلقائيًا لتصبح visit_type = 'PREGNANCY'.
 */
const addVisit = asyncHandler(async (req, res) => {
  const { id: pregnancyId } = req.params;
  const {
    visitId,
    gestationalAgeWeeks,
    weight,
    bloodPressure,
    bloodSugar,
    labSummary,
    ultrasoundSummary,
    medications,
    supplements,
    notes,
  } = req.body;

  const pregnancy = await pregnancyModel.findById(pregnancyId);
  if (!pregnancy) {
    throw new AppError('سجل الحمل غير موجود.', 404, 'NOT_FOUND');
  }

  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (visit.patient_id !== pregnancy.patient_id) {
    throw new AppError('هذه الزيارة لا تخص نفس المريضة صاحبة سجل الحمل.', 400, 'PATIENT_MISMATCH');
  }

  const record = await pregnancyVisitModel.create({
    pregnancyId,
    visitId,
    gestationalAgeWeeks,
    weight,
    bloodPressure,
    bloodSugar,
    labSummary,
    ultrasoundSummary,
    medications,
    supplements,
    notes,
  });

  await visitModel.updateVisitType(visitId, 'PREGNANCY');

  await logAction({
    userId: req.user.id,
    action: 'ADD_PREGNANCY_VISIT',
    recordType: 'pregnancy_visits',
    recordId: record.id,
    details: { pregnancyId: Number(pregnancyId), visitId: Number(visitId) },
  });

  res.status(201).json({ success: true, data: record });
});

module.exports = { create, listByPatient, getById, update, updateStatus, addVisit };
