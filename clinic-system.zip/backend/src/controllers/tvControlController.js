'use strict';

const { emitTvControl } = require('../utils/socketEvents');
const asyncHandler = require('../utils/asyncHandler');

function makeSimpleControl(event) {
  return asyncHandler(async (req, res) => {
    emitTvControl(req.app, event);
    res.json({ success: true, message: 'تم إرسال الأمر إلى شاشة الانتظار.' });
  });
}

const play = makeSimpleControl('tv_play');
const pause = makeSimpleControl('tv_pause');
const next = makeSimpleControl('tv_next');
const previous = makeSimpleControl('tv_previous');
const mute = makeSimpleControl('tv_mute');
const unmute = makeSimpleControl('tv_unmute');

const setVolume = asyncHandler(async (req, res) => {
  const { level } = req.body;
  emitTvControl(req.app, 'tv_volume', { level });
  res.json({ success: true, message: 'تم تعديل مستوى الصوت.' });
});

const testAnnouncement = asyncHandler(async (req, res) => {
  emitTvControl(req.app, 'announcement_start', { test: true, queueNumber: '00' });
  res.json({ success: true, message: 'تم إرسال نداء تجريبي.' });
});

module.exports = { play, pause, next, previous, mute, unmute, setVolume, testAnnouncement };
