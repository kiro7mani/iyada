'use strict';

const { withTransaction } = require('../config/db');
const visitModel = require('../models/visitModel');
const prescriptionModel = require('../models/prescriptionModel');
const { generatePrescriptionPdf } = require('../services/prescriptionPdfService');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

/**
 * إنشاء وصفة كاملة (بند واحد أو أكثر) في عملية واحدة.
 * body: { items: [{ medicationName, dosage, frequency, duration, instructions }] }
 */
const create = asyncHandler(async (req, res) => {
  const { id: visitId } = req.params;
  const { items } = req.body;

  const visit = await visitModel.findById(visitId);
  if (!visit) {
    throw new AppError('الزيارة غير موجودة.', 404, 'NOT_FOUND');
  }
  if (!Array.isArray(items) || items.length === 0) {
    throw new AppError('يجب إضافة دواء واحد على الأقل.', 422, 'ITEMS_REQUIRED');
  }

  const result = await withTransaction(async (client) => {
    const prescription = await prescriptionModel.createWithClient(client, {
      visitId,
      createdBy: req.user.id,
    });
    const createdItems = [];
    for (const item of items) {
      const created = await prescriptionModel.addItemWithClient(client, {
        prescriptionId: prescription.id,
        ...item,
      });
      createdItems.push(created);
    }
    return { ...prescription, items: createdItems };
  });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_PRESCRIPTION',
    recordType: 'prescriptions',
    recordId: result.id,
    details: { visitId: Number(visitId), itemsCount: items.length },
  });

  res.status(201).json({ success: true, data: result });
});

const listByVisit = asyncHandler(async (req, res) => {
  const prescriptions = await prescriptionModel.findByVisitId(req.params.id);
  res.json({ success: true, data: prescriptions });
});

const printPrescription = asyncHandler(async (req, res) => {
  const prescription = await prescriptionModel.findById(req.params.id);
  if (!prescription) {
    throw new AppError('الوصفة غير موجودة.', 404, 'NOT_FOUND');
  }

  // طباعة فوق ورقة وصفة جاهزة مسبقًا: قائمة الأدوية فقط، بدون أي بيانات عيادة/طبيبة/مريضة
  const pdfBuffer = await generatePrescriptionPdf({ prescription });

  await logAction({
    userId: req.user.id,
    action: 'PRINT_PRESCRIPTION',
    recordType: 'prescriptions',
    recordId: prescription.id,
  });

  res.set('Content-Type', 'application/pdf');
  res.set('Content-Disposition', `inline; filename="prescription-${prescription.id}.pdf"`);
  res.send(pdfBuffer);
});

module.exports = { create, listByVisit, printPrescription };
