'use strict';

const { emitNurseCallRequested, emitNurseCallAcknowledged } = require('../utils/socketEvents');
const { logAction } = require('../utils/auditLog');
const asyncHandler = require('../utils/asyncHandler');

/**
 * الطبيبة تطلب الممرضة (الاستقبال) — إشعار مستمر لا يختفي إلا بالضغط عليه.
 */
const request = asyncHandler(async (req, res) => {
  emitNurseCallRequested(req.app);

  await logAction({
    userId: req.user.id,
    action: 'NURSE_CALL_REQUESTED',
  });

  res.json({ success: true, message: 'تم إرسال الاستدعاء إلى الاستقبال.' });
});

/**
 * الاستقبال يؤكد الاستجابة — إشعار قصير يظهر لدى الطبيبة ثم يختفي تلقائيًا.
 */
const acknowledge = asyncHandler(async (req, res) => {
  emitNurseCallAcknowledged(req.app);

  await logAction({
    userId: req.user.id,
    action: 'NURSE_CALL_ACKNOWLEDGED',
  });

  res.json({ success: true, message: 'تم إعلام الطبيبة.' });
});

module.exports = { request, acknowledge };
