'use strict';

const { withTransaction } = require('../config/db');
const patientModel = require('../models/patientModel');
const patientQrModel = require('../models/patientQrModel');
const clinicSettingModel = require('../models/clinicSettingModel');
const qrService = require('../services/qrService');
const { generateMedicalFilePdf } = require('../services/medicalFilePdfService');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const search = asyncHandler(async (req, res) => {
  const { q = '', birthDate = null } = req.query;
  const patients = await patientModel.search({ q, birthDate });
  res.json({ success: true, data: patients });
});

const checkDuplicate = asyncHandler(async (req, res) => {
  const { firstName, lastName, birthDate = null, phone = null } = req.body;
  const matches = await patientModel.findPossibleDuplicates({ firstName, lastName, birthDate, phone });
  res.json({ success: true, data: { possibleDuplicate: matches.length > 0, matches } });
});

/**
 * إنشاء مريضة جديدة.
 * يتم فحص التكرار تلقائيًا قبل الإنشاء: إذا وُجدت مريضات مشابهات ولم يُرسل
 * forceCreate=true، نرجع 409 مع قائمة المرشحين بدل الإنشاء المباشر.
 */
const create = asyncHandler(async (req, res) => {
  const { firstName, lastName, birthDate, phone, address, nationalId, adminNotes, forceCreate } = req.body;

  if (!forceCreate) {
    const possibleDuplicates = await patientModel.findPossibleDuplicates({
      firstName,
      lastName,
      birthDate,
      phone,
    });
    if (possibleDuplicates.length > 0) {
      return res.status(409).json({
        success: false,
        code: 'POSSIBLE_DUPLICATE',
        message: 'قد تكون هذه المريضة موجودة مسبقًا. الرجاء المراجعة قبل إنشاء ملف جديد.',
        data: { matches: possibleDuplicates },
      });
    }
  }

  const result = await withTransaction(async (client) => {
    const patient = await patientModel.createWithClient(client, {
      firstName,
      lastName,
      birthDate,
      phone,
      address,
      nationalId,
      adminNotes,
      createdBy: req.user.id,
    });

    const token = qrService.generateToken();
    const qr = await patientQrModel.createWithClient(client, patient.id, token);

    return { patient, qr };
  });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_PATIENT',
    recordType: 'patients',
    recordId: result.patient.id,
    details: { medicalFileNumber: result.patient.medical_file_number },
  });

  res.status(201).json({
    success: true,
    data: { ...result.patient, qr_token: result.qr.token },
  });
});

const getById = asyncHandler(async (req, res) => {
  const patient = await patientModel.findById(req.params.id);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }
  const qr = await patientQrModel.findByPatientId(patient.id);
  res.json({ success: true, data: { ...patient, qr_token: qr ? qr.token : null } });
});

const getByQrToken = asyncHandler(async (req, res) => {
  const patient = await patientQrModel.findByToken(req.params.token);
  if (!patient) {
    throw new AppError('تعذر قراءة QR أو المريضة غير موجودة.', 404, 'QR_NOT_FOUND');
  }
  res.json({ success: true, data: patient });
});

const update = asyncHandler(async (req, res) => {
  const { firstName, lastName, birthDate, phone, address, nationalId, adminNotes } = req.body;
  const updated = await patientModel.update(req.params.id, {
    firstName,
    lastName,
    birthDate,
    phone,
    address,
    nationalId,
    adminNotes,
  });
  if (!updated) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_PATIENT',
    recordType: 'patients',
    recordId: updated.id,
  });

  res.json({ success: true, data: updated });
});

const getQrImage = asyncHandler(async (req, res) => {
  const qr = await patientQrModel.findByPatientId(req.params.id);
  if (!qr) {
    throw new AppError('لا يوجد QR لهذه المريضة.', 404, 'QR_NOT_FOUND');
  }
  const buffer = await qrService.generateQrPngBuffer(qr.token);
  res.set('Content-Type', 'image/png');
  res.send(buffer);
});

const printMedicalFile = asyncHandler(async (req, res) => {
  const patient = await patientModel.findById(req.params.id);
  if (!patient) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }
  const qr = await patientQrModel.findByPatientId(patient.id);
  const clinicSettings = await clinicSettingModel.getAll();

  const pdfBuffer = await generateMedicalFilePdf({
    patient: { ...patient, qr_token: qr ? qr.token : null },
    clinicSettings,
  });

  await logAction({
    userId: req.user.id,
    action: 'PRINT_MEDICAL_FILE',
    recordType: 'patients',
    recordId: patient.id,
  });

  res.set('Content-Type', 'application/pdf');
  res.set('Content-Disposition', `inline; filename="${patient.medical_file_number}.pdf"`);
  res.send(pdfBuffer);
});

/**
 * حذف مريضة نهائيًا (Admin فقط). إذا كانت لديها زيارات مسجّلة، تُرفض العملية
 * برسالة واضحة للحفاظ على السجل الطبي (بدلًا من رسالة قيود قاعدة بيانات تقنية).
 */
const remove = asyncHandler(async (req, res) => {
  let removed;
  try {
    removed = await patientModel.remove(req.params.id);
  } catch (err) {
    const isForeignKeyViolation =
      err.code === '23503' || (err.message && err.message.toLowerCase().includes('foreign key'));
    if (isForeignKeyViolation) {
      throw new AppError(
        'لا يمكن حذف هذه المريضة لأن لديها زيارات مسجّلة في السجل الطبي. يُحفَظ السجل الطبي دائمًا ولا يُحذف.',
        409,
        'PATIENT_HAS_VISITS'
      );
    }
    // eslint-disable-next-line no-console
    console.error('خطأ غير متوقع أثناء حذف مريضة:', err);
    throw new AppError('تعذر حذف حساب المريضة. حاول مجددًا.', 500, 'DELETE_FAILED');
  }

  if (!removed) {
    throw new AppError('المريضة غير موجودة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'DELETE_PATIENT',
    recordType: 'patients',
    recordId: Number(req.params.id),
  });

  res.json({ success: true, message: 'تم حذف حساب المريضة.' });
});

module.exports = {
  search,
  checkDuplicate,
  create,
  getById,
  getByQrToken,
  update,
  getQrImage,
  printMedicalFile,
  remove,
};
