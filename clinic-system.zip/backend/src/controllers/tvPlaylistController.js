'use strict';

const tvPlaylistModel = require('../models/tvPlaylistModel');
const tvMediaModel = require('../models/tvMediaModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const list = asyncHandler(async (req, res) => {
  const playlists = await tvPlaylistModel.findAll();
  res.json({ success: true, data: playlists });
});

const create = asyncHandler(async (req, res) => {
  const { name, isDefault } = req.body;
  const playlist = await tvPlaylistModel.create({ name, isDefault: !!isDefault });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_TV_PLAYLIST',
    recordType: 'tv_playlists',
    recordId: playlist.id,
  });

  res.status(201).json({ success: true, data: playlist });
});

const setDefault = asyncHandler(async (req, res) => {
  const playlist = await tvPlaylistModel.setDefault(req.params.id);
  if (!playlist) {
    throw new AppError('Playlist غير موجودة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'SET_DEFAULT_TV_PLAYLIST',
    recordType: 'tv_playlists',
    recordId: playlist.id,
  });

  res.json({ success: true, data: playlist });
});

const getItems = asyncHandler(async (req, res) => {
  const playlist = await tvPlaylistModel.findById(req.params.id);
  if (!playlist) {
    throw new AppError('Playlist غير موجودة.', 404, 'NOT_FOUND');
  }
  const items = await tvPlaylistModel.findItemsByPlaylistId(req.params.id);
  res.json({ success: true, data: { ...playlist, items } });
});

const addItem = asyncHandler(async (req, res) => {
  const { id: playlistId } = req.params;
  const { mediaId, orderIndex } = req.body;

  const playlist = await tvPlaylistModel.findById(playlistId);
  if (!playlist) {
    throw new AppError('Playlist غير موجودة.', 404, 'NOT_FOUND');
  }
  const media = await tvMediaModel.findById(mediaId);
  if (!media) {
    throw new AppError('الفيديو غير موجود.', 404, 'MEDIA_NOT_FOUND');
  }

  const item = await tvPlaylistModel.addItem(playlistId, mediaId, orderIndex);

  await logAction({
    userId: req.user.id,
    action: 'ADD_TV_PLAYLIST_ITEM',
    recordType: 'tv_playlists',
    recordId: Number(playlistId),
    details: { mediaId },
  });

  res.status(201).json({ success: true, data: item });
});

const removeItem = asyncHandler(async (req, res) => {
  const { id: playlistId, itemId } = req.params;
  const removed = await tvPlaylistModel.removeItem(itemId, playlistId);
  if (!removed) {
    throw new AppError('هذا العنصر غير موجود في القائمة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'REMOVE_TV_PLAYLIST_ITEM',
    recordType: 'tv_playlists',
    recordId: Number(playlistId),
    details: { itemId: Number(itemId) },
  });

  res.json({ success: true, message: 'تم حذف الفيديو من القائمة.' });
});

module.exports = { list, create, setDefault, getItems, addItem, removeItem };
