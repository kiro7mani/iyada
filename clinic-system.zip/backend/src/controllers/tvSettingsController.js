'use strict';

const tvSettingsModel = require('../models/tvSettingsModel');
const tvPlaylistModel = require('../models/tvPlaylistModel');
const clinicSettingModel = require('../models/clinicSettingModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const DEFAULT_DISPLAY_SETTINGS = {
  show_clock: true,
  show_weather: true,
  show_logo: true,
  call_volume: 80,
  call_repeat_count: 2,
};

const list = asyncHandler(async (req, res) => {
  const settings = await tvSettingsModel.findAll();
  res.json({ success: true, data: settings });
});

const create = asyncHandler(async (req, res) => {
  const { startTime, endTime, playlistId, showClock, showWeather, showLogo, callVolume, callRepeatCount } =
    req.body;
  const record = await tvSettingsModel.create({
    startTime,
    endTime,
    playlistId,
    showClock,
    showWeather,
    showLogo,
    callVolume,
    callRepeatCount,
  });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_TV_SCHEDULE',
    recordType: 'tv_settings',
    recordId: record.id,
  });

  res.status(201).json({ success: true, data: record });
});

const update = asyncHandler(async (req, res) => {
  const updated = await tvSettingsModel.update(req.params.id, req.body);
  if (!updated) {
    throw new AppError('جدولة العرض غير موجودة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_TV_SCHEDULE',
    recordType: 'tv_settings',
    recordId: updated.id,
  });

  res.json({ success: true, data: updated });
});

const remove = asyncHandler(async (req, res) => {
  const removed = await tvSettingsModel.remove(req.params.id);
  if (!removed) {
    throw new AppError('جدولة العرض غير موجودة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'DELETE_TV_SCHEDULE',
    recordType: 'tv_settings',
    recordId: Number(req.params.id),
  });

  res.json({ success: true, message: 'تم حذف جدولة العرض.' });
});

/**
 * نقطة عامة (بدون تسجيل دخول) تستخدمها شاشة التلفاز نفسها لمعرفة ماذا تعرض الآن:
 * تبحث عن جدولة مطابقة للوقت الحالي، وإلا تستخدم الـ Playlist الافتراضية بإعدادات افتراضية.
 */
const getCurrentPublic = asyncHandler(async (req, res) => {
  const clinicSettings = await clinicSettingModel.getAll();
  const activeSchedule = await tvSettingsModel.findActiveNow();

  let playlistId = activeSchedule ? activeSchedule.playlist_id : null;
  let displaySettings = activeSchedule
    ? {
        show_clock: activeSchedule.show_clock,
        show_weather: activeSchedule.show_weather,
        show_logo: activeSchedule.show_logo,
        call_volume: activeSchedule.call_volume,
        call_repeat_count: activeSchedule.call_repeat_count,
      }
    : DEFAULT_DISPLAY_SETTINGS;

  if (!playlistId) {
    const defaultPlaylist = await tvPlaylistModel.findDefault();
    playlistId = defaultPlaylist ? defaultPlaylist.id : null;
  }

  const items = playlistId ? await tvPlaylistModel.findItemsByPlaylistId(playlistId) : [];

  res.json({
    success: true,
    data: {
      clinicName: clinicSettings.clinic_name || 'عيادة أمراض النساء والتوليد ومتابعة الحمل',
      logoPath: clinicSettings.logo_path || null,
      weatherLat: clinicSettings.weather_lat || null,
      weatherLon: clinicSettings.weather_lon || null,
      display: displaySettings,
      playlist: items.map((i) => ({ id: i.media_id, title: i.title, url: `/media/${i.file_path}` })),
    },
  });
});

module.exports = { list, create, update, remove, getCurrentPublic };
