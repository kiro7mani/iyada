'use strict';

const statisticsModel = require('../models/statisticsModel');
const clinicSettingModel = require('../models/clinicSettingModel');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

function toDateString(d) {
  return d.toISOString().slice(0, 10);
}

function startOfWeek(date) {
  // الأسبوع يبدأ السبت (عرف شائع في الجزائر) وينتهي الجمعة
  const d = new Date(date);
  const day = d.getDay(); // 0=الأحد ... 6=السبت
  const diff = (day + 1) % 7; // عدد الأيام منذ آخر سبت
  d.setDate(d.getDate() - diff);
  return d;
}

async function buildFullReport(from, to) {
  const clinicSettings = await clinicSettingModel.getAll();
  const loyaltyThreshold = parseInt(clinicSettings.loyalty_visit_threshold, 10) || 5;

  const [patients, activity, financial, paymentMethods, topServices] = await Promise.all([
    statisticsModel.getPeriodPatientComposition(from, to, loyaltyThreshold),
    statisticsModel.getPeriodActivityCounts(from, to),
    statisticsModel.getPeriodFinancialSummary(from, to),
    statisticsModel.getPaymentMethodBreakdown(from, to),
    statisticsModel.getTopServices(from, to),
  ]);

  return {
    period: { from, to },
    patients,
    activity,
    financial,
    paymentMethods,
    topServices,
  };
}

const daily = asyncHandler(async (req, res) => {
  const date = req.query.date || toDateString(new Date());
  const report = await buildFullReport(date, date);
  res.json({ success: true, data: report });
});

const weekly = asyncHandler(async (req, res) => {
  const anchor = req.query.date ? new Date(req.query.date) : new Date();
  const start = startOfWeek(anchor);
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  const report = await buildFullReport(toDateString(start), toDateString(end));
  res.json({ success: true, data: report });
});

const monthly = asyncHandler(async (req, res) => {
  const now = new Date();
  const year = parseInt(req.query.year, 10) || now.getFullYear();
  const month = req.query.month ? parseInt(req.query.month, 10) : now.getMonth() + 1;

  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 0); // اليوم الأخير من الشهر
  const report = await buildFullReport(toDateString(start), toDateString(end));
  res.json({ success: true, data: report });
});

const yearly = asyncHandler(async (req, res) => {
  const year = parseInt(req.query.year, 10) || new Date().getFullYear();
  const start = new Date(year, 0, 1);
  const end = new Date(year, 11, 31);
  const report = await buildFullReport(toDateString(start), toDateString(end));
  res.json({ success: true, data: report });
});

const range = asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) {
    throw new AppError('يجب تحديد from و to.', 422, 'RANGE_REQUIRED');
  }
  if (new Date(from) > new Date(to)) {
    throw new AppError('تاريخ البداية يجب أن يكون قبل تاريخ النهاية.', 422, 'INVALID_RANGE');
  }
  const report = await buildFullReport(from, to);
  res.json({ success: true, data: report });
});

const loyalPatients = asyncHandler(async (req, res) => {
  const clinicSettings = await clinicSettingModel.getAll();
  const threshold = parseInt(clinicSettings.loyalty_visit_threshold, 10) || 5;
  const patients = await statisticsModel.getLoyalPatients(threshold);
  res.json({ success: true, data: { threshold, patients } });
});

module.exports = { daily, weekly, monthly, yearly, range, loyalPatients };
