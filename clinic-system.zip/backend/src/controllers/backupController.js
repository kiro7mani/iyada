'use strict';

const backupModel = require('../models/backupModel');
const { createBackup, getBackupAbsolutePath } = require('../services/backupService');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const list = asyncHandler(async (req, res) => {
  const backups = await backupModel.findAll();
  res.json({ success: true, data: backups });
});

const runManual = asyncHandler(async (req, res) => {
  const backup = await createBackup('MANUAL');

  await logAction({
    userId: req.user.id,
    action: 'CREATE_BACKUP',
    recordType: 'backups',
    recordId: backup.id,
  });

  res.status(201).json({ success: true, data: backup });
});

const download = asyncHandler(async (req, res) => {
  const backup = await backupModel.findById(req.params.id);
  if (!backup) {
    throw new AppError('النسخة الاحتياطية غير موجودة.', 404, 'NOT_FOUND');
  }

  const absolutePath = getBackupAbsolutePath(backup.file_path);

  await logAction({
    userId: req.user.id,
    action: 'DOWNLOAD_BACKUP',
    recordType: 'backups',
    recordId: backup.id,
  });

  res.download(absolutePath, backup.file_path, (err) => {
    if (err && !res.headersSent) {
      res
        .status(404)
        .json({ success: false, message: 'تعذر العثور على ملف النسخة الاحتياطية.', code: 'FILE_NOT_FOUND' });
    }
  });
});

/**
 * رفع نسخة احتياطية موجودة مسبقًا (ملف .zip) إلى مجلد النسخ — لأغراض النقل بين الأجهزة
 * أو استعادة نسخة محفوظة يدويًا خارج الجدولة التلقائية.
 */
const upload = asyncHandler(async (req, res) => {
  if (!req.file) {
    throw new AppError('يجب اختيار ملف نسخة احتياطية (ZIP) للرفع.', 422, 'FILE_REQUIRED');
  }

  const record = await backupModel.create({
    filePath: req.file.filename,
    type: 'UPLOADED',
    sizeBytes: req.file.size,
  });

  await logAction({
    userId: req.user.id,
    action: 'UPLOAD_BACKUP',
    recordType: 'backups',
    recordId: record.id,
  });

  res.status(201).json({ success: true, data: record });
});

module.exports = { list, runManual, download, upload };
