'use strict';

const serviceModel = require('../models/serviceModel');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const list = asyncHandler(async (req, res) => {
  const activeOnly = req.query.activeOnly === 'true';
  const services = await serviceModel.findAll({ activeOnly });
  res.json({ success: true, data: services });
});

const create = asyncHandler(async (req, res) => {
  const { name, defaultPrice } = req.body;
  const service = await serviceModel.create({ name, defaultPrice });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_SERVICE',
    recordType: 'services',
    recordId: service.id,
  });

  res.status(201).json({ success: true, data: service });
});

const update = asyncHandler(async (req, res) => {
  const { name, defaultPrice, isActive } = req.body;
  const updated = await serviceModel.update(req.params.id, { name, defaultPrice, isActive });
  if (!updated) {
    throw new AppError('الخدمة غير موجودة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_SERVICE',
    recordType: 'services',
    recordId: updated.id,
  });

  res.json({ success: true, data: updated });
});

/**
 * حذف خدمة نهائيًا. إذا كانت الخدمة استُخدمت سابقًا في زيارات (visit_services)،
 * قاعدة البيانات تمنع الحذف (ON DELETE RESTRICT) — نعرض رسالة واضحة بدل خطأ تقني.
 * أي خطأ آخر غير متوقع أثناء الحذف يُسجَّل في الطرفية للتشخيص، ويُعرض للمستخدم
 * برسالة عربية مفهومة بدل رسالة الخادم العامة.
 */
const remove = asyncHandler(async (req, res) => {
  let removed;
  try {
    removed = await serviceModel.remove(req.params.id);
  } catch (err) {
    const isForeignKeyViolation =
      err.code === '23503' || (err.message && err.message.toLowerCase().includes('foreign key'));
    if (isForeignKeyViolation) {
      throw new AppError(
        'لا يمكن حذف هذه الخدمة لأنها استُخدمت في زيارات سابقة. يمكنك تعطيلها بدلًا من حذفها.',
        409,
        'SERVICE_IN_USE'
      );
    }
    // eslint-disable-next-line no-console
    console.error('خطأ غير متوقع أثناء حذف خدمة:', err);
    throw new AppError('تعذر حذف الخدمة. حاول مجددًا، أو عطّلها بدلًا من ذلك.', 500, 'DELETE_FAILED');
  }

  if (!removed) {
    throw new AppError('الخدمة غير موجودة.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'DELETE_SERVICE',
    recordType: 'services',
    recordId: Number(req.params.id),
  });

  res.json({ success: true, message: 'تم حذف الخدمة.' });
});

module.exports = { list, create, update, remove };
