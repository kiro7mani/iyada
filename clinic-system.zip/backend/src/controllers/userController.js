'use strict';

const userModel = require('../models/userModel');
const roleModel = require('../models/roleModel');
const { hashPassword } = require('../auth/authService');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const list = asyncHandler(async (req, res) => {
  const users = await userModel.findAll();
  res.json({ success: true, data: users });
});

const create = asyncHandler(async (req, res) => {
  const { fullName, username, password, roleName } = req.body;

  const exists = await userModel.usernameExists(username);
  if (exists) {
    throw new AppError('اسم المستخدم هذا مستخدم بالفعل.', 409, 'USERNAME_TAKEN');
  }

  const role = await roleModel.findByName(roleName);
  if (!role) {
    throw new AppError('الدور المحدد غير موجود.', 422, 'INVALID_ROLE');
  }

  const passwordHash = await hashPassword(password);
  const newUser = await userModel.create({ fullName, username, passwordHash, roleId: role.id });

  await logAction({
    userId: req.user.id,
    action: 'CREATE_USER',
    recordType: 'users',
    recordId: newUser.id,
    details: { username, roleName },
  });

  res.status(201).json({ success: true, data: newUser });
});

const updateProfile = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { fullName, roleName, newPassword } = req.body;

  let roleId = null;
  if (roleName) {
    const role = await roleModel.findByName(roleName);
    if (!role) {
      throw new AppError('الدور المحدد غير موجود.', 422, 'INVALID_ROLE');
    }
    roleId = role.id;
  }

  const updated = await userModel.updateProfile(id, { fullName, roleId });
  if (!updated) {
    throw new AppError('المستخدم غير موجود.', 404, 'NOT_FOUND');
  }

  if (newPassword) {
    const newHash = await hashPassword(newPassword);
    await userModel.updatePassword(id, newHash);
  }

  await logAction({
    userId: req.user.id,
    action: 'UPDATE_USER',
    recordType: 'users',
    recordId: Number(id),
    details: { fullName, roleName, passwordChanged: !!newPassword },
  });

  res.json({ success: true, data: updated });
});

const deactivate = asyncHandler(async (req, res) => {
  const { id } = req.params;

  if (Number(id) === req.user.id) {
    throw new AppError('لا يمكنك إلغاء تفعيل حسابك الخاص.', 400, 'CANNOT_DEACTIVATE_SELF');
  }

  const updated = await userModel.setActive(id, false);
  if (!updated) {
    throw new AppError('المستخدم غير موجود.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'DEACTIVATE_USER',
    recordType: 'users',
    recordId: Number(id),
  });

  res.json({ success: true, data: updated });
});

const activate = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updated = await userModel.setActive(id, true);
  if (!updated) {
    throw new AppError('المستخدم غير موجود.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'ACTIVATE_USER',
    recordType: 'users',
    recordId: Number(id),
  });

  res.json({ success: true, data: updated });
});

/**
 * يسمح لأي مستخدم مسجّل دخول بتغيير كلمة مروره الخاصة (يتطلب كلمة المرور الحالية).
 */
const changeOwnPassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const { verifyPassword } = require('../auth/authService');

  const user = await userModel.findByUsername(req.user.username);
  const ok = await verifyPassword(currentPassword, user.password_hash);
  if (!ok) {
    throw new AppError('كلمة المرور الحالية غير صحيحة.', 401, 'INVALID_CREDENTIALS');
  }

  const newHash = await hashPassword(newPassword);
  await userModel.updatePassword(req.user.id, newHash);

  await logAction({
    userId: req.user.id,
    action: 'CHANGE_OWN_PASSWORD',
    recordType: 'users',
    recordId: req.user.id,
  });

  res.json({ success: true, message: 'تم تغيير كلمة المرور بنجاح.' });
});

/**
 * حذف مستخدم نهائيًا (Admin فقط). السجلات المرتبطة به (مريضات أنشأها، زيارات...)
 * تبقى محفوظة، حقل "أنشأها" فيها يصبح NULL فقط (ON DELETE SET NULL في قاعدة البيانات).
 */
const remove = asyncHandler(async (req, res) => {
  const { id } = req.params;

  if (Number(id) === req.user.id) {
    throw new AppError('لا يمكنك حذف حسابك الخاص.', 400, 'CANNOT_DELETE_SELF');
  }

  const removed = await userModel.remove(id);
  if (!removed) {
    throw new AppError('المستخدم غير موجود.', 404, 'NOT_FOUND');
  }

  await logAction({
    userId: req.user.id,
    action: 'DELETE_USER',
    recordType: 'users',
    recordId: Number(id),
  });

  res.json({ success: true, message: 'تم حذف المستخدم.' });
});

module.exports = { list, create, updateProfile, deactivate, activate, changeOwnPassword, remove };
