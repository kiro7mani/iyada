'use strict';

const env = require('../config/env');
const userModel = require('../models/userModel');
const { verifyPassword, signToken } = require('../auth/authService');
const { logAction } = require('../utils/auditLog');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const COOKIE_OPTIONS = {
  httpOnly: true,
  sameSite: 'lax',
  // secure: true يتطلب HTTPS فعليًا (عبر Reverse Proxy)، وإلا لن يُحفَظ الـ Cookie في المتصفح إطلاقًا.
  // يُفعَّل صراحةً عبر COOKIE_SECURE=true في .env عند توفر HTTPS، وليس تلقائيًا مع NODE_ENV=production.
  secure: env.auth.cookieSecure,
  maxAge: 12 * 60 * 60 * 1000, // 12 ساعة، يتوافق مع JWT_EXPIRES_IN الافتراضي
};

const login = asyncHandler(async (req, res) => {
  const { username, password } = req.body;

  const user = await userModel.findByUsername(username);
  if (!user) {
    throw new AppError('اسم المستخدم أو كلمة المرور غير صحيحة.', 401, 'INVALID_CREDENTIALS');
  }
  if (!user.is_active) {
    throw new AppError('هذا الحساب غير مفعّل، الرجاء التواصل مع الإدارة.', 403, 'ACCOUNT_INACTIVE');
  }

  const passwordOk = await verifyPassword(password, user.password_hash);
  if (!passwordOk) {
    await logAction({
      userId: null,
      action: 'LOGIN_FAILED',
      recordType: 'users',
      recordId: user.id,
      details: { username },
    });
    throw new AppError('اسم المستخدم أو كلمة المرور غير صحيحة.', 401, 'INVALID_CREDENTIALS');
  }

  const token = signToken(user);
  res.cookie(env.auth.cookieName, token, COOKIE_OPTIONS);

  await logAction({ userId: user.id, action: 'LOGIN', recordType: 'users', recordId: user.id });

  res.json({
    success: true,
    data: {
      id: user.id,
      fullName: user.full_name,
      username: user.username,
      role: user.role_name,
    },
  });
});

const logout = asyncHandler(async (req, res) => {
  if (req.user) {
    await logAction({ userId: req.user.id, action: 'LOGOUT', recordType: 'users', recordId: req.user.id });
  }
  res.clearCookie(env.auth.cookieName, { httpOnly: true, sameSite: 'lax', secure: env.auth.cookieSecure });
  res.json({ success: true, message: 'تم تسجيل الخروج بنجاح.' });
});

const me = asyncHandler(async (req, res) => {
  res.json({ success: true, data: req.user });
});

module.exports = { login, logout, me };
