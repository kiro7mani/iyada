'use strict';

/**
 * يغلّف دالة controller غير متزامنة، ويمرر أي خطأ إلى next() تلقائيًا
 * بدلاً من كتابة try/catch في كل controller.
 * @param {Function} fn
 */
function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = asyncHandler;
