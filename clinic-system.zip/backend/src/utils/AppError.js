'use strict';

class AppError extends Error {
  /**
   * @param {string} message - رسالة موجهة للمستخدم (يفضل بالعربية)
   * @param {number} statusCode
   * @param {string} [code] - كود قصير يمكن للـ Frontend الاعتماد عليه
   */
  constructor(message, statusCode = 400, code = 'ERROR') {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = AppError;
