'use strict';

const { query } = require('../config/db');

/**
 * تسجيل عملية حساسة في Audit Log.
 * لا يجب أن يفشل الطلب الأصلي أبدًا بسبب فشل تسجيل الـ Audit — نلتقط الخطأ ونطبعه فقط.
 *
 * @param {object} params
 * @param {number|null} params.userId
 * @param {string} params.action - مثل CREATE_PATIENT, CALL_PATIENT, MODIFY_PRICE
 * @param {string} [params.recordType]
 * @param {number} [params.recordId]
 * @param {object} [params.details]
 */
async function logAction({ userId, action, recordType = null, recordId = null, details = null }) {
  try {
    await query(
      `INSERT INTO audit_logs (user_id, action, record_type, record_id, details)
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, action, recordType, recordId, details ? JSON.stringify(details) : null]
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('فشل تسجيل Audit Log:', err.message, { action, recordType, recordId });
  }
}

module.exports = { logAction };
