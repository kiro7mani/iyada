'use strict';

/**
 * يُخطر واجهات الاستقبال/الطبيبة/التلفاز بأن قائمة الانتظار تغيّرت،
 * ليعيدوا جلب /api/queue/today. لا يحمل بيانات ثقيلة عمدًا.
 */
function emitQueueUpdated(app) {
  const io = app.locals.io;
  if (!io) return;
  io.to('reception').to('doctor').to('tv').emit('queue_updated');
}

/**
 * يُخطر بأن مريضة استُدعيت (استدعاء جديد أو إعادة استدعاء).
 */
function emitPatientCalled(app, { queueNumber, visitId }, isRecall = false) {
  const io = app.locals.io;
  if (!io) return;
  const eventName = isRecall ? 'patient_recalled' : 'patient_called';
  io.to('tv').to('doctor').to('reception').emit(eventName, { queueNumber, visitId });
}

/**
 * أوامر تحكم يدوية بشاشة التلفاز (تشغيل/إيقاف/تالي/سابق/كتم/صوت) —
 * تُرسل من لوحة الاستقبال أو الطبيبة عبر REST، وتُبَث لغرفة 'tv' فقط.
 */
function emitTvControl(app, event, payload = {}) {
  const io = app.locals.io;
  if (!io) return;
  io.to('tv').emit(event, payload);
}

/**
 * استدعاء الممرضة من الطبيبة → إشعار مستمر في لوحة الاستقبال حتى يُضغَط عليه.
 */
function emitNurseCallRequested(app) {
  const io = app.locals.io;
  if (!io) return;
  io.to('reception').emit('nurse_call_requested');
}

/**
 * تأكيد الاستقبال للاستدعاء → إشعار قصير في لوحة الطبيبة "جاري الاستجابة".
 */
function emitNurseCallAcknowledged(app) {
  const io = app.locals.io;
  if (!io) return;
  io.to('doctor').emit('nurse_call_acknowledged');
}

module.exports = {
  emitQueueUpdated,
  emitPatientCalled,
  emitTvControl,
  emitNurseCallRequested,
  emitNurseCallAcknowledged,
};
