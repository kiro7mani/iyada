'use strict';

const express = require('express');
const { param } = require('express-validator');
const labController = require('../controllers/labController');
const { requireAuth } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

router.get('/:id/file', [param('id').isInt()], validate, labController.getFile);

module.exports = router;
