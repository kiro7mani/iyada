'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const userController = require('../controllers/userController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

// كل المسارات هنا تتطلب تسجيل دخول
router.use(requireAuth);

router.get('/', requireRole('admin'), userController.list);

router.post(
  '/',
  requireRole('admin'),
  [
    body('fullName').trim().notEmpty().withMessage('الاسم الكامل مطلوب.'),
    body('username').trim().isLength({ min: 3 }).withMessage('اسم المستخدم يجب أن يكون 3 أحرف على الأقل.'),
    body('password').isLength({ min: 8 }).withMessage('كلمة المرور يجب أن تكون 8 أحرف على الأقل.'),
    body('roleName').isIn(['admin', 'reception', 'doctor']).withMessage('الدور غير صالح.'),
  ],
  validate,
  userController.create
);

router.put(
  '/:id',
  requireRole('admin'),
  [
    param('id').isInt().withMessage('معرّف غير صالح.'),
    body('newPassword').optional({ nullable: true }).isLength({ min: 8 }).withMessage('كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.'),
  ],
  validate,
  userController.updateProfile
);

router.delete(
  '/:id',
  requireRole('admin'),
  [param('id').isInt().withMessage('معرّف غير صالح.')],
  validate,
  userController.remove
);

router.put(
  '/:id/deactivate',
  requireRole('admin'),
  [param('id').isInt().withMessage('معرّف غير صالح.')],
  validate,
  userController.deactivate
);

router.put(
  '/:id/activate',
  requireRole('admin'),
  [param('id').isInt().withMessage('معرّف غير صالح.')],
  validate,
  userController.activate
);

// أي مستخدم مسجّل دخول يستطيع تغيير كلمة مروره الخاصة
router.put(
  '/me/password',
  [
    body('currentPassword').notEmpty().withMessage('كلمة المرور الحالية مطلوبة.'),
    body('newPassword').isLength({ min: 8 }).withMessage('كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.'),
  ],
  validate,
  userController.changeOwnPassword
);

module.exports = router;
