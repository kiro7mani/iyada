'use strict';

const express = require('express');
const { query: queryValidator } = require('express-validator');
const statisticsController = require('../controllers/statisticsController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);
router.use(requireRole('admin', 'doctor'));

router.get('/daily', [queryValidator('date').optional().isISO8601()], validate, statisticsController.daily);

router.get('/weekly', [queryValidator('date').optional().isISO8601()], validate, statisticsController.weekly);

router.get(
  '/monthly',
  [
    queryValidator('year').optional().isInt({ min: 2000, max: 2100 }),
    queryValidator('month').optional().isInt({ min: 1, max: 12 }),
  ],
  validate,
  statisticsController.monthly
);

router.get('/yearly', [queryValidator('year').optional().isInt({ min: 2000, max: 2100 })], validate, statisticsController.yearly);

router.get(
  '/range',
  [queryValidator('from').isISO8601(), queryValidator('to').isISO8601()],
  validate,
  statisticsController.range
);

router.get('/loyal-patients', statisticsController.loyalPatients);

module.exports = router;
