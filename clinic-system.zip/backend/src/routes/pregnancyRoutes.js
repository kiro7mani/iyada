'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const pregnancyController = require('../controllers/pregnancyController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

router.get('/:id', [param('id').isInt()], validate, pregnancyController.getById);

router.put(
  '/:id',
  requireRole('admin', 'doctor'),
  [param('id').isInt()],
  validate,
  pregnancyController.update
);

router.put(
  '/:id/status',
  requireRole('admin', 'doctor'),
  [param('id').isInt(), body('status').isIn(['ACTIVE', 'DELIVERED', 'TERMINATED'])],
  validate,
  pregnancyController.updateStatus
);

router.post(
  '/:id/visits',
  requireRole('admin', 'doctor'),
  [param('id').isInt(), body('visitId').isInt().withMessage('معرّف الزيارة مطلوب.')],
  validate,
  pregnancyController.addVisit
);

module.exports = router;
