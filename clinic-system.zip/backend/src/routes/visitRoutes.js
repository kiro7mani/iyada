'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const visitController = require('../controllers/visitController');
const radiologyController = require('../controllers/radiologyController');
const labController = require('../controllers/labController');
const billingController = require('../controllers/billingController');
const prescriptionController = require('../controllers/prescriptionController');
const { radiologyUpload, labUpload } = require('../services/uploadService');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

router.get('/:id', [param('id').isInt()], validate, visitController.getById);

// بطاقة الملخص الطبي (المرحلة الأولى من واجهة الطبيبة)
router.get('/:id/summary', [param('id').isInt()], validate, visitController.getSummary);

router.put(
  '/:id/measurements',
  requireRole('admin', 'reception'),
  [param('id').isInt()],
  validate,
  visitController.updateMeasurements
);

router.put(
  '/:id/examination',
  requireRole('admin', 'doctor'),
  [param('id').isInt()],
  validate,
  visitController.updateExamination
);

// ---- الأشعة والإيكوغرافي (مرتبطة بزيارة) ----
router.post(
  '/:id/radiology',
  requireRole('admin', 'doctor'),
  radiologyUpload.single('file'),
  [param('id').isInt()],
  validate,
  radiologyController.upload
);
router.get('/:id/radiology', [param('id').isInt()], validate, radiologyController.listByVisit);

// ---- التحاليل (مرتبطة بزيارة) ----
router.post(
  '/:id/labs',
  requireRole('admin', 'doctor'),
  labUpload.single('file'),
  [param('id').isInt(), body('testName').notEmpty().withMessage('اسم التحليل مطلوب.')],
  validate,
  labController.create
);
router.get('/:id/labs', [param('id').isInt()], validate, labController.listByVisit);

// ---- الخدمات والتخفيض (تُضاف ضمن نافذة "إنهاء الفحص") ----
router.get('/:id/services', [param('id').isInt()], validate, billingController.listServices);
router.post(
  '/:id/services',
  requireRole('admin', 'doctor'),
  [param('id').isInt(), body('serviceId').isInt().withMessage('معرّف الخدمة مطلوب.')],
  validate,
  billingController.addService
);
router.delete(
  '/:id/services/:serviceLineId',
  requireRole('admin', 'doctor'),
  [param('id').isInt(), param('serviceLineId').isInt()],
  validate,
  billingController.removeService
);

router.post(
  '/:id/discount',
  requireRole('admin', 'doctor'),
  [
    param('id').isInt(),
    body('type').isIn(['FIXED', 'PERCENTAGE']).withMessage('نوع التخفيض غير صالح.'),
    body('value').isFloat({ min: 0 }).withMessage('قيمة التخفيض غير صالحة.'),
  ],
  validate,
  billingController.setDiscount
);

// "تأكيد وإنهاء الفحص": WITH_DOCTOR → AWAITING_PAYMENT
router.post(
  '/:id/confirm-finish-exam',
  requireRole('admin', 'doctor'),
  [param('id').isInt()],
  validate,
  billingController.confirmFinishExam
);

router.get('/:id/invoice', [param('id').isInt()], validate, billingController.getInvoice);

// "تخليص": دفعة واحدة تُوزَّع تلقائيًا على الأرصدة القديمة ثم الزيارة الحالية
router.post(
  '/:id/checkout',
  requireRole('admin', 'reception'),
  [
    param('id').isInt(),
    body('amountPaidNow').isFloat({ min: 0 }).withMessage('المبلغ غير صالح.'),
    body('method').isIn(['CASH', 'CARD', 'OTHER']).withMessage('طريقة الدفع غير صالحة.'),
  ],
  validate,
  billingController.checkout
);

router.get('/:id/receipt/print', [param('id').isInt()], validate, billingController.printReceipt);

// ---- الوصفات الطبية ----
router.post(
  '/:id/prescriptions',
  requireRole('admin', 'doctor'),
  [param('id').isInt(), body('items').isArray({ min: 1 }).withMessage('يجب إضافة دواء واحد على الأقل.')],
  validate,
  prescriptionController.create
);
router.get('/:id/prescriptions', [param('id').isInt()], validate, prescriptionController.listByVisit);

module.exports = router;
