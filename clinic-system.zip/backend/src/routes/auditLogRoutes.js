'use strict';

const express = require('express');
const auditLogController = require('../controllers/auditLogController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');

const router = express.Router();

router.use(requireAuth);
router.use(requireRole('admin'));

router.get('/', auditLogController.list);

module.exports = router;
