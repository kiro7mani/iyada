'use strict';

const express = require('express');
const { param } = require('express-validator');
const radiologyController = require('../controllers/radiologyController');
const { requireAuth } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

router.get('/:id/file', [param('id').isInt()], validate, radiologyController.getFile);

module.exports = router;
