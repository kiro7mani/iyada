'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const queueController = require('../controllers/queueController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

// قائمة انتظار اليوم: متاحة لكل الأدوار (الاستقبال، الطبيبة، الإدارة)
router.get('/today', queueController.today);

router.post(
  '/book',
  requireRole('admin', 'reception'),
  [
    body('patientId').isInt().withMessage('معرّف المريضة مطلوب.'),
    body('visitType').optional().isString(),
    body('presentNow').optional().isBoolean(),
  ],
  validate,
  queueController.book
);

router.post(
  '/confirm-presence/:visitId',
  requireRole('admin', 'reception'),
  [param('visitId').isInt()],
  validate,
  queueController.confirmPresence
);

router.post(
  '/cancel/:visitId',
  requireRole('admin', 'reception'),
  [param('visitId').isInt()],
  validate,
  queueController.cancel
);

router.post(
  '/no-show/:visitId',
  requireRole('admin', 'reception'),
  [param('visitId').isInt()],
  validate,
  queueController.markNoShow
);

router.post(
  '/print-ticket/:visitId',
  requireRole('admin', 'reception'),
  [param('visitId').isInt()],
  validate,
  queueController.printTicket
);

router.post('/test-printer', requireRole('admin', 'reception'), queueController.testPrinterConnection);

router.post('/call-next', requireRole('doctor', 'admin'), queueController.callNext);

router.post(
  '/recall/:visitId',
  requireRole('doctor', 'admin'),
  [param('visitId').isInt()],
  validate,
  queueController.recall
);

router.post(
  '/start-exam/:visitId',
  requireRole('doctor', 'admin'),
  [param('visitId').isInt()],
  validate,
  queueController.startExam
);

module.exports = router;
