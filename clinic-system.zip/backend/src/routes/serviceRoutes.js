'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const serviceController = require('../controllers/serviceController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

router.get('/', serviceController.list);

router.post(
  '/',
  requireRole('admin'),
  [
    body('name').trim().notEmpty().withMessage('اسم الخدمة مطلوب.'),
    body('defaultPrice').isFloat({ min: 0 }).withMessage('السعر الافتراضي غير صالح.'),
  ],
  validate,
  serviceController.create
);

router.put(
  '/:id',
  requireRole('admin'),
  [param('id').isInt()],
  validate,
  serviceController.update
);

router.delete(
  '/:id',
  requireRole('admin'),
  [param('id').isInt()],
  validate,
  serviceController.remove
);

module.exports = router;
