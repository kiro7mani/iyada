'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const medicationController = require('../controllers/medicationController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

// البحث/القائمة متاحة لكل الأدوار (الطبيبة تحتاجها عند وصف الدواء)
router.get('/', medicationController.list);

router.post(
  '/',
  requireRole('admin'),
  [body('name').trim().notEmpty().withMessage('اسم الدواء مطلوب.')],
  validate,
  medicationController.create
);

router.put('/:id', requireRole('admin'), [param('id').isInt()], validate, medicationController.update);

router.delete('/:id', requireRole('admin'), [param('id').isInt()], validate, medicationController.remove);

module.exports = router;
