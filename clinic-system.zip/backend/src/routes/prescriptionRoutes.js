'use strict';

const express = require('express');
const { param } = require('express-validator');
const prescriptionController = require('../controllers/prescriptionController');
const { requireAuth } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

router.get('/:id/print', [param('id').isInt()], validate, prescriptionController.printPrescription);

module.exports = router;
