'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const tvMediaController = require('../controllers/tvMediaController');
const tvPlaylistController = require('../controllers/tvPlaylistController');
const tvSettingsController = require('../controllers/tvSettingsController');
const tvControlController = require('../controllers/tvControlController');
const { videoUpload } = require('../services/uploadService');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

// ---- نقطة عامة: تستخدمها شاشة /tv نفسها، بدون تسجيل دخول (القسم 61) ----
router.get('/playlist/current', tvSettingsController.getCurrentPublic);

// ---- كل ما بعد هذا السطر يتطلب تسجيل دخول ----
router.use(requireAuth);

// ---- إدارة الفيديوهات (Admin فقط، القسم 23 و69) ----
router.get('/media', requireRole('admin'), tvMediaController.list);
router.post('/media', requireRole('admin'), videoUpload.single('file'), tvMediaController.upload);
router.delete('/media/:id', requireRole('admin'), [param('id').isInt()], validate, tvMediaController.remove);

// ---- إدارة الـ Playlists (Admin فقط) ----
router.get('/playlists', requireRole('admin'), tvPlaylistController.list);
router.post(
  '/playlists',
  requireRole('admin'),
  [body('name').trim().notEmpty().withMessage('اسم القائمة مطلوب.')],
  validate,
  tvPlaylistController.create
);
router.put(
  '/playlists/:id/default',
  requireRole('admin'),
  [param('id').isInt()],
  validate,
  tvPlaylistController.setDefault
);
router.get('/playlists/:id', requireRole('admin'), [param('id').isInt()], validate, tvPlaylistController.getItems);
router.post(
  '/playlists/:id/items',
  requireRole('admin'),
  [param('id').isInt(), body('mediaId').isInt().withMessage('معرّف الفيديو مطلوب.')],
  validate,
  tvPlaylistController.addItem
);
router.delete(
  '/playlists/:id/items/:itemId',
  requireRole('admin'),
  [param('id').isInt(), param('itemId').isInt()],
  validate,
  tvPlaylistController.removeItem
);

// ---- الجدولة الزمنية (Admin فقط، القسم 24) ----
router.get('/settings', requireRole('admin'), tvSettingsController.list);
router.post(
  '/settings',
  requireRole('admin'),
  [
    body('startTime').notEmpty().withMessage('وقت البداية مطلوب.'),
    body('endTime').notEmpty().withMessage('وقت النهاية مطلوب.'),
  ],
  validate,
  tvSettingsController.create
);
router.put('/settings/:id', requireRole('admin'), [param('id').isInt()], validate, tvSettingsController.update);
router.delete('/settings/:id', requireRole('admin'), [param('id').isInt()], validate, tvSettingsController.remove);

// ---- التحكم اليدوي (الاستقبال + الطبيبة + الإدارة، القسم 25-27 و69) ----
router.post('/control/play', tvControlController.play);
router.post('/control/pause', tvControlController.pause);
router.post('/control/next', tvControlController.next);
router.post('/control/previous', tvControlController.previous);
router.post('/control/mute', tvControlController.mute);
router.post('/control/unmute', tvControlController.unmute);
router.post(
  '/control/volume',
  [body('level').isInt({ min: 0, max: 100 }).withMessage('مستوى الصوت يجب أن يكون بين 0 و100.')],
  validate,
  tvControlController.setVolume
);
router.post('/control/test-announcement', tvControlController.testAnnouncement);

module.exports = router;
