'use strict';

const express = require('express');
const doctorBreakController = require('../controllers/doctorBreakController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');

const router = express.Router();

router.use(requireAuth);

router.get('/status', doctorBreakController.getStatus);
router.post('/start', requireRole('doctor', 'admin'), doctorBreakController.start);
router.post('/end', requireRole('doctor', 'admin'), doctorBreakController.end);

module.exports = router;
