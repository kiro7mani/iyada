'use strict';

const express = require('express');
const { param } = require('express-validator');
const backupController = require('../controllers/backupController');
const { createBackupUploadMulter } = require('../services/backupService');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);
router.use(requireRole('admin'));

router.get('/', backupController.list);
router.post('/run', backupController.runManual);
router.get('/:id/download', [param('id').isInt()], validate, backupController.download);
router.post('/upload', createBackupUploadMulter().single('file'), backupController.upload);

module.exports = router;
