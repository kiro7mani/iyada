'use strict';

const express = require('express');
const clinicSettingModel = require('../models/clinicSettingModel');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get(
  '/clinic-info',
  asyncHandler(async (req, res) => {
    const settings = await clinicSettingModel.getAll();
    res.json({
      success: true,
      data: {
        clinicName: settings.clinic_name || 'عيادة أمراض النساء والتوليد ومتابعة الحمل',
        logoPath: settings.logo_path || null,
      },
    });
  })
);

module.exports = router;
