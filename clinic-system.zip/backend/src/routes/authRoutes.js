'use strict';

const express = require('express');
const { body } = require('express-validator');
const authController = require('../controllers/authController');
const { requireAuth } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.post(
  '/login',
  [
    body('username').trim().notEmpty().withMessage('اسم المستخدم مطلوب.'),
    body('password').notEmpty().withMessage('كلمة المرور مطلوبة.'),
  ],
  validate,
  authController.login
);

router.post('/logout', requireAuth, authController.logout);
router.get('/me', requireAuth, authController.me);

module.exports = router;
