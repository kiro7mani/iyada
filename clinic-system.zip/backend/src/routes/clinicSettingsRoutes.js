'use strict';

const express = require('express');
const clinicSettingsController = require('../controllers/clinicSettingsController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');

const router = express.Router();

router.use(requireAuth);

// كل الأدوار المسجّلة تستطيع قراءة الإعدادات (اسم العيادة، الشعار... تظهر في كل الواجهات)
router.get('/', clinicSettingsController.getSettings);

// التعديل بصلاحية Admin فقط
router.put('/', requireRole('admin'), clinicSettingsController.updateSettings);

module.exports = router;
