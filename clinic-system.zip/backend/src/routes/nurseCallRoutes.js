'use strict';

const express = require('express');
const nurseCallController = require('../controllers/nurseCallController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');

const router = express.Router();

router.use(requireAuth);

router.post('/request', requireRole('doctor', 'admin'), nurseCallController.request);
router.post('/acknowledge', requireRole('reception', 'admin'), nurseCallController.acknowledge);

module.exports = router;
