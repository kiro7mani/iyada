'use strict';

const express = require('express');
const { body, param, query: queryValidator } = require('express-validator');
const patientController = require('../controllers/patientController');
const visitController = require('../controllers/visitController');
const pregnancyController = require('../controllers/pregnancyController');
const radiologyController = require('../controllers/radiologyController');
const labController = require('../controllers/labController');
const { requireAuth, requireRole } = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

router.use(requireAuth);

// البحث والعرض متاح لكل الأدوار المسجّلة (admin, reception, doctor)
router.get('/', [queryValidator('birthDate').optional().isISO8601()], validate, patientController.search);

router.get('/by-qr/:token', patientController.getByQrToken);

router.get('/:id', [param('id').isInt()], validate, patientController.getById);

router.get('/:id/qr', [param('id').isInt()], validate, patientController.getQrImage);

router.get('/:id/medical-file/print', [param('id').isInt()], validate, patientController.printMedicalFile);

// الإنشاء والتعديل: admin و reception فقط
router.post(
  '/check-duplicate',
  requireRole('admin', 'reception'),
  [
    body('firstName').trim().notEmpty().withMessage('الاسم مطلوب.'),
    body('lastName').trim().notEmpty().withMessage('اللقب مطلوب.'),
    body('birthDate').optional({ nullable: true }).isISO8601().withMessage('تاريخ ميلاد غير صالح.'),
  ],
  validate,
  patientController.checkDuplicate
);

router.post(
  '/',
  requireRole('admin', 'reception'),
  [
    body('firstName').trim().notEmpty().withMessage('الاسم مطلوب.'),
    body('lastName').trim().notEmpty().withMessage('اللقب مطلوب.'),
    body('birthDate').optional({ nullable: true }).isISO8601().withMessage('تاريخ ميلاد غير صالح.'),
    body('phone').optional({ nullable: true }).isString(),
    body('forceCreate').optional().isBoolean(),
  ],
  validate,
  patientController.create
);

router.put(
  '/:id',
  requireRole('admin', 'reception'),
  [param('id').isInt(), body('birthDate').optional({ nullable: true }).isISO8601()],
  validate,
  patientController.update
);

// حذف حساب مريضة نهائيًا: Admin فقط
router.delete(
  '/:id',
  requireRole('admin'),
  [param('id').isInt()],
  validate,
  patientController.remove
);

// ---- السجل الطبي الكامل (زيارات/حمل/أشعة/تحاليل) ----
router.get('/:id/visits', [param('id').isInt()], validate, visitController.listByPatient);

router.get('/:id/pregnancies', [param('id').isInt()], validate, pregnancyController.listByPatient);
router.post(
  '/:id/pregnancies',
  requireRole('admin', 'doctor'),
  [param('id').isInt(), body('lmpDate').optional({ nullable: true }).isISO8601()],
  validate,
  pregnancyController.create
);

router.get('/:id/radiology', [param('id').isInt()], validate, radiologyController.listByPatient);
router.get('/:id/labs', [param('id').isInt()], validate, labController.listByPatient);

module.exports = router;
