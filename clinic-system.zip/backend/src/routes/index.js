'use strict';

const express = require('express');
const authRoutes = require('./authRoutes');
const userRoutes = require('./userRoutes');
const clinicSettingsRoutes = require('./clinicSettingsRoutes');
const patientRoutes = require('./patientRoutes');
const queueRoutes = require('./queueRoutes');
const visitRoutes = require('./visitRoutes');
const pregnancyRoutes = require('./pregnancyRoutes');
const radiologyRoutes = require('./radiologyRoutes');
const labRoutes = require('./labRoutes');
const serviceRoutes = require('./serviceRoutes');
const prescriptionRoutes = require('./prescriptionRoutes');
const statisticsRoutes = require('./statisticsRoutes');
const tvRoutes = require('./tvRoutes');
const publicRoutes = require('./publicRoutes');
const backupRoutes = require('./backupRoutes');
const auditLogRoutes = require('./auditLogRoutes');
const adminRoutes = require('./adminRoutes');
const medicationRoutes = require('./medicationRoutes');
const nurseCallRoutes = require('./nurseCallRoutes');
const doctorBreakRoutes = require('./doctorBreakRoutes');

const router = express.Router();

router.get('/health', (req, res) => {
  res.json({ success: true, message: 'الخادم يعمل بشكل طبيعي.' });
});

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/clinic-settings', clinicSettingsRoutes);
router.use('/patients', patientRoutes);
router.use('/queue', queueRoutes);
router.use('/visits', visitRoutes);
router.use('/pregnancies', pregnancyRoutes);
router.use('/radiology', radiologyRoutes);
router.use('/labs', labRoutes);
router.use('/services', serviceRoutes);
router.use('/prescriptions', prescriptionRoutes);
router.use('/statistics', statisticsRoutes);
router.use('/tv', tvRoutes);
router.use('/public', publicRoutes);
router.use('/backups', backupRoutes);
router.use('/audit-logs', auditLogRoutes);
router.use('/admin', adminRoutes);
router.use('/medications', medicationRoutes);
router.use('/nurse-call', nurseCallRoutes);
router.use('/doctor-break', doctorBreakRoutes);

module.exports = router;
