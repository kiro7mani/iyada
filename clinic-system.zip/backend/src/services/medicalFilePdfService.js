'use strict';

const PDFDocument = require('pdfkit');
const QRCode = require('qrcode');

function formatDateArabic(dateValue) {
  if (!dateValue) return '—';
  const d = new Date(dateValue);
  return d.toLocaleDateString('ar-DZ', { year: 'numeric', month: '2-digit', day: '2-digit' });
}

/**
 * يرسم محتوى نصف الصفحة (يُستخدم مرتين: النصف العلوي والنصف السفلي المقلوب).
 */
function drawHalf(doc, area, patient, clinicSettings, qrBuffer) {
  const { x, y, width, height } = area;
  const padding = 40;
  const centerWidth = width - padding * 2;

  // شعار / اسم العيادة
  doc
    .fillColor('#111827')
    .font('Helvetica-Bold')
    .fontSize(20)
    .text(clinicSettings.clinic_name || 'عيادة أمراض النساء والتوليد ومتابعة الحمل', x + padding, y + padding, {
      width: centerWidth,
      align: 'center',
    });

  doc
    .font('Helvetica')
    .fontSize(11)
    .fillColor('#4b5563')
    .text('عيادة أمراض النساء والتوليد ومتابعة الحمل', x + padding, y + padding + 28, {
      width: centerWidth,
      align: 'center',
    });

  // خط فاصل
  doc
    .moveTo(x + padding, y + padding + 55)
    .lineTo(x + width - padding, y + padding + 55)
    .strokeColor('#d1d5db')
    .lineWidth(1)
    .stroke();

  // بيانات المريضة
  doc
    .font('Helvetica-Bold')
    .fontSize(16)
    .fillColor('#111827')
    .text(`${patient.first_name} ${patient.last_name}`, x + padding, y + padding + 72, {
      width: centerWidth,
      align: 'center',
    });

  doc
    .font('Helvetica')
    .fontSize(13)
    .fillColor('#374151')
    .text(`رقم الملف الطبي: ${patient.medical_file_number}`, x + padding, y + padding + 100, {
      width: centerWidth,
      align: 'center',
    });

  doc
    .fontSize(10)
    .fillColor('#6b7280')
    .text(`تاريخ إنشاء الملف: ${formatDateArabic(patient.created_at)}`, x + padding, y + padding + 122, {
      width: centerWidth,
      align: 'center',
    });

  // QR Code
  if (qrBuffer) {
    const qrSize = 85;
    doc.image(qrBuffer, x + width / 2 - qrSize / 2, y + height - qrSize - 28, {
      width: qrSize,
      height: qrSize,
    });
  }
}

/**
 * يولّد PDF بحجم A4 (Portrait) يحتوي على نصفين متطابقين (علوي وسفلي مقلوب 180°)،
 * بحيث عند طي الورقة من المنتصف يظهر الملف الطبي بشكل صحيح على شكل A5.
 *
 * @param {object} params
 * @param {object} params.patient - يجب أن يحتوي على qr_token
 * @param {object} params.clinicSettings - Key/Value من جدول clinic_settings
 */
async function generateMedicalFilePdf({ patient, clinicSettings }) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: 'A4', margin: 0 });
      const buffers = [];
      doc.on('data', (chunk) => buffers.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(buffers)));
      doc.on('error', reject);

      const pageWidth = doc.page.width;
      const pageHeight = doc.page.height;
      const halfHeight = pageHeight / 2;

      QRCode.toBuffer(patient.qr_token || patient.medical_file_number, {
        type: 'png',
        width: 300,
        margin: 0,
      })
        .then((qrBuffer) => {
          // خط الطي المنقّط في المنتصف
          doc.save();
          doc.dash(4, { space: 4 });
          doc
            .moveTo(0, halfHeight)
            .lineTo(pageWidth, halfHeight)
            .strokeColor('#9ca3af')
            .lineWidth(0.75)
            .stroke();
          doc.undash();
          doc.restore();

          doc
            .fontSize(7)
            .fillColor('#9ca3af')
            .text('✂ اطوِ من هنا', pageWidth - 90, halfHeight - 9, { width: 80, align: 'right' });

          // النصف العلوي
          drawHalf(doc, { x: 0, y: 0, width: pageWidth, height: halfHeight }, patient, clinicSettings, qrBuffer);

          // النصف السفلي، مقلوب 180° حول مركزه ليصبح مقروءًا بشكل صحيح بعد الطي
          doc.save();
          doc.rotate(180, { origin: [pageWidth / 2, pageHeight - halfHeight / 2] });
          drawHalf(
            doc,
            { x: 0, y: halfHeight, width: pageWidth, height: halfHeight },
            patient,
            clinicSettings,
            qrBuffer
          );
          doc.restore();

          doc.end();
        })
        .catch(reject);
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = { generateMedicalFilePdf };
