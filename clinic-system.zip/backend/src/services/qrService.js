'use strict';

const crypto = require('crypto');
const QRCode = require('qrcode');

/**
 * يولّد Token عشوائي آمن (48 حرف hex) لا يحتوي على أي بيانات شخصية أو طبية.
 * هذا هو المحتوى الوحيد الذي يُشفَّر داخل QR الخاص بالمريضة.
 */
function generateToken() {
  return crypto.randomBytes(24).toString('hex');
}

/**
 * يولّد صورة QR (PNG Buffer) من Token فقط.
 */
async function generateQrPngBuffer(token) {
  return QRCode.toBuffer(token, {
    type: 'png',
    width: 400,
    margin: 1,
    errorCorrectionLevel: 'M',
  });
}

module.exports = { generateToken, generateQrPngBuffer };
