'use strict';

const cron = require('node-cron');
const env = require('../config/env');
const { createBackup } = require('../services/backupService');

/**
 * جدولة نسخ احتياطي تلقائي:
 *  - يومي: كل يوم الساعة 02:00
 *  - أسبوعي: كل يوم أحد الساعة 02:30
 *  - شهري: أول يوم من كل شهر الساعة 03:00
 * يمكن تعطيلها بالكامل عبر BACKUP_SCHEDULING_ENABLED=false في .env
 */
function startBackupScheduler() {
  if (!env.backup.schedulingEnabled) {
    // eslint-disable-next-line no-console
    console.log('⏭ الجدولة التلقائية للنسخ الاحتياطي معطّلة (BACKUP_SCHEDULING_ENABLED=false).');
    return;
  }

  cron.schedule('0 2 * * *', () => runScheduled('DAILY'));
  cron.schedule('30 2 * * 0', () => runScheduled('WEEKLY'));
  cron.schedule('0 3 1 * *', () => runScheduled('MONTHLY'));

  // eslint-disable-next-line no-console
  console.log('✔ جدولة النسخ الاحتياطي التلقائي مفعّلة (يومي 02:00، أسبوعي أحد 02:30، شهري أول الشهر 03:00).');
}

async function runScheduled(type) {
  try {
    await createBackup(type);
    // eslint-disable-next-line no-console
    console.log(`✔ نسخة احتياطية تلقائية (${type}) تمت بنجاح.`);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`✘ فشلت النسخة الاحتياطية التلقائية (${type}):`, err.message);
  }
}

module.exports = { startBackupScheduler };
