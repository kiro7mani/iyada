'use strict';

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const env = require('../config/env');
const backupModel = require('../models/backupModel');
const AppError = require('../utils/AppError');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function runPgDump(outputSqlPath) {
  return new Promise((resolve, reject) => {
    const cmd = `"${env.backup.pgDumpPath}" -h "${env.db.host}" -p ${env.db.port} -U "${env.db.user}" -F p -f "${outputSqlPath}" "${env.db.database}"`;
    exec(cmd, { env: { ...process.env, PGPASSWORD: env.db.password } }, (err) => {
      if (err) {
        reject(
          new AppError(
            'فشل تنفيذ pg_dump. تأكد من تثبيت PostgreSQL Client Tools وأن pg_dump متاح (راجع PG_DUMP_PATH في .env).',
            500,
            'PG_DUMP_FAILED'
          )
        );
        return;
      }
      resolve();
    });
  });
}

function zipAll(zipPath, sqlPath, uploadsDir) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', resolve);
    archive.on('error', reject);
    archive.pipe(output);

    archive.file(sqlPath, { name: 'database.sql' });
    if (fs.existsSync(uploadsDir)) {
      archive.directory(uploadsDir, 'uploads');
    }

    archive.finalize();
  });
}

/**
 * ينشئ نسخة احتياطية كاملة: تفريغ قاعدة البيانات (pg_dump) + كل الملفات المرفوعة
 * (أشعة، تحاليل، وصفات، فيديوهات) مضغوطة في ملف ZIP واحد، ويسجّلها في جدول backups.
 *
 * @param {'DAILY'|'WEEKLY'|'MONTHLY'|'MANUAL'} type
 */
async function createBackup(type = 'MANUAL') {
  const backupDir = path.resolve(env.backup.dir);
  ensureDir(backupDir);

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const tempSqlPath = path.join(backupDir, `.tmp-${timestamp}.sql`);
  const zipFilename = `backup-${timestamp}.zip`;
  const zipPath = path.join(backupDir, zipFilename);

  await runPgDump(tempSqlPath);
  await zipAll(zipPath, tempSqlPath, path.resolve(env.uploads.dir));

  fs.unlink(tempSqlPath, () => {});

  const stats = fs.statSync(zipPath);
  const record = await backupModel.create({ filePath: zipFilename, type, sizeBytes: stats.size });
  return record;
}

function getBackupAbsolutePath(filePath) {
  return path.resolve(env.backup.dir, filePath);
}

/**
 * Multer مخصص لرفع نسخة احتياطية يدويًا (ملف .zip) وتخزينها مباشرة في مجلد backups.
 */
function createBackupUploadMulter() {
  const multer = require('multer');
  const crypto = require('crypto');
  const backupDir = path.resolve(env.backup.dir);
  ensureDir(backupDir);

  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, backupDir),
    filename: (req, file, cb) => cb(null, `uploaded-${Date.now()}-${crypto.randomBytes(6).toString('hex')}.zip`),
  });

  const fileFilter = (req, file, cb) => {
    const isZip =
      file.mimetype === 'application/zip' ||
      file.mimetype === 'application/x-zip-compressed' ||
      file.originalname.toLowerCase().endsWith('.zip');
    if (!isZip) {
      cb(new AppError('يجب أن يكون الملف بصيغة ZIP فقط.', 422, 'INVALID_FILE_TYPE'));
      return;
    }
    cb(null, true);
  };

  return multer({ storage, fileFilter, limits: { fileSize: env.backup.maxUploadMb * 1024 * 1024 } });
}

module.exports = { createBackup, getBackupAbsolutePath, createBackupUploadMulter };
