'use strict';

const PDFDocument = require('pdfkit');

function formatDateArabic(dateValue) {
  if (!dateValue) return '—';
  return new Date(dateValue).toLocaleDateString('ar-DZ', { year: 'numeric', month: '2-digit', day: '2-digit' });
}

const PAYMENT_METHOD_LABELS = { CASH: 'نقدًا', CARD: 'بطاقة', OTHER: 'أخرى' };

/**
 * يولّد PDF بحجم A4 لوصل دفع.
 * @param {object} params
 * @param {object} params.patient
 * @param {object} params.clinicSettings
 * @param {Array} params.services - [{ service_name, price }]
 * @param {object|null} params.discount - { type, value, subtotal, total }
 * @param {object} params.payment - { amount, method, paid_at, receipt_number }
 */
async function generateReceiptPdf({ patient, clinicSettings, services, discount, payment }) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: 'A4', margin: 50 });
      const buffers = [];
      doc.on('data', (chunk) => buffers.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(buffers)));
      doc.on('error', reject);

      const pageWidth = doc.page.width - 100;

      doc.font('Helvetica-Bold').fontSize(18).fillColor('#111827');
      doc.text(clinicSettings.clinic_name || 'عيادة أمراض النساء والتوليد ومتابعة الحمل', 50, 50, {
        width: pageWidth,
        align: 'center',
      });
      doc.font('Helvetica').fontSize(11).fillColor('#6b7280');
      doc.text('وصل دفع', 50, 76, { width: pageWidth, align: 'center' });

      doc.moveTo(50, 100).lineTo(50 + pageWidth, 100).strokeColor('#d1d5db').stroke();

      doc.font('Helvetica-Bold').fontSize(12).fillColor('#111827');
      doc.text(`رقم الوصل: ${payment.receipt_number}`, 50, 116);
      doc.font('Helvetica').fontSize(11).fillColor('#374151');
      doc.text(`المريضة: ${patient.first_name} ${patient.last_name}`, 50, 136);
      doc.text(`رقم الملف: ${patient.medical_file_number}`, 50, 154);
      doc.text(`التاريخ: ${formatDateArabic(payment.paid_at)}`, 50, 172);

      doc.moveTo(50, 196).lineTo(50 + pageWidth, 196).strokeColor('#d1d5db').stroke();

      let y = 214;
      doc.font('Helvetica-Bold').fontSize(11).fillColor('#111827');
      doc.text('الخدمة', 50, y, { width: 300 });
      doc.text('السعر (دج)', 50 + pageWidth - 140, y, { width: 140, align: 'left' });
      y += 20;
      doc.moveTo(50, y).lineTo(50 + pageWidth, y).strokeColor('#e5e7eb').stroke();
      y += 10;

      doc.font('Helvetica').fontSize(10.5).fillColor('#1f2937');
      services.forEach((s) => {
        doc.text(s.service_name, 50, y, { width: 300 });
        doc.text(Number(s.price).toFixed(2), 50 + pageWidth - 140, y, { width: 140, align: 'left' });
        y += 22;
      });

      y += 8;
      doc.moveTo(50, y).lineTo(50 + pageWidth, y).strokeColor('#e5e7eb').stroke();
      y += 14;

      const subtotal = discount ? Number(discount.subtotal) : services.reduce((s, x) => s + Number(x.price), 0);
      doc.font('Helvetica').fontSize(11).fillColor('#374151');
      doc.text('المجموع الفرعي (Subtotal):', 50, y, { width: 300 });
      doc.text(`${subtotal.toFixed(2)} دج`, 50 + pageWidth - 140, y, { width: 140, align: 'left' });
      y += 20;

      if (discount) {
        const discountLabel =
          discount.type === 'PERCENTAGE' ? `${discount.value}%` : `${Number(discount.value).toFixed(2)} دج`;
        doc.text(`التخفيض (${discountLabel}):`, 50, y, { width: 300 });
        doc.text(`- ${(subtotal - Number(discount.total)).toFixed(2)} دج`, 50 + pageWidth - 140, y, {
          width: 140,
          align: 'left',
        });
        y += 24;
      }

      doc.font('Helvetica-Bold').fontSize(13).fillColor('#111827');
      doc.text('المبلغ الإجمالي:', 50, y, { width: 300 });
      doc.text(`${Number(payment.amount).toFixed(2)} دج`, 50 + pageWidth - 140, y, { width: 140, align: 'left' });
      y += 26;

      doc.font('Helvetica').fontSize(10.5).fillColor('#6b7280');
      doc.text(`طريقة الدفع: ${PAYMENT_METHOD_LABELS[payment.method] || payment.method}`, 50, y);

      const footerY = doc.page.height - 90;
      doc.moveTo(50, footerY).lineTo(50 + pageWidth, footerY).strokeColor('#d1d5db').stroke();
      doc.fontSize(10).fillColor('#9ca3af').text('شكرًا لثقتكم بعيادتنا', 50, footerY + 14, {
        width: pageWidth,
        align: 'center',
      });

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = { generateReceiptPdf };
