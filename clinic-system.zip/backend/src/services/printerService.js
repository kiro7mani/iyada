'use strict';

const { ThermalPrinter, PrinterTypes } = require('node-thermal-printer');
const env = require('../config/env');

function createPrinterInstance() {
  return new ThermalPrinter({
    type: PrinterTypes.EPSON,
    interface: env.printer.interface, // مثال: 'tcp://192.168.1.87' أو 'printer:POS-80'
    options: { timeout: 5000 },
    width: 42,
    removeSpecialCharacters: false,
    lineCharacter: '-',
  });
}

async function assertConnected(printer) {
  const isConnected = await printer.isPrinterConnected().catch(() => false);
  if (!isConnected) {
    throw new Error('تعذر الاتصال بالطابعة.');
  }
}

/**
 * طباعة كوبون انتظار حراري (80mm) — بدون رقم الملف الطبي، حسب المواصفة.
 * @param {object} data
 * @param {string} data.clinicName
 * @param {string} data.patientFullName
 * @param {number} data.queueNumber
 * @param {string} data.visitDate - بصيغة معروضة جاهزة (DD/MM/YYYY)
 * @param {string} data.visitTime - بصيغة معروضة جاهزة (HH:MM)
 */
async function printTicket({ clinicName, patientFullName, queueNumber, visitDate, visitTime }) {
  const printer = createPrinterInstance();
  await assertConnected(printer);

  printer.alignCenter();
  printer.bold(true);
  printer.println(clinicName);
  printer.bold(false);
  printer.println('عيادة النساء والتوليد');
  printer.println('ومتابعة الحمل');
  printer.drawLine();

  printer.alignCenter();
  printer.println(`المريضة: ${patientFullName}`);
  printer.newLine();

  printer.bold(true);
  printer.setTextSize(0, 0);
  printer.println('رقم الانتظار');
  printer.setTextSize(2, 2);
  printer.println(String(queueNumber));
  printer.setTextSize(0, 0);
  printer.bold(false);
  printer.drawLine();

  printer.println(`التاريخ: ${visitDate}`);
  printer.println(`الساعة: ${visitTime}`);
  printer.drawLine();

  printer.println('يرجى الاحتفاظ بالكوبون');
  printer.println('حتى يتم استدعاؤكم');

  printer.cut();
  await printer.execute();
}

/**
 * طباعة اختبار سريعة للتأكد من عمل الطابعة (تُستخدم من الإدارة/الاستقبال).
 */
async function testPrinter() {
  const printer = createPrinterInstance();
  await assertConnected(printer);

  printer.alignCenter();
  printer.println('اختبار الطباعة');
  printer.println('النظام يعمل بشكل صحيح.');
  printer.cut();
  await printer.execute();
  return true;
}

module.exports = { printTicket, testPrinter };
