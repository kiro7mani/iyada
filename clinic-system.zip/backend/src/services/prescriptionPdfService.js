'use strict';

const PDFDocument = require('pdfkit');

// ==== مقاسات الورقة الجاهزة مسبقًا (A5 Portrait) بالنقاط (1mm = 2.8346pt) ====
const MM = 2.8346;
const PAGE_WIDTH = 148 * MM; // 148mm
const PAGE_HEIGHT = 210 * MM; // 210mm

const MARGIN_LEFT = 10 * MM; // 1 سم
const MARGIN_RIGHT = 10 * MM; // 1 سم
const MARGIN_BOTTOM = 30 * MM; // 3 سم
const CONTENT_TOP = 70 * MM; // 7 سم من رأس الصفحة فعليًا (وليس بعد هامش افتراضي)

const CONTENT_WIDTH = PAGE_WIDTH - MARGIN_LEFT - MARGIN_RIGHT;
const MAX_Y = PAGE_HEIGHT - MARGIN_BOTTOM;

const NAME_FONT_SIZE = 11;
const SUB_FONT_SIZE = 9;
const ROW_BLOCK_HEIGHT = 34; // ارتفاع كل دواء (سطر الاسم/الكمية + سطر الجرعة-التكرار-وقت الاستعمال)

function newPage(doc) {
  doc.addPage({ size: [PAGE_WIDTH, PAGE_HEIGHT], margins: { top: 0, bottom: 0, left: 0, right: 0 } });
}

/**
 * يولّد PDF بحجم A5 (148×210mm) يحتوي فقط على قائمة الأدوية، مصمَّم للطباعة فوق
 * ورقة وصفة جاهزة مسبقًا (شعار العيادة، اسم الطبيبة، العنوان... مطبوعة سلفًا).
 * لا يُطبع أي عنصر آخر غير قائمة الأدوية. الكتابة تبدأ فعليًا عند 70mm من أعلى
 * الصفحة (هامش 10mm يمين/يسار، 30mm أسفل)، باتجاه LTR.
 *
 * لكل دواء سطران:
 *   1. رقم + اسم الدواء (غامق) في أقصى جهة ← ومقابله الكمية في الجهة الأخرى، بنفس السطر.
 *   2. الجرعة - التكرار - وقت الاستعمال (بخط أصغر، غير غامق).
 *
 * مثال:
 *   1. Abdifly Od 10MG Comprime Orodispersible          1 Boîte
 *      1 cp - q4h - soir
 *
 * @param {object} params
 * @param {object} params.prescription - { items: [{ medication_name, quantity, duration, frequency, dosage }] }
 *   (duration = الجرعة لكل مرة، dosage = وقت الاستعمال — انظر توثيق نموذج البيانات)
 */
async function generatePrescriptionPdf({ prescription }) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: [PAGE_WIDTH, PAGE_HEIGHT],
        margins: { top: 0, bottom: 0, left: 0, right: 0 },
      });
      const buffers = [];
      doc.on('data', (chunk) => buffers.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(buffers)));
      doc.on('error', reject);

      let y = CONTENT_TOP;

      prescription.items.forEach((item, index) => {
        if (y + ROW_BLOCK_HEIGHT > MAX_Y) {
          // تجاوز المساحة المتبقية → صفحة A5 ثانية بنفس إعدادات البداية (7cm)، بدون أي عنصر آخر
          newPage(doc);
          y = CONTENT_TOP;
        }

        const nameLine = `${index + 1}. ${item.medication_name}`;
        const quantity = item.quantity || '';

        // السطر الأول: الاسم غامق في أقصى جهة، والكمية في الجهة المقابلة بنفس السطر
        doc.font('Helvetica-Bold').fontSize(NAME_FONT_SIZE).fillColor('#000000');
        doc.text(nameLine, MARGIN_LEFT, y, {
          width: CONTENT_WIDTH * 0.72,
          align: 'left',
          direction: 'ltr',
          lineBreak: false,
        });
        if (quantity) {
          doc.text(quantity, MARGIN_LEFT, y, {
            width: CONTENT_WIDTH,
            align: 'right',
            direction: 'ltr',
            lineBreak: false,
          });
        }

        // السطر الثاني: الجرعة - التكرار - وقت الاستعمال، بخط أصغر وغير غامق
        const subParts = [item.duration, item.frequency, item.dosage].filter(Boolean);
        if (subParts.length > 0) {
          doc.font('Helvetica').fontSize(SUB_FONT_SIZE).fillColor('#1a1a1a');
          doc.text(`   ${subParts.join(' - ')}`, MARGIN_LEFT, y + 15, {
            width: CONTENT_WIDTH,
            align: 'left',
            direction: 'ltr',
            lineBreak: false,
          });
        }

        y += ROW_BLOCK_HEIGHT;
      });

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = { generatePrescriptionPdf };
