'use strict';

const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const env = require('../config/env');
const AppError = require('../utils/AppError');

const ALLOWED_MIME_EXT = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'application/pdf': '.pdf',
};

const ALLOWED_VIDEO_MIME_EXT = {
  'video/mp4': '.mp4',
  'video/webm': '.webm',
};

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function makeStorage(subfolder, mimeMap) {
  const dir = path.join(env.uploads.dir, subfolder);
  ensureDir(dir);
  return multer.diskStorage({
    destination: (req, file, cb) => cb(null, dir),
    filename: (req, file, cb) => {
      const ext = mimeMap[file.mimetype] || path.extname(file.originalname) || '';
      cb(null, `${crypto.randomBytes(16).toString('hex')}${ext}`);
    },
  });
}

function fileFilter(req, file, cb) {
  if (!ALLOWED_MIME_EXT[file.mimetype]) {
    cb(new AppError('نوع الملف غير مسموح به. المسموح فقط: صور JPG/PNG/WEBP أو PDF.', 422, 'INVALID_FILE_TYPE'));
    return;
  }
  cb(null, true);
}

function videoFileFilter(req, file, cb) {
  if (!ALLOWED_VIDEO_MIME_EXT[file.mimetype]) {
    cb(new AppError('نوع الفيديو غير مسموح به. المسموح فقط: MP4 أو WEBM.', 422, 'INVALID_FILE_TYPE'));
    return;
  }
  cb(null, true);
}

function createUploader(subfolder) {
  return multer({
    storage: makeStorage(subfolder, ALLOWED_MIME_EXT),
    fileFilter,
    limits: { fileSize: env.uploads.maxSizeMb * 1024 * 1024 },
  });
}

const radiologyUpload = createUploader('radiology');
const labUpload = createUploader('labs');

const videoUpload = multer({
  storage: makeStorage('tv', ALLOWED_VIDEO_MIME_EXT),
  fileFilter: videoFileFilter,
  limits: { fileSize: env.uploads.maxVideoSizeMb * 1024 * 1024 },
});

module.exports = { radiologyUpload, labUpload, videoUpload };
