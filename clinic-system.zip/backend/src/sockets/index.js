'use strict';

/**
 * تهيئة أساسية لـ Socket.IO.
 * في هذه المرحلة (PHASE 1) نكتفي بإدارة الاتصال والانضمام للغرف (rooms):
 *   tv | doctor | reception
 * الأحداث الفعلية (patient_called, tv_mute...) ستُضاف في PHASE 8.
 */
function initSockets(io) {
  io.on('connection', (socket) => {
    // eslint-disable-next-line no-console
    console.log(`🔌 اتصال جديد عبر WebSocket: ${socket.id}`);

    socket.on('join_room', ({ room }) => {
      const allowedRooms = ['tv', 'doctor', 'reception'];
      if (allowedRooms.includes(room)) {
        socket.join(room);
        // eslint-disable-next-line no-console
        console.log(`↳ ${socket.id} انضم إلى الغرفة: ${room}`);
      }
    });

    socket.on('disconnect', () => {
      // eslint-disable-next-line no-console
      console.log(`❌ قطع الاتصال: ${socket.id}`);
    });
  });
}

module.exports = initSockets;
