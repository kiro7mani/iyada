'use strict';

const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');

const env = require('./config/env');
const routes = require('./routes');
const { errorHandler, notFoundHandler } = require('./middlewares/errorHandler');

const FRONTEND_DIR = path.join(__dirname, '..', '..', 'frontend');

function createApp() {
  const app = express();

  // helmet's CSP الافتراضي يمنع تشغيل <script> inline أو CDN خارجي، ونحتاج كليهما
  // في صفحات الواجهة البسيطة هذه (Socket.IO عبر CDN)، لذلك نعطّل CSP هنا فقط.
  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(
    cors({
      origin: env.corsOrigins.length > 0 ? env.corsOrigins : true,
      credentials: true, // ضروري لإرسال/استقبال الـ Cookie عبر الأجهزة داخل الشبكة المحلية
    })
  );
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());

  if (env.nodeEnv !== 'test') {
    app.use(morgan(env.nodeEnv === 'production' ? 'combined' : 'dev'));
  }

  app.use('/api', routes);

  // ملفات فيديوهات التلفاز — عامة (بدون تسجيل دخول)، شاشة التلفاز نفسها لا تملك طريقة لتسجيل الدخول
  app.use('/media/tv', express.static(path.join(env.uploads.dir, 'tv')));

  // ملفات مشتركة (CSS/JS) بين كل الواجهات
  app.use('/shared', express.static(path.join(FRONTEND_DIR, 'shared')));

  // الواجهات الرسومية (كل واحدة تُضاف تباعًا مع تقدم المراحل)
  app.use('/login', express.static(path.join(FRONTEND_DIR, 'login')));
  app.use('/reception', express.static(path.join(FRONTEND_DIR, 'reception')));
  app.use('/doctor', express.static(path.join(FRONTEND_DIR, 'doctor')));
  app.use('/tv', express.static(path.join(FRONTEND_DIR, 'tv')));
  app.use('/tv-manager', express.static(path.join(FRONTEND_DIR, 'tv-manager')));
  app.use('/admin', express.static(path.join(FRONTEND_DIR, 'admin')));

  app.get('/', (req, res) => res.redirect('/login'));

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

module.exports = createApp;
