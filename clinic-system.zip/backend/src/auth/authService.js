'use strict';

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const env = require('../config/env');

const SALT_ROUNDS = 12;

async function hashPassword(plainPassword) {
  return bcrypt.hash(plainPassword, SALT_ROUNDS);
}

async function verifyPassword(plainPassword, passwordHash) {
  return bcrypt.compare(plainPassword, passwordHash);
}

/**
 * إصدار JWT يحتوي على المعرّف والدور فقط (لا بيانات حساسة).
 */
function signToken(user) {
  return jwt.sign(
    {
      sub: user.id,
      username: user.username,
      role: user.role_name,
    },
    env.auth.jwtSecret,
    { expiresIn: env.auth.jwtExpiresIn }
  );
}

function verifyToken(token) {
  return jwt.verify(token, env.auth.jwtSecret);
}

module.exports = { hashPassword, verifyPassword, signToken, verifyToken };
