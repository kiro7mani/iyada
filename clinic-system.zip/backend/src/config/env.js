'use strict';

require('dotenv').config();

const REQUIRED_VARS = [
  'DB_HOST',
  'DB_PORT',
  'DB_NAME',
  'DB_USER',
  'DB_PASSWORD',
  'JWT_SECRET',
];

function assertRequiredEnv() {
  const missing = REQUIRED_VARS.filter((key) => !process.env[key] || process.env[key].trim() === '');
  if (missing.length > 0) {
    throw new Error(
      `متغيرات بيئة ناقصة: ${missing.join(', ')}. تأكد من إنشاء ملف .env بناءً على .env.example`
    );
  }
  if (
    process.env.NODE_ENV === 'production' &&
    process.env.JWT_SECRET === 'change_this_to_a_long_random_secret_key'
  ) {
    throw new Error('يجب تغيير JWT_SECRET قبل التشغيل في بيئة الإنتاج.');
  }
}

assertRequiredEnv();

const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 4000,

  db: {
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT, 10) || 5432,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
  },

  auth: {
    jwtSecret: process.env.JWT_SECRET,
    jwtExpiresIn: process.env.JWT_EXPIRES_IN || '12h',
    cookieName: process.env.COOKIE_NAME || 'clinic_session',
    // مفصولة عمدًا عن NODE_ENV: تشغيل production عبر PM2 لا يعني وجود HTTPS فعليًا
    // في شبكة العيادة المحلية. لا تُفعّل هذا إلا بعد وضع Reverse Proxy بشهادة HTTPS حقيقية.
    cookieSecure: process.env.COOKIE_SECURE === 'true',
  },

  corsOrigins: (process.env.CORS_ORIGINS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),

  uploads: {
    dir: process.env.UPLOADS_DIR || './uploads',
    maxSizeMb: parseInt(process.env.MAX_UPLOAD_SIZE_MB, 10) || 25,
    maxVideoSizeMb: parseInt(process.env.MAX_VIDEO_SIZE_MB, 10) || 300,
  },

  printer: {
    interface: process.env.PRINTER_INTERFACE || 'tcp://192.168.1.87',
  },

  backup: {
    dir: process.env.BACKUP_DIR || '../backups',
    pgDumpPath: process.env.PG_DUMP_PATH || 'pg_dump',
    schedulingEnabled: process.env.BACKUP_SCHEDULING_ENABLED !== 'false',
    maxUploadMb: parseInt(process.env.MAX_BACKUP_UPLOAD_MB, 10) || 500,
  },
};

module.exports = env;
