'use strict';

const { Pool } = require('pg');
const env = require('./env');

const pool = new Pool({
  host: env.db.host,
  port: env.db.port,
  database: env.db.database,
  user: env.db.user,
  password: env.db.password,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  // خطأ غير متوقع في اتصال خامل داخل الـ Pool، لا يجب أن يوقف السيرفر
  // eslint-disable-next-line no-console
  console.error('خطأ غير متوقع في اتصال قاعدة البيانات:', err);
});

/**
 * تنفيذ استعلام مباشر (بدون Transaction).
 * @param {string} text - نص الاستعلام SQL (Parameterized)
 * @param {Array} params
 */
async function query(text, params) {
  return pool.query(text, params);
}

/**
 * تنفيذ مجموعة عمليات ضمن Transaction واحد.
 * @param {(client: import('pg').PoolClient) => Promise<any>} callback
 */
async function withTransaction(callback) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function checkConnection() {
  const res = await pool.query('SELECT NOW()');
  return res.rows[0];
}

module.exports = { pool, query, withTransaction, checkConnection };
