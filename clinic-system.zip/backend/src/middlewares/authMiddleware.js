'use strict';

const env = require('../config/env');
const { verifyToken } = require('../auth/authService');
const userModel = require('../models/userModel');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

/**
 * يتحقق من وجود جلسة صالحة (Cookie تحتوي JWT).
 * عند النجاح: يضيف req.user = { id, username, role }
 */
const requireAuth = asyncHandler(async (req, res, next) => {
  const token = req.cookies ? req.cookies[env.auth.cookieName] : null;

  if (!token) {
    throw new AppError('يجب تسجيل الدخول للوصول إلى هذا المورد.', 401, 'NOT_AUTHENTICATED');
  }

  let payload;
  try {
    payload = verifyToken(token);
  } catch (err) {
    throw new AppError('انتهت صلاحية الجلسة، الرجاء تسجيل الدخول من جديد.', 401, 'INVALID_TOKEN');
  }

  const user = await userModel.findById(payload.sub);
  if (!user || !user.is_active) {
    throw new AppError('الحساب غير موجود أو غير مفعّل.', 401, 'ACCOUNT_INACTIVE');
  }

  req.user = {
    id: user.id,
    fullName: user.full_name,
    username: user.username,
    roleId: user.role_id,
    role: user.role_name,
  };

  next();
});

/**
 * يقيّد الوصول لأدوار محددة فقط.
 * الاستخدام: requireRole('admin') أو requireRole('admin', 'doctor')
 */
function requireRole(...allowedRoles) {
  return function roleCheck(req, res, next) {
    if (!req.user) {
      return next(new AppError('يجب تسجيل الدخول أولاً.', 401, 'NOT_AUTHENTICATED'));
    }
    if (!allowedRoles.includes(req.user.role)) {
      return next(
        new AppError('لا تملك الصلاحية الكافية للقيام بهذا الإجراء.', 403, 'FORBIDDEN')
      );
    }
    return next();
  };
}

module.exports = { requireAuth, requireRole };
