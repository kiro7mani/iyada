'use strict';

const multer = require('multer');
const env = require('../config/env');

/**
 * يجب أن يكون آخر middleware في السلسلة (4 معاملات = Error handler في Express).
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // أخطاء Multer (حجم الملف الأقصى تجاوَز، حقل غير متوقع...) ليست AppError افتراضيًا
  if (err instanceof multer.MulterError) {
    const message =
      err.code === 'LIMIT_FILE_SIZE'
        ? `حجم الملف أكبر من الحد المسموح (${env.uploads.maxSizeMb}MB).`
        : 'تعذر رفع الملف.';
    return res.status(422).json({ success: false, message, code: err.code });
  }

  const statusCode = err.statusCode || 500;
  const isOperational = err.isOperational === true;

  if (!isOperational) {
    // خطأ غير متوقع (برمجي) — نسجله بالكامل في الطرفية
    // eslint-disable-next-line no-console
    console.error('خطأ غير متوقع:', err);
  }

  const response = {
    success: false,
    message: isOperational ? err.message : 'حدث خطأ غير متوقع في الخادم.',
    code: err.code || 'INTERNAL_ERROR',
  };

  if (env.nodeEnv === 'development' && !isOperational) {
    response.stack = err.stack;
  }

  res.status(statusCode).json(response);
}

function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    message: 'المسار المطلوب غير موجود.',
    code: 'NOT_FOUND',
  });
}

module.exports = { errorHandler, notFoundHandler };
