'use strict';

const { validationResult } = require('express-validator');
const AppError = require('../utils/AppError');

/**
 * يوضع بعد قواعد express-validator في أي route:
 *   router.post('/x', [body('name').notEmpty()], validate, controller.create)
 */
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const firstError = errors.array()[0];
    return next(new AppError(firstError.msg, 422, 'VALIDATION_ERROR'));
  }
  return next();
}

module.exports = validate;
