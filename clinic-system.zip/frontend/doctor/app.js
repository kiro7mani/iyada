/* لوحة الطبيبة */

let currentUser = null;
let currentQueue = [];
let currentCalledVisit = null; // { visitId, queueNumber, name }
let serviceCatalog = [];

let examState = null;
/* examState = {
     visitId, patientId, defaultVisitType,
     medications: [{medicationName, frequency, quantity}],
     savedMedicationsCount, lastPrescriptionId,
     services: [{serviceId, name, price}]
   } */

async function init() {
  currentUser = await requireSession(['doctor', 'admin']);
  if (!currentUser) return;
  document.getElementById('userLabel').textContent = `${currentUser.fullName} (${roleLabel(currentUser.role)})`;

  await loadQueue();
  await syncBreakStatus();
  setupSocket();
}

function roleLabel(role) {
  return { admin: 'إدارة', reception: 'استقبال', doctor: 'طبيبة' }[role] || role;
}

function setupSocket() {
  const socket = io({ withCredentials: true });
  socket.on('connect', () => socket.emit('join_room', { room: 'doctor' }));
  socket.on('queue_updated', () => loadQueue());
  socket.on('patient_called', () => syncCurrentCalledFromQueue());
  socket.on('patient_recalled', () => syncCurrentCalledFromQueue());
  socket.on('nurse_call_acknowledged', () => showDoctorNurseToast());
}

/* ---------------- استدعاء الممرضة ---------------- */

let doctorNurseToastTimer = null;

async function callNurse() {
  try {
    await apiRequest('/nurse-call/request', { method: 'POST' });
    showToast('تم إرسال الاستدعاء إلى الاستقبال.', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function showDoctorNurseToast() {
  const toast = document.getElementById('doctorNurseToast');
  clearTimeout(doctorNurseToastTimer);
  toast.classList.remove('hide');
  toast.classList.add('visible');
  doctorNurseToastTimer = setTimeout(hideDoctorNurseToast, 2000);
}

function hideDoctorNurseToast() {
  const toast = document.getElementById('doctorNurseToast');
  clearTimeout(doctorNurseToastTimer);
  toast.classList.add('hide');
  setTimeout(() => toast.classList.remove('visible', 'hide'), 400);
}

/* ---------------- استراحة عمل الطبيبة ---------------- */

let isOnBreak = false;
let doctorBreakToastTimer = null;

async function syncBreakStatus() {
  try {
    const res = await apiRequest('/doctor-break/status');
    applyBreakState(res.data.is_on_break);
  } catch (err) {
    // تجاهل بصمت — الافتراضي عدم وجود استراحة
  }
}

function applyBreakState(onBreak) {
  isOnBreak = onBreak;
  const btn = document.getElementById('breakToggleBtn');
  const startExamBtn = document.getElementById('startExamBtn');

  if (onBreak) {
    btn.textContent = '▶ استئناف العمل';
    btn.classList.add('on-break');
    startExamBtn.disabled = true;
  } else {
    btn.textContent = '⏸ استراحة عمل';
    btn.classList.remove('on-break');
    // إعادة تفعيل زر بدء الفحص فقط إذا كانت هناك مريضة مستدعاة فعليًا حاليًا
    startExamBtn.disabled = !currentCalledVisit;
  }
}

async function toggleDoctorBreak() {
  const btn = document.getElementById('breakToggleBtn');
  btn.disabled = true;
  try {
    if (!isOnBreak) {
      const res = await apiRequest('/doctor-break/start', { method: 'POST' });
      applyBreakState(res.data.is_on_break);
      showDoctorBreakToast('تم إعلام مكتب الاستقبال أنه تم توقيف الفحص مؤقتًا', 'break-paused');
    } else {
      const res = await apiRequest('/doctor-break/end', { method: 'POST' });
      applyBreakState(res.data.is_on_break);
      showDoctorBreakToast('تم إعلام مكتب الاستقبال أنه تم استئناف الفحص', 'break-resumed');
    }
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    btn.disabled = false;
  }
}

function showDoctorBreakToast(text, variantClass) {
  const toast = document.getElementById('doctorBreakToast');
  clearTimeout(doctorBreakToastTimer);
  toast.classList.remove('break-paused', 'break-resumed', 'hide');
  toast.classList.add('visible', variantClass);
  document.getElementById('doctorBreakToastText').textContent = text;
  doctorBreakToastTimer = setTimeout(hideDoctorBreakToast, 5000);
}

function hideDoctorBreakToast() {
  const toast = document.getElementById('doctorBreakToast');
  clearTimeout(doctorBreakToastTimer);
  toast.classList.add('hide');
  setTimeout(() => toast.classList.remove('visible', 'hide', 'break-paused', 'break-resumed'), 400);
}

async function loadQueue() {
  try {
    const res = await apiRequest('/queue/today');
    currentQueue = res.data;
    renderStats(currentQueue);
    renderQueueTable(currentQueue);
    syncCurrentCalledFromQueue();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function syncCurrentCalledFromQueue() {
  const called = currentQueue.find((v) => v.status === 'CALLED');
  const recallBtn = document.getElementById('recallBtn');
  const startExamBtn = document.getElementById('startExamBtn');

  if (called) {
    currentCalledVisit = {
      visitId: called.visit_id,
      queueNumber: called.queue_number,
      name: `${called.first_name} ${called.last_name}`,
    };
    document.getElementById('currentCalledNumber').textContent = String(called.queue_number).padStart(2, '0');
    document.getElementById('currentCalledName').textContent = currentCalledVisit.name;
    recallBtn.disabled = false;
    startExamBtn.disabled = isOnBreak; // لا يمكن بدء الفحص أثناء استراحة العمل
  } else {
    currentCalledVisit = null;
    document.getElementById('currentCalledNumber').textContent = '—';
    document.getElementById('currentCalledName').textContent = '';
    recallBtn.disabled = true;
    startExamBtn.disabled = true;
  }
}

const VISIT_TYPE_LABELS = { GENERAL: 'فحص روتيني', FERTILITY: 'متابعة الإنجاب', PREGNANCY: 'متابعة الحمل' };

function renderStats(list) {
  const counts = {
    waiting: list.filter((v) => v.status === 'WAITING').length,
    withDoctor: list.filter((v) => v.status === 'WITH_DOCTOR').length,
    completedToday: list.filter((v) => v.status === 'COMPLETED').length,
  };
  const expectedFinish = computeExpectedFinishTime(list);
  const items = [
    { label: 'في الانتظار', value: counts.waiting },
    { label: 'قيد الفحص', value: counts.withDoctor },
    { label: 'توقع انتهاء العمل اليوم', value: expectedFinish || '—' },
    { label: 'مكتملة اليوم', value: counts.completedToday },
  ];
  document.getElementById('statGrid').innerHTML = items
    .map((i) => `<div class="stat-card"><div class="value">${i.value}</div><div class="label">${i.label}</div></div>`)
    .join('');
}

/**
 * "توقع انتهاء العمل اليوم": الساعة المتوقعة لفحص آخر مريضة مسجّلة اليوم (أعلى رقم انتظار)،
 * محسوبة بنفس منطق المتوسط المتحرك المستخدم في لوحة الاستقبال (متوسط مدة فحص المريضات
 * بأرقام 1 إلى N-2). تتحدّث تلقائيًا مع كل حجز جديد أو تغيّر في المتوسطات.
 */
function computeExpectedFinishTime(list) {
  const relevant = list.filter((v) => !['CANCELLED', 'NO_SHOW'].includes(v.status));
  if (relevant.length === 0) return null;

  const lastPatient = relevant.reduce((max, v) => (v.queue_number > max.queue_number ? v : max), relevant[0]);
  const n = lastPatient.queue_number;
  if (n < 3) return null;

  const durationByQueueNumber = {};
  list.forEach((v) => {
    if (v.with_doctor_started_at && v.with_doctor_ended_at) {
      const minutes = Math.round((new Date(v.with_doctor_ended_at) - new Date(v.with_doctor_started_at)) / 60000);
      if (minutes > 0) durationByQueueNumber[v.queue_number] = minutes;
    }
  });

  const lookbackDurations = [];
  for (let i = 1; i <= n - 2; i++) {
    if (durationByQueueNumber[i] !== undefined) lookbackDurations.push(durationByQueueNumber[i]);
  }
  if (lookbackDurations.length === 0) return null;

  const avgMinutes = Math.round(lookbackDurations.reduce((a, b) => a + b, 0) / lookbackDurations.length);
  const expectedClock = new Date(Date.now() + avgMinutes * 60000);
  return expectedClock.toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit' });
}

function renderQueueTable(list) {
  const relevant = list.filter((v) => ['WAITING', 'CALLED', 'WITH_DOCTOR'].includes(v.status));
  const wrap = document.getElementById('queueTableWrap');
  if (relevant.length === 0) {
    wrap.innerHTML = '<div class="empty-state">لا توجد مريضات في الانتظار حاليًا.</div>';
    return;
  }
  const rows = relevant
    .map(
      (v) => `
    <tr>
      <td><span class="queue-number">${String(v.queue_number).padStart(2, '0')}</span></td>
      <td>${v.first_name} ${v.last_name}<div style="color:var(--text-muted);font-size:12px;">${v.medical_file_number}</div></td>
      <td>${VISIT_TYPE_LABELS[v.visit_type] || v.visit_type}</td>
      <td>${new Date(v.booked_at).toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit' })}</td>
      <td>${statusBadge(v.status)}</td>
      <td>${v.status === 'WITH_DOCTOR' ? `<button class="btn btn-primary" onclick="openExam(${v.visit_id})">📋 فتح الفحص</button>` : ''}</td>
    </tr>`
    )
    .join('');

  wrap.innerHTML = `
    <table>
      <thead><tr><th>الرقم</th><th>المريضة</th><th>نوع الزيارة</th><th>وقت الحجز</th><th>الحالة</th><th></th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

async function callNext() {
  const btn = document.getElementById('callNextBtn');
  btn.disabled = true;
  try {
    const res = await apiRequest('/queue/call-next', { method: 'POST' });
    showToast(`تم استدعاء الرقم ${res.data.queue.queue_number}`, 'success');
    loadQueue();
  } catch (err) {
    showToast(err.message, err.code === 'QUEUE_EMPTY' ? 'info' : 'error');
  } finally {
    btn.disabled = false;
  }
}

async function recallCurrent() {
  if (!currentCalledVisit) return;
  try {
    await apiRequest(`/queue/recall/${currentCalledVisit.visitId}`, { method: 'POST' });
    showToast('تمت إعادة الاستدعاء.', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function startExamCurrent() {
  if (!currentCalledVisit) return;
  const visitId = currentCalledVisit.visitId;
  try {
    await apiRequest(`/queue/start-exam/${visitId}`, { method: 'POST' });
    showToast('بدأ الفحص.', 'success');
    await loadQueue();
    openExam(visitId);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/* ================= واجهة الفحص ================= */

async function openExam(visitId) {
  try {
    const res = await apiRequest(`/visits/${visitId}/summary`);
    const s = res.data;

    examState = {
      visitId,
      patientId: s.patient.id,
      defaultVisitType: s.defaultVisitType,
      lastFollowUp: s.lastFollowUp,
      medications: [],
      savedMedicationsCount: 0,
      lastPrescriptionId: null,
      services: [],
    };

    document.getElementById('examPatientName').textContent = `${s.patient.first_name} ${s.patient.last_name}`;
    document.getElementById('examPatientFile').textContent = s.patient.medical_file_number;

    renderSummaryStage(s);

    document.getElementById('examStageSummary').style.display = 'block';
    document.getElementById('examStageExam').style.display = 'none';
    document.getElementById('examOverlay').style.display = 'flex';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function closeExam() {
  document.getElementById('examOverlay').style.display = 'none';
  document.getElementById('finishExamModal').style.display = 'none'; // تفادي بقاء النافذة مفتوحة خلفيًا لجلسة الفحص التالية
  examState = null;
  loadQueue();
}

function renderSummaryStage(s) {
  // آخر متابعة
  let followUpHtml = '<div style="color:var(--text-muted); font-size:13px;">لا توجد زيارات سابقة.</div>';
  if (s.lastFollowUp) {
    const f = s.lastFollowUp;
    if (f.type === 'PREGNANCY' && f.gestationalAgeWeeks !== undefined) {
      followUpHtml = renderPregnancyStrip(f);
    } else {
      const rows = [`<div class="kv-row"><span>تاريخ آخر فحص</span><span>${formatDate(f.lastVisitDate)}</span></div>`];
      rows.push(`<div class="kv-row"><span>نوع المتابعة</span><span>${VISIT_TYPE_LABELS[f.type]}</span></div>`);
      if (f.type === 'FERTILITY' && f.daysSince !== undefined) {
        const label = f.dateType === 'MARRIAGE' ? 'تاريخ الزواج' : 'تاريخ آخر حمل';
        rows.push(`<div class="kv-row"><span>${label}</span><span>${formatDate(f.referenceDate)}</span></div>`);
        rows.push(`<div class="kv-row"><span>المدة حتى اليوم</span><span>${f.daysSince} يومًا</span></div>`);
      }
      followUpHtml = rows.join('');
    }
  }
  document.getElementById('summaryLastFollowUp').innerHTML = followUpHtml;

  // قياسات اليوم
  document.getElementById('summaryTodayMeasurements').innerHTML = renderMeasurementsKv(s.todayMeasurements);

  // آخر ثلاث قياسات (رسم بياني من بيانات حقيقية)
  document.getElementById('summaryRecentMeasurements').innerHTML = renderMeasurementsChart(s.recentMeasurements, s.todayMeasurements);

  // آخر ملاحظة
  document.getElementById('summaryLastNote').innerHTML = s.lastNote
    ? `<div style="font-size:13.5px;">${s.lastNote.examination_notes}</div><div style="color:var(--text-muted); font-size:11.5px; margin-top:4px;">${formatDate(s.lastNote.visit_date)}</div>`
    : '<div style="color:var(--text-muted); font-size:13px;">لا توجد ملاحظات سابقة.</div>';

  // آخر الأدوية
  if (s.lastPrescription && s.lastPrescription.items.length > 0) {
    const rows = s.lastPrescription.items
      .map((i) => `<tr><td>${i.medication_name}</td><td>${i.quantity || '—'}</td><td>${i.duration || '—'}</td><td>${i.frequency || '—'}</td></tr>`)
      .join('');
    document.getElementById('summaryLastMeds').innerHTML = `
      <table><thead><tr><th>الدواء</th><th>الكمية</th><th>الجرعة</th><th>التكرار</th></tr></thead><tbody>${rows}</tbody></table>`;
  } else {
    document.getElementById('summaryLastMeds').innerHTML = '<div style="color:var(--text-muted); font-size:13px;">لا توجد أدوية سابقة.</div>';
  }
}

/* ---------------- بطاقة متابعة الحمل الرسومية (بيانات حقيقية للمريضة) ---------------- */

/**
 * جدول تقريبي شائع لمقارنة حجم الجنين أسبوعيًا (معلومات عامة تقريبية، وليست خاصة بمريضة بعينها).
 */
const PREGNANCY_SIZE_TABLE = {
  4: ['🌱', 'بذرة خشخاش'], 5: ['🌰', 'بذرة سمسم'], 6: ['🫛', 'حبة عدس'], 7: ['🫐', 'توتة'],
  8: ['🫘', 'حبة فاصوليا'], 9: ['🍇', 'حبة عنب'], 10: ['🍓', 'فراولة'], 11: ['🍋', 'ليمونة صغيرة'],
  12: ['🍋', 'ليمونة'], 13: ['🍑', 'خوخة'], 14: ['🍋', 'ليمون كبير'], 15: ['🍎', 'تفاحة'],
  16: ['🥑', 'أفوكادو'], 17: ['🍐', 'كمثرى'], 18: ['🫑', 'فلفل حلو'], 19: ['🍅', 'طماطم كبيرة'],
  20: ['🍌', 'موزة'], 21: ['🥕', 'جزرة'], 22: ['🥥', 'جوز هند صغير'], 23: ['🌽', 'كوز ذرة'],
  24: ['🍆', 'باذنجان'], 25: ['🥦', 'قرنبيط'], 26: ['🥬', 'خس'], 27: ['🥦', 'بروكلي كبير'],
  28: ['🍆', 'باذنجان كبير'], 29: ['🎃', 'يقطين صغير'], 30: ['🥥', 'جوز هند كبير'], 31: ['🍍', 'أناناس صغير'],
  32: ['🎃', 'يقطين متوسط'], 33: ['🍈', 'شمام'], 34: ['🍈', 'بطيخ صغير'], 35: ['🎃', 'يقطين'],
  36: ['🥬', 'ملفوف كبير'], 37: ['🍈', 'شمام كبير'], 38: ['🎃', 'يقطين كبير'], 39: ['🍉', 'بطيخة صغيرة'],
  40: ['🍉', 'بطيخة'], 41: ['🍉', 'بطيخة كبيرة'], 42: ['🍉', 'بطيخة كبيرة'],
};

function renderPregnancyStrip(f) {
  const week = Math.max(4, Math.min(42, f.gestationalAgeWeeks));
  const [emoji, sizeName] = PREGNANCY_SIZE_TABLE[week] || ['👶', '—'];
  const trimester = week <= 13 ? 'الثلث الأول' : week <= 27 ? 'الثلث الثاني' : 'الثلث الثالث';
  const progress = Math.max(0, Math.min(100, Math.round((week / 40) * 100)));
  const remaining = Math.max(0, 40 - week);

  return `
  <div class="pregnancy-strip">
    <div class="preg-section preg-primary">
      <span class="preg-label">المرحلة الحالية</span>
      <span class="preg-week-value">الأسبوع ${week}</span>
      <span class="preg-trimester-badge">${trimester}</span>
    </div>
    <div class="preg-section preg-baby">
      <div class="preg-baby-icon">${emoji}</div>
      <div class="preg-baby-info">
        <span class="preg-baby-title">مؤشر حجم الجنين</span>
        <span class="preg-baby-name">بحجم ${sizeName}</span>
      </div>
    </div>
    <div class="preg-section preg-progress">
      <div class="preg-progress-meta">
        <span>التقدم: ${progress}%</span>
        <span>متبقي ${remaining} أسبوعًا للولادة</span>
      </div>
      <div class="preg-track-container"><div class="preg-track-fill" style="width:${progress}%;"></div></div>
    </div>
    <div class="preg-section preg-vitals">
      <div class="preg-vital-row"><span>تاريخ آخر فحص:</span><span>${formatDate(f.lastVisitDate)}</span></div>
      <div class="preg-vital-row"><span>تاريخ الولادة المتوقع:</span><span>${formatDate(f.eddDate)}</span></div>
    </div>
  </div>`;
}

/* ---------------- رسم بياني لآخر القياسات (بيانات حقيقية) ---------------- */

function parseSystolic(bp) {
  if (!bp) return null;
  const match = String(bp).match(/[\d.]+/);
  return match ? parseFloat(match[0]) : null;
}
function parseNumeric(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = parseFloat(String(v).replace(',', '.'));
  return isNaN(n) ? null : n;
}

function renderMeasurementsChart(recentMeasurements, todayMeasurements) {
  // ترتيب تصاعدي (الأقدم أولًا) + قياس اليوم كنقطة "الحالية" إن وُجد
  const ascending = [...recentMeasurements].reverse();
  const points = ascending.map((r) => ({
    label: formatDate(r.visit_date),
    bp: parseSystolic(r.reception_measurements ? r.reception_measurements.blood_pressure : null),
    sugar: parseNumeric(r.reception_measurements ? r.reception_measurements.blood_sugar : null),
    weight: parseNumeric(r.reception_measurements ? r.reception_measurements.weight : null),
  }));
  if (todayMeasurements && (todayMeasurements.blood_pressure || todayMeasurements.blood_sugar || todayMeasurements.weight)) {
    points.push({
      label: 'الحالية',
      bp: parseSystolic(todayMeasurements.blood_pressure),
      sugar: parseNumeric(todayMeasurements.blood_sugar),
      weight: parseNumeric(todayMeasurements.weight),
    });
  }

  if (points.length === 0) {
    return '<div style="color:var(--text-muted); font-size:13px;">لا توجد قياسات مسجّلة بعد.</div>';
  }

  const bpValues = points.map((p) => p.bp);
  const sugarValues = points.map((p) => p.sugar);
  const weightValues = points.map((p) => p.weight);
  const labels = points.map((p) => p.label);

  const lastBp = [...bpValues].reverse().find((v) => v !== null);
  const lastSugar = [...sugarValues].reverse().find((v) => v !== null);
  const lastWeight = [...weightValues].reverse().find((v) => v !== null);

  return `
    <div class="clinical-grid">
      ${sparklineCard('ضغط الدم (Systolic)', lastBp !== undefined ? `${lastBp} mmHg` : '—', bpValues, labels, '#db869f')}
      ${sparklineCard('سكر الدم', lastSugar !== undefined ? `${lastSugar}` : '—', sugarValues, labels, '#3182ce')}
      ${sparklineCard('الوزن', lastWeight !== undefined ? `${lastWeight} kg` : '—', weightValues, labels, '#38a169')}
    </div>`;
}

function sparklineCard(title, currentValueLabel, values, labels, color) {
  const numericPoints = values.filter((v) => v !== null && v !== undefined);
  let svgContent;
  if (numericPoints.length < 2) {
    svgContent = `<div style="display:flex; align-items:center; justify-content:center; height:100%; color:var(--text-muted); font-size:10px;">بيانات غير كافية للرسم</div>`;
  } else {
    const min = Math.min(...numericPoints);
    const max = Math.max(...numericPoints);
    const range = max - min || 1;
    const n = values.length;
    const stepX = n > 1 ? 76 / (n - 1) : 0;
    const coords = values.map((v, i) => {
      if (v === null || v === undefined) return null;
      const x = 12 + i * stepX;
      const y = 30 - ((v - min) / range) * 20;
      return { x, y };
    });
    const validCoords = coords.filter(Boolean);
    const pathD = validCoords.map((c, i) => `${i === 0 ? 'M' : 'L'} ${c.x} ${c.y}`).join(' ');
    const circles = coords
      .map((c, i) =>
        c ? `<circle cx="${c.x}" cy="${c.y}" r="${i === coords.length - 1 ? 3.5 : 3}" fill="${i === coords.length - 1 ? color : '#ffffff'}" stroke="${color}" stroke-width="2" />` : ''
      )
      .join('');
    svgContent = `
      <svg viewBox="0 0 100 36" width="100%" height="100%">
        <rect x="0" y="8" width="100" height="20" fill="#faf8f9" opacity="0.6" rx="2" />
        <line x1="0" y1="18" x2="100" y2="18" stroke="#e5d5dc" stroke-dasharray="2" />
        <path d="${pathD}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        ${circles}
      </svg>`;
  }

  return `
    <div class="clinical-card">
      <div class="card-header-row">
        <span class="card-title">${title}</span>
        <span class="card-current-value" style="color:${color};">${currentValueLabel}</span>
      </div>
      <div class="chart-box-svg">${svgContent}</div>
      <div class="axis-time-labels">${labels.map((l) => `<span>${l}</span>`).join('')}</div>
    </div>`;
}

function renderMeasurementsKv(measurements) {
  if (!measurements || Object.keys(measurements).length === 0) {
    return '<div style="color:var(--text-muted); font-size:13px;">لم تُسجَّل قياسات اليوم.</div>';
  }
  const labels = { blood_pressure: 'ضغط الدم', blood_sugar: 'نسبة السكر', weight: 'الوزن', notes: 'ملاحظات' };
  return Object.entries(measurements)
    .filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => `<div class="kv-row"><span>${labels[k] || k}</span><span>${v}</span></div>`)
    .join('');
}

function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('ar-DZ');
}

async function goToExamStage() {
  document.getElementById('visitTypeSelect').value = examState.defaultVisitType || 'GENERAL';
  onVisitTypeChange();
  document.getElementById('examNotes').value = '';
  examState.medications = [];
  examState.savedMedicationsCount = 0;
  document.getElementById('medNameInput').value = '';
  document.getElementById('medQuantity').value = '1 Boîte';
  document.getElementById('medDosage').value = '';
  document.getElementById('medFrequency').value = '';
  document.getElementById('medTimeOfUse').value = '';
  renderMedicationsTable();

  document.getElementById('examStageSummary').style.display = 'none';
  document.getElementById('examStageExam').style.display = 'block';
}

function onVisitTypeChange() {
  const type = document.getElementById('visitTypeSelect').value;
  document.getElementById('fertilityFields').style.display = type === 'FERTILITY' ? 'block' : 'none';
  document.getElementById('pregnancyFields').style.display = type === 'PREGNANCY' ? 'block' : 'none';
  renderVisitTypeNote(type);
}

/**
 * ملاحظة توضيحية بجانب "نوع الزيارة" بناءً على آخر متابعة مسجّلة للمريضة:
 * - متابعة حمل مستمرة: "بدون تغيير"
 * - متابعة إنجاب مستمرة: تاريخ البداية + عدد الدورات (كل دورة = شهر واحد)
 */
function renderVisitTypeNote(currentType) {
  const noteEl = document.getElementById('visitTypeNote');
  const f = examState ? examState.lastFollowUp : null;

  if (!f || f.type !== currentType) {
    noteEl.style.display = 'none';
    noteEl.textContent = '';
    return;
  }

  if (currentType === 'PREGNANCY') {
    noteEl.textContent = 'بدون تغيير — لا تزال المريضة في متابعة الحمل.';
    noteEl.style.display = 'block';
  } else if (currentType === 'FERTILITY' && f.referenceDate) {
    const cycles = Math.floor((f.daysSince || 0) / 30);
    const dateLabel = f.dateType === 'MARRIAGE' ? 'تاريخ الزواج' : 'تاريخ آخر حمل';
    noteEl.textContent = `تتم متابعة الإنجاب منذ ${dateLabel}: ${formatDate(f.referenceDate)} — عدد الدورات: ${cycles}`;
    noteEl.style.display = 'block';
  } else {
    noteEl.style.display = 'none';
    noteEl.textContent = '';
  }
}

function updatePregnancyPreview() {
  const lmp = document.getElementById('pregnancyLmpDate').value;
  const preview = document.getElementById('pregnancyPreview');
  if (!lmp) {
    preview.textContent = '';
    return;
  }
  const days = Math.floor((new Date() - new Date(lmp)) / (1000 * 60 * 60 * 24));
  const weeks = Math.floor(days / 7);
  const extraDays = days % 7;
  const edd = new Date(lmp);
  edd.setDate(edd.getDate() + 280);
  preview.textContent = `عمر الحمل التقريبي: ${weeks} أسبوعًا و${extraDays} أيام — تاريخ الولادة المتوقع: ${formatDate(edd)}`;
}

/* اقتراحات اسم الدواء أثناء الكتابة (نفس منطق البحث الحالي عبر /api/medications) */
let medNameSearchTimer = null;
async function onMedNameInput() {
  clearTimeout(medNameSearchTimer);
  const q = document.getElementById('medNameInput').value.trim();
  if (q.length < 1) return;
  medNameSearchTimer = setTimeout(async () => {
    try {
      const res = await apiRequest(`/medications?q=${encodeURIComponent(q)}&activeOnly=true`);
      document.getElementById('medNameOptions').innerHTML = res.data.map((m) => `<option value="${m.name}"></option>`).join('');
    } catch (err) {
      // فشل البحث الصامت لا يوقف الكتابة اليدوية
    }
  }, 200);
}

function addMedicationRow() {
  const name = document.getElementById('medNameInput').value.trim();
  if (!name) {
    showToast('يجب كتابة أو اختيار اسم الدواء أولًا.', 'error');
    return;
  }
  examState.medications.push({
    medicationName: name,
    quantity: document.getElementById('medQuantity').value.trim(), // الكمية: 1 Boîte...
    duration: document.getElementById('medDosage').value.trim(), // الجرعة: 1 cp...
    frequency: document.getElementById('medFrequency').value.trim(), // التكرار
    dosage: document.getElementById('medTimeOfUse').value.trim(), // وقت الاستعمال: matin/soir...
  });
  renderMedicationsTable();

  document.getElementById('medNameInput').value = '';
  document.getElementById('medDosage').value = '';
  document.getElementById('medFrequency').value = '';
  document.getElementById('medTimeOfUse').value = '';
  document.getElementById('medNameInput').focus();
}

function removeMedicationRow(index) {
  examState.medications.splice(index, 1);
  renderMedicationsTable();
}

function renderMedicationsTable() {
  const rows = examState.medications
    .map(
      (m, i) => `<tr>
        <td>${i + 1}</td><td>${m.medicationName}</td><td>${m.quantity || '—'}</td>
        <td>${m.duration || '—'}</td><td>${m.frequency || '—'}</td><td>${m.dosage || '—'}</td>
        <td><button class="btn btn-danger" onclick="removeMedicationRow(${i})">حذف</button></td>
      </tr>`
    )
    .join('');
  document.getElementById('medicationsTableBody').innerHTML = rows;
}

async function saveExam() {
  const visitType = document.getElementById('visitTypeSelect').value;
  const body = { visitType, examinationNotes: document.getElementById('examNotes').value.trim() || null };

  if (visitType === 'FERTILITY') {
    const dateVal = document.getElementById('fertilityDate').value;
    if (dateVal) {
      body.fertility = { dateType: document.getElementById('fertilityDateType').value, referenceDate: dateVal };
    }
  }
  if (visitType === 'PREGNANCY') {
    const lmp = document.getElementById('pregnancyLmpDate').value;
    if (lmp) body.pregnancy = { lmpDate: lmp };
  }

  try {
    await apiRequest(`/visits/${examState.visitId}/examination`, { method: 'PUT', body });

    const newItems = examState.medications.slice(examState.savedMedicationsCount);
    if (newItems.length > 0) {
      const res = await apiRequest(`/visits/${examState.visitId}/prescriptions`, {
        method: 'POST',
        body: { items: newItems },
      });
      examState.lastPrescriptionId = res.data.id;
      examState.savedMedicationsCount = examState.medications.length;
      document.getElementById('printPrescriptionBtn').disabled = false;
    }

    showToast('تم حفظ الفحص.', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function printPrescription() {
  if (!examState.lastPrescriptionId) return;
  window.open(`/api/prescriptions/${examState.lastPrescriptionId}/print`, '_blank');
}

/* ---------------- إنهاء الفحص (الخدمات) ---------------- */

async function openFinishExamModal() {
  try {
    if (serviceCatalog.length === 0) {
      const res = await apiRequest('/services?activeOnly=true');
      serviceCatalog = res.data;
    }
    document.getElementById('serviceSelect').innerHTML = serviceCatalog
      .map((s) => `<option value="${s.id}" data-price="${s.default_price}">${s.name}</option>`)
      .join('');
    document.getElementById('serviceSelect').onchange = () => {
      const opt = document.getElementById('serviceSelect').selectedOptions[0];
      document.getElementById('servicePriceInput').value = opt ? opt.dataset.price : '';
    };
    document.getElementById('serviceSelect').dispatchEvent(new Event('change'));

    const existing = await apiRequest(`/visits/${examState.visitId}/services`);
    examState.services = existing.data.map((s) => ({ id: s.id, serviceId: s.service_id, name: s.service_name, price: s.price }));
    renderServicesTable();

    document.getElementById('finishExamModal').style.display = 'flex';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function closeFinishExamModal() {
  document.getElementById('finishExamModal').style.display = 'none';
}

async function addServiceRow() {
  if (!examState) {
    showToast('انتهت جلسة الفحص، أعد فتحها من جديد.', 'error');
    closeFinishExamModal();
    return;
  }
  const serviceId = Number(document.getElementById('serviceSelect').value);
  const price = Number(document.getElementById('servicePriceInput').value);
  try {
    const res = await apiRequest(`/visits/${examState.visitId}/services`, {
      method: 'POST',
      body: { serviceId, price },
    });
    examState.services.push({ id: res.data.id, serviceId, name: res.data.service_name, price });
    renderServicesTable();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function removeServiceRow(lineId, index) {
  if (!examState) return;
  try {
    await apiRequest(`/visits/${examState.visitId}/services/${lineId}`, { method: 'DELETE' });
    examState.services.splice(index, 1);
    renderServicesTable();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function renderServicesTable() {
  const rows = examState.services
    .map(
      (s, i) => `<tr><td>${s.name}</td><td>${Number(s.price).toFixed(2)} دج</td>
      <td><button class="btn btn-danger" onclick="removeServiceRow(${s.id}, ${i})">حذف</button></td></tr>`
    )
    .join('');
  document.getElementById('servicesTableBody').innerHTML = rows;
  const total = examState.services.reduce((sum, s) => sum + Number(s.price), 0);
  document.getElementById('servicesTotalLabel').textContent = `إجمالي المبلغ المستحق: ${total.toFixed(2)} دج`;
}

async function confirmFinishExam() {
  if (!examState) {
    showToast('انتهت جلسة الفحص، أعد فتحها من جديد.', 'error');
    closeFinishExamModal();
    return;
  }
  if (examState.services.length === 0) {
    showToast('يجب اختيار خدمة واحدة على الأقل.', 'error');
    return;
  }
  try {
    await apiRequest(`/visits/${examState.visitId}/confirm-finish-exam`, { method: 'POST' });
    showToast('تم إنهاء الفحص — الزيارة الآن قيد الدفع لدى الاستقبال.', 'success');
    closeFinishExamModal();
    closeExam();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

init();
