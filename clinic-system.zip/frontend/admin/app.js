/* لوحة الإدارة */

let currentUser = null;
let usersCache = [];
let servicesCache = [];
let medicationsCache = [];
let medicationSearchTimer = null;
let adminPatientSearchTimer = null;
let currentPatientFileId = null;

async function init() {
  currentUser = await requireSession(['admin']);
  if (!currentUser) return;
  document.getElementById('userLabel').textContent = `${currentUser.fullName} (إدارة)`;

  await loadDashboardStats();
  await loadUsers();
  await loadServices();
  await loadBackups();

  document.getElementById('userForm').addEventListener('submit', onCreateUser);
  document.getElementById('editUserForm').addEventListener('submit', onEditUserSubmit);
  document.getElementById('serviceForm').addEventListener('submit', onCreateService);
  document.getElementById('editServiceForm').addEventListener('submit', onEditServiceSubmit);
  document.getElementById('medicationForm').addEventListener('submit', onCreateMedication);
  document.getElementById('editMedicationForm').addEventListener('submit', onEditMedicationSubmit);
  document.getElementById('adminEditPatientForm').addEventListener('submit', onAdminEditPatientSubmit);
}

function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach((p) => p.classList.toggle('active', p.id === `tab-${tab}`));
}

/* ---------------- إحصائيات سريعة ---------------- */

async function loadDashboardStats() {
  try {
    const res = await apiRequest('/admin/dashboard');
    const { counts, today } = res.data;
    // الترتيب المطلوب: مريضات اليوم الجدد، عدد زيارات اليوم، صافي إيرادات اليوم،
    // إجمالي المريضات، إجمالي الزيارات، المستخدمون النشطون (بدون فيديوهات التلفاز)
    const items = [
      { label: 'مريضات اليوم الجدد', value: today.patients.new_patients },
      { label: 'عدد زيارات اليوم', value: counts.todayVisitsCount },
      { label: 'صافي إيراد اليوم', value: `${Number(today.financial.net_revenue).toFixed(0)} دج` },
      { label: 'إجمالي المريضات', value: counts.totalPatients },
      { label: 'إجمالي الزيارات', value: counts.totalVisits },
      { label: 'المستخدمون النشطون', value: `${counts.activeUsers}/${counts.totalUsers}` },
    ];
    document.getElementById('statGrid').innerHTML = items
      .map((i) => `<div class="stat-card"><div class="value">${i.value}</div><div class="label">${i.label}</div></div>`)
      .join('');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/* ---------------- المستخدمون ---------------- */

const ROLE_LABELS = { admin: 'إدارة', reception: 'استقبال', doctor: 'طبيبة' };

async function loadUsers() {
  const res = await apiRequest('/users');
  usersCache = res.data;
  renderUsersTable();
}

function renderUsersTable() {
  const rows = usersCache
    .map(
      (u) => `
    <tr>
      <td>${u.full_name}</td>
      <td>${u.username}</td>
      <td>${ROLE_LABELS[u.role_name] || u.role_name}</td>
      <td>${u.is_active ? '<span class="badge badge-PAID">مفعّل</span>' : '<span class="badge badge-CANCELLED">معطّل</span>'}</td>
      <td class="actions-cell">
        ${
          u.is_active
            ? `<button class="btn btn-danger" onclick="toggleUser(${u.id}, false)">تعطيل</button>`
            : `<button class="btn btn-success" onclick="toggleUser(${u.id}, true)">تفعيل</button>`
        }
        <button class="btn" onclick="openEditUserModal(${u.id})">✏️ تعديل</button>
        <button class="btn btn-danger" onclick="deleteUser(${u.id})">🗑 حذف</button>
      </td>
    </tr>`
    )
    .join('');

  document.getElementById('usersTableWrap').innerHTML = `
    <table>
      <thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>الدور</th><th>الحالة</th><th>إجراءات</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function openUserModal() {
  document.getElementById('userForm').reset();
  document.getElementById('userModal').style.display = 'flex';
}
function closeUserModal() {
  document.getElementById('userModal').style.display = 'none';
}

async function onCreateUser(e) {
  e.preventDefault();
  try {
    await apiRequest('/users', {
      method: 'POST',
      body: {
        fullName: document.getElementById('u_fullName').value.trim(),
        username: document.getElementById('u_username').value.trim(),
        password: document.getElementById('u_password').value,
        roleName: document.getElementById('u_role').value,
      },
    });
    showToast('تم إنشاء المستخدم بنجاح.', 'success');
    closeUserModal();
    await loadUsers();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function toggleUser(id, activate) {
  try {
    await apiRequest(`/users/${id}/${activate ? 'activate' : 'deactivate'}`, { method: 'PUT' });
    showToast(activate ? 'تم التفعيل.' : 'تم التعطيل.', 'success');
    await loadUsers();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openEditUserModal(id) {
  const u = usersCache.find((x) => x.id === id);
  if (!u) return;
  document.getElementById('eu_id').value = u.id;
  document.getElementById('eu_fullName').value = u.full_name;
  document.getElementById('eu_newPassword').value = '';
  document.getElementById('editUserModal').style.display = 'flex';
}
function closeEditUserModal() {
  document.getElementById('editUserModal').style.display = 'none';
}

async function onEditUserSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('eu_id').value;
  const newPassword = document.getElementById('eu_newPassword').value;
  try {
    await apiRequest(`/users/${id}`, {
      method: 'PUT',
      body: {
        fullName: document.getElementById('eu_fullName').value.trim(),
        ...(newPassword ? { newPassword } : {}),
      },
    });
    showToast('تم تحديث بيانات المستخدم.', 'success');
    closeEditUserModal();
    await loadUsers();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteUser(id) {
  if (!confirm('هل تريد حذف هذا المستخدم نهائيًا؟ لا يمكن التراجع عن هذا الإجراء.')) return;
  try {
    await apiRequest(`/users/${id}`, { method: 'DELETE' });
    showToast('تم حذف المستخدم.', 'success');
    await loadUsers();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/* ---------------- الخدمات ---------------- */

async function loadServices() {
  const res = await apiRequest('/services');
  servicesCache = res.data;
  renderServicesTable();
}

function renderServicesTable() {
  const rows = servicesCache
    .map(
      (s) => `
    <tr>
      <td>${s.name}</td>
      <td>${Number(s.default_price).toFixed(2)} دج</td>
      <td>${s.is_active ? '<span class="badge badge-PAID">نشطة</span>' : '<span class="badge badge-CANCELLED">معطّلة</span>'}</td>
      <td class="actions-cell">
        ${
          s.is_active
            ? `<button class="btn btn-danger" onclick="toggleService(${s.id}, false)">تعطيل</button>`
            : `<button class="btn btn-success" onclick="toggleService(${s.id}, true)">تفعيل</button>`
        }
        <button class="btn" onclick="openEditServiceModal(${s.id})">✏️ تعديل</button>
        <button class="btn btn-danger" onclick="deleteService(${s.id})">🗑 حذف</button>
      </td>
    </tr>`
    )
    .join('');

  document.getElementById('servicesTableWrap').innerHTML = `
    <table>
      <thead><tr><th>الخدمة</th><th>السعر الافتراضي</th><th>الحالة</th><th>إجراءات</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function openServiceModal() {
  document.getElementById('serviceForm').reset();
  document.getElementById('serviceModal').style.display = 'flex';
}
function closeServiceModal() {
  document.getElementById('serviceModal').style.display = 'none';
}

async function onCreateService(e) {
  e.preventDefault();
  try {
    await apiRequest('/services', {
      method: 'POST',
      body: {
        name: document.getElementById('sv_name').value.trim(),
        defaultPrice: Number(document.getElementById('sv_price').value),
      },
    });
    showToast('تمت إضافة الخدمة.', 'success');
    closeServiceModal();
    await loadServices();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function toggleService(id, activate) {
  try {
    await apiRequest(`/services/${id}`, { method: 'PUT', body: { isActive: activate } });
    showToast(activate ? 'تم التفعيل.' : 'تم التعطيل.', 'success');
    await loadServices();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openEditServiceModal(id) {
  const s = servicesCache.find((x) => x.id === id);
  if (!s) return;
  document.getElementById('esv_id').value = s.id;
  document.getElementById('esv_name').value = s.name;
  document.getElementById('esv_price').value = s.default_price;
  document.getElementById('editServiceModal').style.display = 'flex';
}
function closeEditServiceModal() {
  document.getElementById('editServiceModal').style.display = 'none';
}

async function onEditServiceSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('esv_id').value;
  try {
    await apiRequest(`/services/${id}`, {
      method: 'PUT',
      body: {
        name: document.getElementById('esv_name').value.trim(),
        defaultPrice: Number(document.getElementById('esv_price').value),
      },
    });
    showToast('تم تحديث الخدمة.', 'success');
    closeEditServiceModal();
    await loadServices();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteService(id) {
  if (!confirm('هل تريد حذف هذه الخدمة نهائيًا؟')) return;
  try {
    await apiRequest(`/services/${id}`, { method: 'DELETE' });
    showToast('تم حذف الخدمة.', 'success');
    await loadServices();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/* ---------------- الأدوية (بحث أولًا لتخفيف الصفحة) ---------------- */

function renderMedicationsTable() {
  const wrap = document.getElementById('medicationsTableWrap');
  if (medicationsCache.length === 0) {
    wrap.innerHTML = '<div class="empty-state">لا توجد نتائج.</div>';
    return;
  }
  const rows = medicationsCache
    .map(
      (m) => `
    <tr>
      <td>${m.name}</td>
      <td>${m.is_active ? '<span class="badge badge-PAID">نشط</span>' : '<span class="badge badge-CANCELLED">معطّل</span>'}</td>
      <td class="actions-cell">
        ${
          m.is_active
            ? `<button class="btn btn-danger" onclick="toggleMedication(${m.id}, false)">تعطيل</button>`
            : `<button class="btn btn-success" onclick="toggleMedication(${m.id}, true)">تفعيل</button>`
        }
        <button class="btn" onclick="openEditMedicationModal(${m.id})">✏️ تعديل</button>
        <button class="btn btn-danger" onclick="deleteMedication(${m.id})">🗑 حذف</button>
      </td>
    </tr>`
    )
    .join('');
  wrap.innerHTML = `
    <table>
      <thead><tr><th>اسم الدواء</th><th>الحالة</th><th>إجراءات</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function onMedicationSearch() {
  clearTimeout(medicationSearchTimer);
  const q = document.getElementById('medSearchInput').value.trim();
  const wrap = document.getElementById('medicationsTableWrap');
  if (q.length === 0) {
    wrap.innerHTML = '<div class="empty-state">ابحث عن اسم دواء لعرض النتائج.</div>';
    medicationsCache = [];
    return;
  }
  medicationSearchTimer = setTimeout(async () => {
    try {
      const res = await apiRequest(`/medications?q=${encodeURIComponent(q)}`);
      medicationsCache = res.data;
      renderMedicationsTable();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }, 250);
}

function openMedicationModal() {
  document.getElementById('medicationForm').reset();
  document.getElementById('medicationModal').style.display = 'flex';
}
function closeMedicationModal() {
  document.getElementById('medicationModal').style.display = 'none';
}

async function onCreateMedication(e) {
  e.preventDefault();
  try {
    await apiRequest('/medications', { method: 'POST', body: { name: document.getElementById('med_name').value.trim() } });
    showToast('تمت إضافة الدواء.', 'success');
    closeMedicationModal();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function toggleMedication(id, activate) {
  try {
    await apiRequest(`/medications/${id}`, { method: 'PUT', body: { isActive: activate } });
    showToast(activate ? 'تم التفعيل.' : 'تم التعطيل.', 'success');
    onMedicationSearch();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openEditMedicationModal(id) {
  const m = medicationsCache.find((x) => x.id === id);
  if (!m) return;
  document.getElementById('emed_id').value = m.id;
  document.getElementById('emed_name').value = m.name;
  document.getElementById('editMedicationModal').style.display = 'flex';
}
function closeEditMedicationModal() {
  document.getElementById('editMedicationModal').style.display = 'none';
}

async function onEditMedicationSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('emed_id').value;
  try {
    await apiRequest(`/medications/${id}`, {
      method: 'PUT',
      body: { name: document.getElementById('emed_name').value.trim() },
    });
    showToast('تم تحديث الدواء.', 'success');
    closeEditMedicationModal();
    onMedicationSearch();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function deleteMedication(id) {
  if (!confirm('هل تريد حذف هذا الدواء نهائيًا من الكتالوج؟')) return;
  try {
    await apiRequest(`/medications/${id}`, { method: 'DELETE' });
    showToast('تم الحذف.', 'success');
    onMedicationSearch();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/* ---------------- إدارة المرضى ---------------- */

function onAdminPatientSearch() {
  clearTimeout(adminPatientSearchTimer);
  const q = document.getElementById('adminPatientSearch').value.trim();
  adminPatientSearchTimer = setTimeout(() => searchAdminPatients(q), 300);
}

async function searchAdminPatients(q) {
  const wrap = document.getElementById('adminPatientsListWrap');
  if (!q || q.length < 1) {
    wrap.innerHTML = '<div class="empty-state">ابحث بالاسم، رقم الملف، أو المعرّف لعرض المريضات.</div>';
    return;
  }
  try {
    const res = await apiRequest(`/patients?q=${encodeURIComponent(q)}`);
    renderAdminPatientsList(res.data);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function renderAdminPatientsList(list) {
  const wrap = document.getElementById('adminPatientsListWrap');
  if (list.length === 0) {
    wrap.innerHTML = '<div class="empty-state">لا توجد نتائج.</div>';
    return;
  }
  const rows = list
    .map(
      (p) => `
    <tr>
      <td>${p.first_name} ${p.last_name}</td>
      <td>${p.medical_file_number}</td>
      <td>${p.phone || '—'}</td>
      <td class="actions-cell">
        <button class="btn btn-primary" onclick="openPatientFile(${p.id})">📁 الملف</button>
        <button class="btn" onclick="openAdminEditPatientModal(${p.id})">✏️ تعديل</button>
        <button class="btn btn-danger" onclick="deleteAdminPatient(${p.id}, '${(p.first_name + ' ' + p.last_name).replace(/'/g, "\\'")}')">🗑 حذف</button>
      </td>
    </tr>`
    )
    .join('');
  wrap.innerHTML = `
    <table>
      <thead><tr><th>الاسم</th><th>رقم الملف</th><th>الهاتف</th><th>إجراءات</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

async function deleteAdminPatient(id, name) {
  if (!confirm(`هل تريد حذف حساب المريضة "${name}" نهائيًا؟\nإذا كان لديها زيارات مسجّلة سيُرفض الحذف تلقائيًا للحفاظ على السجل الطبي.`)) return;
  try {
    await apiRequest(`/patients/${id}`, { method: 'DELETE' });
    showToast('تم حذف حساب المريضة.', 'success');
    const q = document.getElementById('adminPatientSearch').value.trim();
    if (q) searchAdminPatients(q);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function openPatientFile(patientId) {
  currentPatientFileId = patientId;
  try {
    const [patientRes, visitsRes] = await Promise.all([
      apiRequest(`/patients/${patientId}`),
      apiRequest(`/patients/${patientId}/visits`),
    ]);
    const patient = patientRes.data;
    const visits = visitsRes.data;

    document.getElementById('patientFileTitle').textContent = `ملف المريضة: ${patient.first_name} ${patient.last_name} — ${patient.medical_file_number}`;

    if (visits.length === 0) {
      document.getElementById('patientFileContent').innerHTML = '<div class="empty-state">لا توجد زيارات مسجّلة بعد.</div>';
    } else {
      document.getElementById('patientFileContent').innerHTML = visits
        .map(
          (v, i) => `
        <div class="patient-file-visit" id="pfv-${v.id}" onclick="toggleVisitDetails(${v.id})">
          <strong>${new Date(v.visit_date).toLocaleDateString('ar-DZ')}</strong>
          <span style="color:var(--text-muted); font-size:12.5px; margin-right:8px;">${statusBadge(v.status)}</span>
          <div class="meds-panel" id="pfv-panel-${v.id}"></div>
        </div>`
        )
        .join('');
    }

    document.getElementById('patientFileModal').style.display = 'flex';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function toggleVisitDetails(visitId) {
  const row = document.getElementById(`pfv-${visitId}`);
  const panel = document.getElementById(`pfv-panel-${visitId}`);
  const isExpanded = row.classList.contains('expanded');

  if (isExpanded) {
    row.classList.remove('expanded');
    return;
  }
  row.classList.add('expanded');

  if (panel.dataset.loaded === 'true') return;

  try {
    const [visitRes, prescRes] = await Promise.all([
      apiRequest(`/visits/${visitId}`),
      apiRequest(`/visits/${visitId}/prescriptions`),
    ]);

    const measurements = visitRes.data.medicalHistory ? visitRes.data.medicalHistory.reception_measurements : null;
    const measurementsHtml = renderMeasurementsInline(measurements);

    let medsHtml = '<div style="color:var(--text-muted); font-size:12.5px;">لا توجد أدوية موصوفة في هذه الزيارة.</div>';
    const allItems = (prescRes.data || []).flatMap((p) => p.items);
    if (allItems.length > 0) {
      medsHtml = `<table style="margin-top:6px;"><thead><tr><th>الدواء</th><th>الكمية</th><th>التكرار</th></tr></thead><tbody>${allItems
        .map((it) => `<tr><td>${it.medication_name}</td><td>${it.quantity || '—'}</td><td>${it.frequency || '—'}</td></tr>`)
        .join('')}</tbody></table>`;
    }

    panel.innerHTML = `
      <div style="margin-bottom:8px;"><strong style="font-size:12.5px;">القياسات:</strong> ${measurementsHtml}</div>
      <div><strong style="font-size:12.5px;">الأدوية الموصوفة:</strong> ${medsHtml}</div>
    `;
    panel.dataset.loaded = 'true';
  } catch (err) {
    panel.innerHTML = `<div style="color:var(--danger); font-size:12.5px;">تعذر تحميل التفاصيل: ${err.message}</div>`;
  }
}

function renderMeasurementsInline(m) {
  if (!m || Object.keys(m).length === 0) return '<span style="color:var(--text-muted);">لا توجد قياسات مسجّلة.</span>';
  const labels = { blood_pressure: 'ضغط الدم', blood_sugar: 'السكر', weight: 'الوزن', notes: 'ملاحظات' };
  return Object.entries(m)
    .filter(([, v]) => v)
    .map(([k, v]) => `${labels[k] || k}: ${v}`)
    .join(' — ');
}

function closePatientFileModal() {
  document.getElementById('patientFileModal').style.display = 'none';
  currentPatientFileId = null;
}

async function openAdminEditPatientModal(patientId) {
  try {
    const res = await apiRequest(`/patients/${patientId}`);
    const p = res.data;
    document.getElementById('aep_id').value = p.id;
    document.getElementById('aep_firstName').value = p.first_name || '';
    document.getElementById('aep_lastName').value = p.last_name || '';
    document.getElementById('aep_birthDate').value = p.birth_date ? p.birth_date.slice(0, 10) : '';
    document.getElementById('aep_phone').value = p.phone || '';
    document.getElementById('aep_address').value = p.address || '';
    document.getElementById('adminEditPatientModal').style.display = 'flex';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function closeAdminEditPatientModal() {
  document.getElementById('adminEditPatientModal').style.display = 'none';
}

async function onAdminEditPatientSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('aep_id').value;
  try {
    await apiRequest(`/patients/${id}`, {
      method: 'PUT',
      body: {
        firstName: document.getElementById('aep_firstName').value.trim(),
        lastName: document.getElementById('aep_lastName').value.trim(),
        birthDate: document.getElementById('aep_birthDate').value || null,
        phone: document.getElementById('aep_phone').value.trim() || null,
        address: document.getElementById('aep_address').value.trim() || null,
      },
    });
    showToast('تم تحديث بيانات المريضة.', 'success');
    closeAdminEditPatientModal();
    const q = document.getElementById('adminPatientSearch').value.trim();
    if (q) searchAdminPatients(q);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/* ---------------- النسخ الاحتياطي ---------------- */

async function loadBackups() {
  const res = await apiRequest('/backups');
  const backups = res.data;
  if (backups.length === 0) {
    document.getElementById('backupsTableWrap').innerHTML = '<div class="empty-state">لا توجد نسخ احتياطية بعد.</div>';
    return;
  }
  const typeLabels = { DAILY: 'يومي', WEEKLY: 'أسبوعي', MONTHLY: 'شهري', MANUAL: 'يدوي', UPLOADED: 'مرفوعة يدويًا' };
  const rows = backups
    .map(
      (b) => `
    <tr>
      <td>${new Date(b.created_at).toLocaleString('ar-DZ')}</td>
      <td>${typeLabels[b.type] || b.type}</td>
      <td>${(b.size_bytes / (1024 * 1024)).toFixed(1)} MB</td>
      <td><a class="btn" href="/api/backups/${b.id}/download">⬇ تنزيل نسخة احتياطية</a></td>
    </tr>`
    )
    .join('');
  document.getElementById('backupsTableWrap').innerHTML = `
    <table>
      <thead><tr><th>التاريخ</th><th>النوع</th><th>الحجم</th><th></th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

async function runBackupNow() {
  const btn = document.getElementById('runBackupBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> جارٍ الإنشاء...';
  try {
    await apiRequest('/backups/run', { method: 'POST' });
    showToast('تم إنشاء النسخة الاحتياطية بنجاح.', 'success');
    await loadBackups();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '💾 إنشاء نسخة احتياطية الآن';
  }
}

async function uploadBackup() {
  const fileInput = document.getElementById('backupUploadInput');
  if (!fileInput.files[0]) {
    showToast('اختر ملف ZIP أولًا.', 'error');
    return;
  }
  const btn = document.getElementById('uploadBackupBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>';

  const formData = new FormData();
  formData.append('file', fileInput.files[0]);

  try {
    const res = await fetch('/api/backups/upload', { method: 'POST', credentials: 'include', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'فشل الرفع.');
    showToast('تم رفع النسخة الاحتياطية بنجاح.', 'success');
    fileInput.value = '';
    await loadBackups();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'رفع';
  }
}

init();
