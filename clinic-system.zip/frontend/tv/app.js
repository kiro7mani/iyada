/* شاشة التلفاز — صفحة عامة بدون تسجيل دخول */

const API_BASE = '/api';

let playlist = [];
let currentIndex = 0;
let manuallyMuted = false; // حالة الكتم اليدوي (تبقى بعد انتهاء أي نداء)
let currentVolume = 80;
let callRepeatCount = 2;
let announcementInProgress = false;

const videoEl = document.getElementById('main-video');
const noMediaLabel = document.getElementById('noMediaLabel');
const ticketBox = document.getElementById('ticket-anim');
const currentNumberEl = document.getElementById('current-number');

async function init() {
  await loadCurrentConfig();
  setupSocket();
  startClock();
}

async function loadCurrentConfig() {
  try {
    const res = await fetch(`${API_BASE}/tv/playlist/current`);
    const data = await res.json();
    if (!data.success) return;

    document.getElementById('clinic-name').textContent = data.data.clinicName;

    if (data.data.logoPath) {
      const logoImg = document.getElementById('clinic-logo-img');
      logoImg.src = data.data.logoPath;
      logoImg.style.display = 'block';
    }

    const display = data.data.display || {};
    currentVolume = display.call_volume !== undefined ? display.call_volume : 80;
    callRepeatCount = display.call_repeat_count !== undefined ? display.call_repeat_count : 2;

    playlist = data.data.playlist || [];

    if (playlist.length > 0) {
      playVideoAt(0);
    } else {
      noMediaLabel.style.display = 'flex';
    }
  } catch (err) {
    // فشل تحميل الإعدادات (السيرفر غير متاح لحظيًا) — لا نوقف الشاشة، نعيد المحاولة لاحقًا
    setTimeout(loadCurrentConfig, 15000);
  }
}

/**
 * تشغيل الفيديوهات تلقائيًا بالتناوب؛ عند وصول آخر فيديو للنهاية يُعاد التشغيل من الفيديو الأول.
 */
function playVideoAt(index) {
  if (playlist.length === 0) return;
  currentIndex = ((index % playlist.length) + playlist.length) % playlist.length;
  videoEl.src = playlist[currentIndex].url;
  videoEl.muted = manuallyMuted;
  videoEl.play().catch(() => {});
}

videoEl.addEventListener('ended', () => playVideoAt(currentIndex + 1));

function setupSocket() {
  const socket = io({ withCredentials: false });
  socket.on('connect', () => socket.emit('join_room', { room: 'tv' }));

  socket.on('patient_called', (payload) => announcePatient(payload.queueNumber, false));
  socket.on('patient_recalled', (payload) => announcePatient(payload.queueNumber, true));

  socket.on('tv_play', () => videoEl.play().catch(() => {}));
  socket.on('tv_pause', () => videoEl.pause());
  socket.on('tv_next', () => playVideoAt(currentIndex + 1));
  socket.on('tv_previous', () => playVideoAt(currentIndex - 1));
  socket.on('tv_mute', () => {
    manuallyMuted = true;
    videoEl.muted = true;
  });
  socket.on('tv_unmute', () => {
    manuallyMuted = false;
    if (!announcementInProgress) videoEl.muted = false;
  });
  socket.on('tv_volume', (payload) => {
    currentVolume = payload.level;
  });
  socket.on('announcement_start', (payload) => announcePatient(payload.queueNumber, false));
}

function playChime() {
  const sound = document.getElementById('airport-sound');
  if (!sound) return Promise.resolve();
  return new Promise((resolve) => {
    sound.currentTime = 0;
    sound.onended = resolve;
    sound.play().then(() => {
      // إذا تعذّر تحديد onended (ملف غير موجود)، لا نعلّق التنفيذ أكثر من ثانيتين
      setTimeout(resolve, 2000);
    }).catch(resolve);
  });
}

/**
 * تدفق الاستدعاء: حفظ حالة صوت الفيديو → كتم مؤقت → صوت تنبيه (Chime) → نداء صوتي
 * (مكرر حسب الإعداد) → عرض الرقم بوضوح مع تأثير حركي → إعادة الصوت لحالته السابقة
 * (يبقى مكتومًا إن كان كذلك يدويًا). لا يُعرض اسم المريضة إطلاقًا، فقط رقم الانتظار.
 */
async function announcePatient(queueNumber, isRecall) {
  announcementInProgress = true;
  videoEl.muted = true;

  currentNumberEl.textContent = String(queueNumber).padStart(2, '0');
  ticketBox.style.animation = 'none';
  // eslint-disable-next-line no-unused-expressions
  ticketBox.offsetHeight; // إعادة تفعيل الـ DOM reflow لتشغيل الأنيميشن من جديد
  ticketBox.style.animation = 'ticket-pop 0.6s cubic-bezier(.175,.885,.32,1.275)';

  await playChime();
  await speakAnnouncement(queueNumber, callRepeatCount);

  videoEl.muted = manuallyMuted;
  announcementInProgress = false;
}

function speakAnnouncement(queueNumber, repeatCount) {
  return new Promise((resolve) => {
    if (!('speechSynthesis' in window)) {
      setTimeout(resolve, 1500);
      return;
    }

    const text = `المريضة رقم ${queueNumber}، يرجى التوجه إلى غرفة الفحص.`;
    let remaining = Math.max(1, repeatCount || 1);

    function speakOnce() {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.volume = Math.min(1, Math.max(0, currentVolume / 100));
      utterance.rate = 0.95;
      utterance.onend = () => {
        remaining -= 1;
        if (remaining > 0) {
          setTimeout(speakOnce, 400);
        } else {
          resolve();
        }
      };
      utterance.onerror = () => resolve();
      window.speechSynthesis.speak(utterance);
    }

    speakOnce();
  });
}

function startClock() {
  function tick() {
    const now = new Date();
    document.getElementById('clock').textContent = now.toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit' });
    document.getElementById('date').textContent = now.toLocaleDateString('ar-DZ', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    });
  }
  tick();
  setInterval(tick, 1000 * 30);
}

init();
