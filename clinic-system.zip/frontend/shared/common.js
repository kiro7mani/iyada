/* أدوات مشتركة تُستخدم في كل صفحات الواجهة */

const API_BASE = '/api';

/**
 * غلاف موحّد لـ fetch: يرسل الـ Cookie تلقائيًا، ويحوّل الأخطاء إلى استثناء واضح بالعربية.
 */
async function apiRequest(path, { method = 'GET', body = null, isFile = false } = {}) {
  const options = {
    method,
    credentials: 'include',
    headers: {},
  };
  if (body) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  }

  const res = await fetch(API_BASE + path, options);

  if (isFile) {
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: 'حدث خطأ غير متوقع.' }));
      throw new ApiError(err.message || 'حدث خطأ غير متوقع.', res.status, err.code, err.data);
    }
    return res;
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError(data.message || 'حدث خطأ غير متوقع.', res.status, data.code, data.data);
  }
  return data;
}

class ApiError extends Error {
  constructor(message, status, code, data) {
    super(message);
    this.status = status;
    this.code = code;
    this.data = data;
  }
}

/** يعرض Toast قصير أسفل الشاشة */
function showToast(message, type = 'info') {
  let wrap = document.querySelector('.toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.className = 'toast-wrap';
    document.body.appendChild(wrap);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  wrap.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

const STATUS_LABELS = {
  BOOKED: 'محجوزة',
  PRESENT: 'حاضرة',
  WAITING: 'في الانتظار',
  CALLED: 'تم الاستدعاء',
  WITH_DOCTOR: 'عند الطبيبة',
  EXAM_COMPLETED: 'انتهى الفحص',
  AWAITING_PAYMENT: 'بانتظار الدفع',
  PAID: 'مدفوعة',
  COMPLETED: 'مكتملة',
  CANCELLED: 'ملغاة',
  NO_SHOW: 'لم تحضر',
};

function statusBadge(status) {
  const label = STATUS_LABELS[status] || status;
  return `<span class="badge badge-${status}">${label}</span>`;
}

/** يتحقق من الجلسة، ويعيد التوجيه إلى /login إذا لم يكن هناك تسجيل دخول صالح */
async function requireSession(allowedRoles = []) {
  try {
    const res = await apiRequest('/auth/me');
    if (allowedRoles.length > 0 && !allowedRoles.includes(res.data.role)) {
      window.location.href = '/login';
      return null;
    }
    return res.data;
  } catch (err) {
    window.location.href = '/login';
    return null;
  }
}

async function logout() {
  try {
    await apiRequest('/auth/logout', { method: 'POST' });
  } finally {
    window.location.href = '/login';
  }
}
