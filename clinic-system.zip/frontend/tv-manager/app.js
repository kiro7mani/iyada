/* إدارة شاشة التلفاز */

let currentUser = null;
let mediaLibrary = [];
let defaultPlaylist = null;
let playlistItems = [];

async function init() {
  currentUser = await requireSession(['admin']);
  if (!currentUser) return;
  document.getElementById('userLabel').textContent = `${currentUser.fullName} (إدارة)`;

  await ensureDefaultPlaylist();
  await loadMedia();
  await loadPlaylistItems();

  document.getElementById('uploadForm').addEventListener('submit', onUpload);
}

async function ensureDefaultPlaylist() {
  const res = await apiRequest('/tv/playlists');
  defaultPlaylist = res.data.find((p) => p.is_default);
  if (!defaultPlaylist) {
    const created = await apiRequest('/tv/playlists', {
      method: 'POST',
      body: { name: 'القائمة الافتراضية', isDefault: true },
    });
    defaultPlaylist = created.data;
  }
}

async function loadMedia() {
  const res = await apiRequest('/tv/media');
  mediaLibrary = res.data;
  renderMediaList();
  renderMediaSelect();
}

function renderMediaList() {
  const wrap = document.getElementById('mediaList');
  if (mediaLibrary.length === 0) {
    wrap.innerHTML = '<div class="empty-state">لا توجد فيديوهات مرفوعة بعد.</div>';
    return;
  }
  wrap.innerHTML = mediaLibrary
    .map(
      (m) => `
    <div class="media-item">
      <span>${m.title} <span style="color:var(--text-muted); font-size:11.5px;">(${m.category || '—'})</span></span>
      <button class="btn btn-danger" onclick="deleteMedia(${m.id})">حذف</button>
    </div>`
    )
    .join('');
}

function renderMediaSelect() {
  const select = document.getElementById('addToPlaylistSelect');
  select.innerHTML = mediaLibrary.map((m) => `<option value="${m.id}">${m.title}</option>`).join('');
}

async function onUpload(e) {
  e.preventDefault();
  const btn = document.getElementById('uploadBtn');
  const fileInput = document.getElementById('videoFile');
  if (!fileInput.files[0]) return;

  const formData = new FormData();
  formData.append('file', fileInput.files[0]);
  formData.append('title', document.getElementById('videoTitle').value.trim());
  formData.append('category', document.getElementById('videoCategory').value);

  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> جارٍ الرفع...';

  try {
    const res = await fetch('/api/tv/media', { method: 'POST', credentials: 'include', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'فشل الرفع.');
    showToast('تم رفع الفيديو بنجاح.', 'success');
    document.getElementById('uploadForm').reset();
    await loadMedia();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '⬆ رفع الفيديو';
  }
}

async function deleteMedia(id) {
  if (!confirm('هل تريد حذف هذا الفيديو نهائيًا؟')) return;
  try {
    await apiRequest(`/tv/media/${id}`, { method: 'DELETE' });
    showToast('تم الحذف.', 'success');
    await loadMedia();
    await loadPlaylistItems();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function loadPlaylistItems() {
  if (!defaultPlaylist) return;
  const res = await apiRequest(`/tv/playlists/${defaultPlaylist.id}`);
  playlistItems = res.data.items;
  renderPlaylistItems();
}

function renderPlaylistItems() {
  const wrap = document.getElementById('playlistList');
  if (playlistItems.length === 0) {
    wrap.innerHTML = '<div class="empty-state">القائمة فارغة — أضف فيديوهات من المكتبة.</div>';
    return;
  }
  wrap.innerHTML = playlistItems
    .map(
      (item, index) => `
    <div class="playlist-item">
      <span>${index + 1}. ${item.title}</span>
      <button class="btn btn-danger" onclick="removeFromPlaylist(${item.id})">حذف</button>
    </div>`
    )
    .join('');
}

async function addSelectedToPlaylist() {
  const mediaId = Number(document.getElementById('addToPlaylistSelect').value);
  if (!mediaId || !defaultPlaylist) return;
  try {
    await apiRequest(`/tv/playlists/${defaultPlaylist.id}/items`, {
      method: 'POST',
      body: { mediaId, orderIndex: playlistItems.length },
    });
    showToast('تمت الإضافة إلى القائمة.', 'success');
    await loadPlaylistItems();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function removeFromPlaylist(itemId) {
  try {
    await apiRequest(`/tv/playlists/${defaultPlaylist.id}/items/${itemId}`, { method: 'DELETE' });
    showToast('تم الحذف من القائمة.', 'success');
    await loadPlaylistItems();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

init();
