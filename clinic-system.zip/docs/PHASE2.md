# PHASE 2 — المرضى، البحث، منع التكرار، QR، الملف الطبي

## المتطلبات الإضافية

بعد سحب هذا التحديث، شغّل داخل `backend`:

```bash
npm install     # لتثبيت qrcode و pdfkit الجديدتين
npm run migrate # لتنفيذ ترحيل 002 (Sequence رقم الملف + pg_trgm)
```

## نقاط API الجديدة

كلها تحت `/api/patients` وتتطلب تسجيل دخول.

| Method | Path | الصلاحية | الوصف |
|---|---|---|---|
| GET | `/api/patients?q=&birthDate=` | admin, reception, doctor | بحث مدمج بالاسم/الهاتف/رقم الملف + تصفية اختيارية بتاريخ الميلاد |
| GET | `/api/patients/by-qr/:token` | admin, reception, doctor | فتح ملف المريضة عبر مسح QR |
| GET | `/api/patients/:id` | admin, reception, doctor | تفاصيل مريضة |
| GET | `/api/patients/:id/qr` | admin, reception, doctor | صورة QR (PNG) |
| GET | `/api/patients/:id/medical-file/print` | admin, reception, doctor | الملف الطبي كـ PDF (A4 قابل للطي إلى A5) |
| POST | `/api/patients/check-duplicate` | admin, reception | فحص وجود مريضة مشابهة دون إنشاء |
| POST | `/api/patients` | admin, reception | إنشاء مريضة جديدة (يفحص التكرار تلقائيًا) |
| PUT | `/api/patients/:id` | admin, reception | تعديل بيانات مريضة |

## آلية منع التكرار

عند `POST /api/patients`:

1. يبحث النظام تلقائيًا عن مريضات مشابهات بناءً على:
   - تشابه الاسم الكامل (عتبة 35% عبر `pg_trgm`)
   - تطابق تام في تاريخ الميلاد
   - تطابق تام في رقم الهاتف
2. إذا وُجدت نتائج ولم يُرسل `forceCreate: true` في الطلب → يرجع الخادم **409** مع قائمة المرشحين، ولا يُنشئ ملفًا جديدًا.
3. الموظف يراجع القائمة في الواجهة (تُبنى في PHASE 4)، وإذا تأكد أنها مريضة مختلفة يعيد الطلب بـ `forceCreate: true`.

## مثال: إنشاء مريضة جديدة

```bash
curl -i -X POST http://localhost:4000/api/patients \
  -H "Content-Type: application/json" \
  -b "clinic_session=<TOKEN من تسجيل الدخول>" \
  -d '{
    "firstName": "فاطمة",
    "lastName": "بن أحمد",
    "birthDate": "1990-05-12",
    "phone": "0555123456",
    "address": "البليدة"
  }'
```

إذا رجعت 409، أعد الإرسال مع `"forceCreate": true` بعد التأكد.

## ملاحظة حول QR

الـ Token المخزّن في `patient_qr.token` هو نص عشوائي آمن (48 حرف hex) فقط — لا يحتوي على أي اسم أو هاتف أو تاريخ ميلاد أو بيانات طبية، تمامًا كما هو مطلوب في المواصفة الأصلية.

## الخطوة التالية

PHASE 3: الحجز، رقم الانتظار اليومي (منفصل عن رقم الملف الطبي)، الطباعة الحرارية للكوبون.
