# دليل التثبيت — PHASE 1

## 1. تثبيت PostgreSQL

```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
```

إنشاء المستخدم وقاعدة البيانات:

```bash
sudo -u postgres psql
```

داخل psql:

```sql
CREATE USER clinic_admin WITH PASSWORD 'ضع_كلمة_مرور_قوية_هنا';
CREATE DATABASE clinic_system OWNER clinic_admin;
GRANT ALL PRIVILEGES ON DATABASE clinic_system TO clinic_admin;
\q
```

## 2. تثبيت Node.js

يُفضّل استخدام NVM:

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
nvm install 20
nvm use 20
```

## 3. إعداد المشروع

```bash
cd clinic-system/backend
cp .env.example .env
```

عدّل ملف `.env`:

```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=clinic_system
DB_USER=clinic_admin
DB_PASSWORD=نفس_كلمة_المرور_التي_وضعتها_فوق

JWT_SECRET=<ولّد قيمة عشوائية عبر: openssl rand -hex 64>
```

```bash
npm install
```

## 4. تشغيل الترحيل والبذور

```bash
npm run migrate
npm run seed
```

يجب أن تظهر رسالة تؤكد إنشاء الأدوار ومستخدم Admin الافتراضي.

## 5. تشغيل السيرفر

```bash
npm run dev
```

تحقق من عمل السيرفر:

```bash
curl http://localhost:4000/api/health
```

يجب أن يرجع:
```json
{"success":true,"message":"الخادم يعمل بشكل طبيعي."}
```

## 6. اختبار تسجيل الدخول

```bash
curl -i -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"ChangeMe123!"}'
```

يجب أن يرجع بيانات المستخدم مع تعيين Cookie باسم `clinic_session`.

## 7. تشغيل السيرفر دائمًا (اختياري - production)

يُفضّل استخدام PM2 لإبقاء السيرفر يعمل تلقائيًا بعد إعادة تشغيل الـ Mini PC:

```bash
npm install -g pm2
cd clinic-system/backend
pm2 start src/server.js --name clinic-backend
pm2 save
pm2 startup
```

## الخطوة التالية

بعد التأكد من عمل PHASE 1، ننتقل إلى PHASE 2: المرضى، البحث، منع التكرار، QR، الملف الطبي.
