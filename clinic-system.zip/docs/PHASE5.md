# PHASE 5 — الفحص الطبي، متابعة الحمل، الأشعة والتحاليل

## المتطلبات الإضافية

```bash
cd backend
npm install   # لتثبيت multer (رفع الملفات)
```

لا يوجد ترحيل قاعدة بيانات جديد (الجداول `medical_history`, `pregnancies`, `pregnancy_visits`, `radiology`, `lab_results` أُنشئت مسبقًا في PHASE 1).

هذه المرحلة **Backend فقط** (بدون واجهة رسومية جديدة) — نموذج الفحص الطبي والحمل في لوحة الطبيبة يُبنى بصريًا في مرحلة لاحقة مع الوصفات والتسعير (PHASE 6) ليكونا شاشة واحدة متكاملة. يمكن اختبار كل شيء الآن عبر `curl`/Postman.

## نقاط API الجديدة

### الزيارة الطبية (`/api/visits`)

| Method | Path | الصلاحية | الوصف |
|---|---|---|---|
| GET | `/:id` | الكل | تفاصيل الزيارة + المريضة + السجل الطبي |
| PUT | `/:id/measurements` | admin, reception | قياسات الاستقبال (ضغط، سكر، وزن، طول، حرارة) |
| PUT | `/:id/examination` | admin, doctor | الفحص والتشخيص وخطة العلاج (يتطلب أن تكون الزيارة WITH_DOCTOR) |
| POST | `/:id/complete-exam` | admin, doctor | WITH_DOCTOR → EXAM_COMPLETED |
| POST | `/:id/radiology` | admin, doctor | رفع أشعة/إيكوغرافي (multipart: `file` + `reportText` + `notes`) |
| GET | `/:id/radiology` | الكل | أشعة هذه الزيارة |
| POST | `/:id/labs` | admin, doctor | إضافة نتيجة تحليل (`testName` مطلوب، `file` اختياري) |
| GET | `/:id/labs` | الكل | تحاليل هذه الزيارة |

### السجل الطبي الكامل (`/api/patients/:id/...`)

| Method | Path | الوصف |
|---|---|---|
| GET | `/:id/visits` | كل زيارات المريضة (Timeline) |
| GET | `/:id/pregnancies` | كل سجلات الحمل للمريضة |
| POST | `/:id/pregnancies` | تسجيل حمل جديد (admin, doctor) |
| GET | `/:id/radiology` | كل أشعة المريضة عبر كل الزيارات |
| GET | `/:id/labs` | كل تحاليل المريضة عبر كل الزيارات |

### متابعة الحمل (`/api/pregnancies`)

| Method | Path | الصلاحية | الوصف |
|---|---|---|---|
| GET | `/:id` | الكل | بيانات الحمل + Timeline الزيارات كاملًا |
| PUT | `/:id` | admin, doctor | تعديل LMP/EDD/Gravida/Para |
| PUT | `/:id/status` | admin, doctor | ACTIVE / DELIVERED / TERMINATED |
| POST | `/:id/visits` | admin, doctor | إضافة نقطة جديدة في Timeline مرتبطة بزيارة فعلية |

### ملفات الأشعة/التحاليل

| Method | Path | الوصف |
|---|---|---|
| GET | `/api/radiology/:id/file` | تنزيل/عرض ملف الأشعة (محمي بتسجيل الدخول) |
| GET | `/api/labs/:id/file` | تنزيل/عرض ملف نتيجة تحليل مرفق |

## حساب موعد الولادة المتوقع (EDD)

عند إنشاء سجل حمل بدون إرسال `eddDate`، يحسبه الخادم تلقائيًا: **LMP + 280 يومًا** (قاعدة نيغل التقريبية). يمكن إرسال `eddDate` صراحة لتجاوز الحساب التلقائي إذا حدّدته الطبيبة يدويًا (مثلاً بناءً على الإيكوغرافي).

## أمان رفع الملفات

- الأنواع المسموحة فقط: `image/jpeg`, `image/png`, `image/webp`, `application/pdf`.
- الحجم الأقصى يُضبط عبر `MAX_UPLOAD_SIZE_MB` في `.env` (الافتراضي 25MB).
- أسماء الملفات على القرص عشوائية بالكامل (لا تحتفظ باسم الملف الأصلي) لمنع أي استغلال في المسار.
- الوصول للملفات يتطلب تسجيل دخول (`GET /api/radiology/:id/file`), لا روابط عامة مباشرة.

## مثال: تسجيل حمل ثم زيارة متابعة

```bash
# 1) تسجيل الحمل
curl -X POST http://localhost:4000/api/patients/5/pregnancies \
  -H "Content-Type: application/json" -b "clinic_session=<TOKEN>" \
  -d '{"lmpDate":"2026-03-01","gravida":2,"para":1}'
# → يُحسب eddDate تلقائيًا: 2026-12-05

# 2) إضافة زيارة متابعة (بعد أن تكون الزيارة WITH_DOCTOR)
curl -X POST http://localhost:4000/api/pregnancies/1/visits \
  -H "Content-Type: application/json" -b "clinic_session=<TOKEN>" \
  -d '{"visitId": 12, "gestationalAgeWeeks": 24, "weight": 68.5, "bloodPressure":"12/8", "ultrasoundSummary":"نمو طبيعي"}'
```

## مثال: رفع صورة إيكوغرافي

```bash
curl -X POST http://localhost:4000/api/visits/12/radiology \
  -b "clinic_session=<TOKEN>" \
  -F "file=@/path/to/scan.jpg" \
  -F "reportText=نمو الجنين طبيعي ضمن العمر الحملي" \
  -F "notes=موعد المتابعة القادمة بعد 4 أسابيع"
```

## الخطوة التالية

PHASE 6: الوصفات الطبية، تحديد سعر الفحص والخدمات، التخفيض، الدفع، طباعة الوصفة والوصل.
