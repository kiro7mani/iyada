# PHASE 3 — الحجز، الانتظار اليومي، الطباعة الحرارية

## المتطلبات الإضافية

```bash
cd backend
npm install   # لتثبيت node-thermal-printer
```

لا يوجد ترحيل قاعدة بيانات جديد (الجداول `visits` و `daily_queue` أُنشئت مسبقًا في PHASE 1).

اضبط `PRINTER_INTERFACE` في `.env`:
- طابعة عبر الشبكة: `tcp://192.168.1.87`
- طابعة USB على ويندوز: `printer:اسم_الطابعة_في_نظام_التشغيل`

## نقاط API الجديدة (تحت `/api/queue`)

| Method | Path | الصلاحية | الوصف |
|---|---|---|---|
| GET | `/today` | admin, reception, doctor | قائمة انتظار اليوم كاملة مرتبة برقم الانتظار |
| POST | `/book` | admin, reception | حجز مريضة (`{patientId, visitType, presentNow}`) |
| POST | `/confirm-presence/:visitId` | admin, reception | تأكيد حضور مريضة محجوزة هاتفيًا (BOOKED → WAITING) |
| POST | `/cancel/:visitId` | admin, reception | إلغاء حجز (قبل دخولها للطبيبة) |
| POST | `/no-show/:visitId` | admin, reception | تعليم "لم تحضر" |
| POST | `/print-ticket/:visitId` | admin, reception | طباعة كوبون الانتظار الحراري |
| POST | `/test-printer` | admin, reception | اختبار اتصال الطابعة |

## آلية منع تكرار الحجز (القسم 17)

عند `POST /api/queue/book`، يبحث النظام أولاً عن أي زيارة **نشطة** لنفس المريضة بنفس التاريخ (أي حالة غير `CANCELLED`/`NO_SHOW`). إذا وُجدت:

```json
{
  "success": false,
  "code": "ALREADY_BOOKED_TODAY",
  "message": "هذه المريضة لديها حجز بالفعل اليوم.",
  "data": { "visit": {...}, "queue": {"queue_number": 27, ...} }
}
```

لا يُنشأ رقم انتظار جديد في هذه الحالة.

## أمان رقم الانتظار

توليد `queue_number` يستخدم `pg_advisory_xact_lock` مبنيًا على تاريخ اليوم، مما يمنع تمامًا احتمال تكرار نفس الرقم في نفس اليوم حتى لو وصل طلبان في نفس اللحظة من جهازين مختلفين. القفل يُحرَّر تلقائيًا عند إنهاء الـ Transaction.

## مثال: حجز مريضة حاضرة فعليًا في الاستقبال

```bash
curl -i -X POST http://localhost:4000/api/queue/book \
  -H "Content-Type: application/json" \
  -b "clinic_session=<TOKEN>" \
  -d '{"patientId": 5, "presentNow": true}'
```

النتيجة: الزيارة تُنشأ مباشرة بحالة `WAITING` (بدون المرور بـ BOOKED/PRESENT)، لأن المريضة حاضرة فعلاً أمام الاستقبال.

## مثال: حجز هاتفي (المريضة غير حاضرة)

```bash
curl -i -X POST http://localhost:4000/api/queue/book \
  -H "Content-Type: application/json" \
  -b "clinic_session=<TOKEN>" \
  -d '{"patientId": 5}'
```

الحالة تبدأ `BOOKED`. عند وصولها لاحقًا:

```bash
curl -i -X POST http://localhost:4000/api/queue/confirm-presence/12 \
  -b "clinic_session=<TOKEN>"
```

## الخطوة التالية

PHASE 4: واجهات Reception Dashboard و Doctor Dashboard (أول واجهة رسومية فعلية يمكن تشغيلها ومشاهدتها في المتصفح)، بالإضافة إلى منطق استدعاء المريضة التالية (`call-next`, `recall`).
