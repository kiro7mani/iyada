# PHASE 7 — الإحصائيات

لا مكتبات أو ترحيلات جديدة. Backend فقط (الرسوم البيانية المرئية لهذه البيانات تُبنى مع لوحة الإدارة في PHASE 9).

## نقاط API (تحت `/api/statistics`, صلاحية admin و doctor فقط)

| Method | Path | الوصف |
|---|---|---|
| GET | `/daily?date=` | تقرير يوم واحد (افتراضيًا اليوم) |
| GET | `/weekly?date=` | تقرير الأسبوع المحتوي على `date` (السبت→الجمعة) |
| GET | `/monthly?year=&month=` | تقرير شهر كامل |
| GET | `/yearly?year=` | تقرير سنة كاملة |
| GET | `/range?from=&to=` | تقرير فترة مخصصة (القسم 50) |
| GET | `/loyal-patients` | قائمة المريضات الدائمات بالتفصيل |

كل نقاط `daily/weekly/monthly/yearly/range` ترجع نفس الشكل الموحّد:

```json
{
  "period": { "from": "2026-08-01", "to": "2026-08-31" },
  "patients": {
    "total_patients": 42,
    "new_patients": 12,
    "returning_patients": 30,
    "loyal_patients": 9
  },
  "activity": {
    "general_exams": 28,
    "pregnancy_visits": 14,
    "cancelled_visits": 2,
    "no_show_visits": 1,
    "ultrasound_count": 11,
    "prescriptions_count": 33
  },
  "financial": {
    "paid_visits_count": 38,
    "unpaid_visits_count": 3,
    "total_subtotal": "71000.00",
    "total_discounts": "3200.00",
    "net_revenue": "67800.00"
  },
  "paymentMethods": [
    { "method": "CASH", "count": 30, "total": "54000.00" },
    { "method": "CARD", "count": 8, "total": "13800.00" }
  ],
  "topServices": [
    { "name": "فحص عام", "count": 28, "total": "42000.00" },
    { "name": "إيكوغرافي", "count": 11, "total": "19800.00" }
  ]
}
```

## منطق مهم: عدم ازدواج العد (القسم 47)

- **جديدة/سابقة** فئتان حصريتان لا تتقاطعان (كل مريضة إما جديدة أو سابقة في الفترة، ليس كلاهما).
- **الدائمة** (Loyalty) صفة إضافية فوق ذلك (مبنية على إجمالي الزيارات مدى الحياة ≥ `loyalty_visit_threshold` من `clinic_settings`، الافتراضي 5) — لا تُطرح أو تُضاف كفئة منفصلة في مجموع "الإجمالي"، بل تُعرض كرقم مستقل جنبًا إلى جنب.

## منطق الملخص المالي

يُحسب "المدفوع" على أساس حالة الزيارة (`PAID`/`COMPLETED`) ضمن `visit_date` الواقعة في الفترة — وليس على أساس تاريخ الدفع الفعلي — بحيث يبقى كل تقرير متسقًا مع نفس مجموعة الزيارات المعروضة في بقية الأقسام (النشاط، تركيبة المريضات...). الـ Subtotal والتخفيض والصافي محسوبة مباشرة من `discounts`/`visit_services`، وليست تقديرية.

## مثال

```bash
curl "http://localhost:4000/api/statistics/monthly?year=2026&month=8" -b "clinic_session=<TOKEN>"

curl "http://localhost:4000/api/statistics/range?from=2026-08-01&to=2026-08-15" -b "clinic_session=<TOKEN>"

curl "http://localhost:4000/api/statistics/loyal-patients" -b "clinic_session=<TOKEN>"
```

## الخطوة التالية

PHASE 8: شاشة التلفاز (`/tv`)، مشغّل الفيديوهات والـ Playlist، الاستدعاء المرئي والصوتي المتزامن مع لوحة الطبيبة (الأحداث مُفعَّلة منذ PHASE 4).
