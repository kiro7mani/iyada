# PHASE 6 — الوصفات، التسعير، التخفيض، الدفع، الطباعة

## المتطلبات الإضافية

لا مكتبات جديدة (pdfkit موجودة مسبقًا من PHASE 2). لكن يوجد ترحيل جديد:

```bash
cd backend
npm run migrate   # ينفّذ 003_payment_receipt_sequence.sql (توليد رقم الوصل تلقائيًا)
npm run seed       # يضيف خدمتين افتراضيتين: "فحص عام" (1500) و"إيكوغرافي" (2000)
```

Backend فقط في هذه المرحلة أيضًا — الشاشة الموحّدة (فحص + وصفة + تسعير) في لوحة الطبيبة تُبنى بصريًا لاحقًا.

## تسلسل العملية الكاملة (من انتهاء الفحص إلى إغلاق الزيارة)

```
EXAM_COMPLETED
   → POST /api/visits/:id/services      (إضافة خدمة/أكثر، الطبيبة فقط)
   → POST /api/visits/:id/discount      (اختياري، الطبيبة فقط)
   → POST /api/visits/:id/finalize-pricing   → الحالة: AWAITING_PAYMENT
   → POST /api/visits/:id/payments      (الاستقبال، يتطلب مطابقة المبلغ) → الحالة: PAID
   → POST /api/visits/:id/complete       → الحالة: COMPLETED
```

## نقاط API الجديدة

### كتالوج الخدمات (`/api/services`)

| Method | Path | الصلاحية | الوصف |
|---|---|---|---|
| GET | `/` | الكل | قائمة الخدمات (`?activeOnly=true` للنشطة فقط) |
| POST | `/` | admin | إضافة خدمة جديدة |
| PUT | `/:id` | admin | تعديل اسم/سعر/تفعيل خدمة |

### التسعير والتخفيض والدفع (`/api/visits/:id/...`)

| Method | Path | الصلاحية | الوصف |
|---|---|---|---|
| GET | `/services` | الكل | خدمات الزيارة الحالية |
| POST | `/services` | admin, **doctor فقط** | إضافة خدمة وسعرها (`serviceId`, `price` اختياري) |
| DELETE | `/services/:serviceLineId` | admin, doctor | حذف سطر خدمة |
| POST | `/discount` | admin, **doctor فقط** | تحديد تخفيض (`type`: FIXED/PERCENTAGE, `value`) |
| GET | `/invoice` | الكل | الفاتورة الحالية (خدمات + تخفيض + المبلغ النهائي) |
| POST | `/finalize-pricing` | admin, doctor | EXAM_COMPLETED → AWAITING_PAYMENT |
| POST | `/payments` | admin, **reception فقط** | تسجيل الدفع (`amount`, `method`) → PAID |
| POST | `/complete` | admin, reception | PAID → COMPLETED |
| GET | `/receipt/print` | الكل | وصل الدفع كـ PDF |

⚠️ **فرض صلاحية السعر (القسم 40)**: مسارا `services` (الإضافة) و`discount` مقيَّدان بـ `requireRole('admin','doctor')` فقط — الاستقبال ممنوعة تمامًا من تعديل أي سعر أو تخفيض، بالضبط كما هو مطلوب. الاستقبال ترى المبلغ فقط عبر `/invoice` وتُسجّل الدفع.

### الوصفات الطبية

| Method | Path | الصلاحية | الوصف |
|---|---|---|---|
| POST | `/api/visits/:id/prescriptions` | admin, doctor | إنشاء وصفة (`items: [{medicationName, dosage, frequency, duration, instructions}]`) |
| GET | `/api/visits/:id/prescriptions` | الكل | وصفات هذه الزيارة |
| GET | `/api/prescriptions/:id/print` | الكل | الوصفة كـ PDF جاهز للطباعة |

## التحقق من مطابقة المبلغ عند الدفع

عند `POST /payments`، يُقارن الخادم `amount` المُرسَل بالمبلغ النهائي المحسوب فعليًا من قاعدة البيانات (وليس بما يرسله المتصفح كـ "المبلغ المعروض")، لمنع أي تلاعب. أي فرق أكبر من 0.01 يُرفض مع رسالة توضّح المبلغ الصحيح.

## مثال متكامل (curl)

```bash
TOKEN="<clinic_session من تسجيل الدخول>"

# 1) إضافة خدمة (بعد أن تصبح الزيارة EXAM_COMPLETED)
curl -X POST http://localhost:4000/api/visits/12/services \
  -H "Content-Type: application/json" -b "clinic_session=$TOKEN" \
  -d '{"serviceId": 1}'   # يستخدم default_price تلقائيًا (1500)

curl -X POST http://localhost:4000/api/visits/12/services \
  -H "Content-Type: application/json" -b "clinic_session=$TOKEN" \
  -d '{"serviceId": 2, "price": 1800}'   # سعر مخصص لهذه الزيارة فقط

# 2) تخفيض 300 دج ثابت
curl -X POST http://localhost:4000/api/visits/12/discount \
  -H "Content-Type: application/json" -b "clinic_session=$TOKEN" \
  -d '{"type":"FIXED","value":300}'

# 3) تثبيت التسعير
curl -X POST http://localhost:4000/api/visits/12/finalize-pricing -b "clinic_session=$TOKEN"

# 4) الدفع (المبلغ يجب أن يطابق: 1500+1800-300 = 3000)
curl -X POST http://localhost:4000/api/visits/12/payments \
  -H "Content-Type: application/json" -b "clinic_session=$TOKEN" \
  -d '{"amount": 3000, "method": "CASH"}'

# 5) إنهاء الزيارة
curl -X POST http://localhost:4000/api/visits/12/complete -b "clinic_session=$TOKEN"

# 6) طباعة الوصل
curl http://localhost:4000/api/visits/12/receipt/print -b "clinic_session=$TOKEN" --output receipt.pdf
```

## الخطوة التالية

PHASE 7: الإحصائيات (يومية/أسبوعية/شهرية/سنوية)، التمييز بين مريضة جديدة/سابقة/دائمة، التقرير المالي.
